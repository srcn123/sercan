<?php
// SrcnChat PHP — sıralı sesli sohbet API (Next.js /api/rooms/[id]/voice ile birebir)
// Kural: mikrofonu alan bırakana kadar kimse alamaz, herkes sırayla alır.
// Kullanım:
//   GET  php/api/voice.php?room=1&user_id=5
//   POST php/api/voice.php  {room, user_id, username, action: take|release|heartbeat|leave}
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/../config.php';

define('VOICE_STALE_SEC', 60);

try {
  $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => 'Veritabanına bağlanılamadı']);
  exit;
}

// Tablolar yoksa otomatik oluştur (kurulum gerektirmez)
$pdo->exec("CREATE TABLE IF NOT EXISTS voice_holders (
  room_id INT PRIMARY KEY,
  user_id INT NOT NULL,
  username VARCHAR(32) NOT NULL,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("CREATE TABLE IF NOT EXISTS voice_queue (
  id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT NOT NULL,
  user_id INT NOT NULL,
  username VARCHAR(32) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_room_created (room_id, created_at),
  UNIQUE KEY uq_room_user (room_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

function voice_state($pdo, $room, $me) {
  $st = $pdo->prepare('SELECT room_id AS roomId, user_id AS userId, username FROM voice_holders WHERE room_id=?');
  $st->execute([$room]);
  $holder = $st->fetch() ?: null;
  $q = $pdo->prepare('SELECT id, user_id AS userId, username FROM voice_queue WHERE room_id=? ORDER BY created_at ASC LIMIT 20');
  $q->execute([$room]);
  $queue = $q->fetchAll();
  $pos = 0;
  foreach ($queue as $i => $row) { if ((int)$row['userId'] === (int)$me) { $pos = $i + 1; break; } }
  return [$holder, $queue, $holder && (int)$holder['userId'] === (int)$me, $pos];
}

function voice_system($pdo, $room, $text) {
  try {
    $st = $pdo->prepare("INSERT INTO messages (room_id, user_id, username, color, `rank`, content, kind) VALUES (?, NULL, 'Sistem', '#64748b', 'admin', ?, 'system')");
    $st->execute([$room, $text]);
  } catch (Throwable $e) { /* messages tablosu yoksa sessiz geç */ }
}

function voice_expire_stale($pdo, $room) {
  $st = $pdo->prepare('SELECT * FROM voice_holders WHERE room_id=?');
  $st->execute([$room]);
  $holder = $st->fetch();
  if ($holder && (time() - strtotime($holder['updated_at'])) > VOICE_STALE_SEC) {
    $pdo->prepare('DELETE FROM voice_holders WHERE room_id=?')->execute([$room]);
    voice_system($pdo, $room, '🎤 '.$holder['username'].' mikrofonu bıraktı');
    $nq = $pdo->prepare('SELECT * FROM voice_queue WHERE room_id=? ORDER BY created_at ASC LIMIT 1');
    $nq->execute([$room]);
    if ($next = $nq->fetch()) {
      $pdo->prepare('DELETE FROM voice_queue WHERE id=?')->execute([$next['id']]);
      $ins = $pdo->prepare('INSERT INTO voice_holders (room_id, user_id, username) VALUES (?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), username=VALUES(username)');
      $ins->execute([$room, $next['user_id'], $next['username']]);
      voice_system($pdo, $room, '🎤 '.$next['username'].' mikrofon aldı');
    }
  }
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
  $room = (int)($_GET['room'] ?? 0);
  $me = (int)($_GET['user_id'] ?? 0);
  if (!$room) { http_response_code(400); echo json_encode(['error' => 'Geçersiz oda']); exit; }
  voice_expire_stale($pdo, $room);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => $am, 'myPosition' => $pos]);
  exit;
}

$in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$room = (int)($in['room'] ?? 0);
$me = (int)($in['user_id'] ?? 0);
$username = substr(trim((string)($in['username'] ?? '')), 0, 32);
$action = (string)($in['action'] ?? 'take');
if (!$room || !$me || !$username) { http_response_code(400); echo json_encode(['error' => 'room, user_id ve username zorunlu']); exit; }

voice_expire_stale($pdo, $room);
[$holder, $queue] = voice_state($pdo, $room, $me);

if ($action === 'heartbeat') {
  if ($holder && (int)$holder['userId'] === $me) $pdo->prepare('UPDATE voice_holders SET updated_at=NOW() WHERE room_id=?')->execute([$room]);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => $am, 'myPosition' => $pos]);
  exit;
}
if ($action === 'leave') {
  $pdo->prepare('DELETE FROM voice_queue WHERE room_id=? AND user_id=?')->execute([$room, $me]);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => $am, 'myPosition' => 0]);
  exit;
}
if ($action === 'release') {
  if (!$holder || (int)$holder['userId'] !== $me) { http_response_code(400); echo json_encode(['error' => 'Mikrofon sende değil.']); exit; }
  $pdo->prepare('DELETE FROM voice_holders WHERE room_id=?')->execute([$room]);
  voice_system($pdo, $room, '🎤 '.$username.' mikrofonu bıraktı');
  $nq = $pdo->prepare('SELECT * FROM voice_queue WHERE room_id=? ORDER BY created_at ASC LIMIT 1');
  $nq->execute([$room]);
  if ($next = $nq->fetch()) {
    $pdo->prepare('DELETE FROM voice_queue WHERE id=?')->execute([$next['id']]);
    $pdo->prepare('INSERT INTO voice_holders (room_id, user_id, username) VALUES (?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), username=VALUES(username)')->execute([$room, $next['user_id'], $next['username']]);
    voice_system($pdo, $room, '🎤 '.$next['username'].' mikrofon aldı');
  }
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => false, 'myPosition' => 0]);
  exit;
}

// take: tutucu varsa ASLA üzerine yazma — sıraya gir
if ($holder && (int)$holder['userId'] === $me) {
  $pdo->prepare('UPDATE voice_holders SET updated_at=NOW() WHERE room_id=?')->execute([$room]);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => true, 'myPosition' => 0]);
  exit;
}
if ($holder) {
  $pdo->prepare('INSERT IGNORE INTO voice_queue (room_id, user_id, username) VALUES (?,?,?)')->execute([$room, $me, $username]);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => false, 'myPosition' => $pos, 'queued' => true]);
  exit;
}
$pdo->prepare('INSERT INTO voice_holders (room_id, user_id, username) VALUES (?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), username=VALUES(username)')->execute([$room, $me, $username]);
// yarış koruması: araya başkası girdiyse sıraya düş
$chk = $pdo->prepare('SELECT * FROM voice_holders WHERE room_id=?'); $chk->execute([$room]);
$cur = $chk->fetch();
if (!$cur || (int)$cur['user_id'] !== $me) {
  $pdo->prepare('INSERT IGNORE INTO voice_queue (room_id, user_id, username) VALUES (?,?,?)')->execute([$room, $me, $username]);
  [$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
  echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => false, 'myPosition' => $pos, 'queued' => true]);
  exit;
}
$pdo->prepare('DELETE FROM voice_queue WHERE room_id=? AND user_id=?')->execute([$room, $me]);
voice_system($pdo, $room, '🎤 '.$username.' mikrofon aldı');
[$holder, $queue, $am, $pos] = voice_state($pdo, $room, $me);
echo json_encode(['holder' => $holder, 'queue' => $queue, 'amHolder' => true, 'myPosition' => 0]);
