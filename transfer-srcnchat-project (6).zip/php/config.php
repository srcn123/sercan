<?php
// SrcnChat PHP — veritabanı ayarları
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'srcnchat');
define('SITE_URL', getenv('SITE_URL') ?: 'https://srcnchat.com');
define('OPENAI_KEY', getenv('OPENAI_API_KEY') ?: '');
