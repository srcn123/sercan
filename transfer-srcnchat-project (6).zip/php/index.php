<?php
require __DIR__ . '/config.php';
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SrcnChat — Sohbetin yeni adresi</title>
<meta name="description" content="Odalara katıl, özel sohbetler başlat, radyoyu aç ve rütbeni yükselt.">
<link rel="canonical" href="<?= htmlspecialchars(SITE_URL) ?>/sohbet.html">
<meta property="og:title" content="SrcnChat">
<meta property="og:description" content="Odalara katıl, özel sohbetler başlat.">
<meta property="og:url" content="<?= htmlspecialchars(SITE_URL) ?>/sohbet.html">
<meta property="og:type" content="website">
<link rel="sitemap" type="application/xml" href="/sitemap.xml">
</head>
<body>
<h1>SrcnChat PHP Sürümü</h1>
<p>Bu dosya Next.js sürümünün PHP + MySQL karşılığıdır. Tam özellikli sohbet için <a href="/chat">Next.js sürümüne</a> geçin.</p>
<ul>
  <li>🎤 <b>Sesli sohbet (sıralı mikrofon):</b> odada mikrofonu alan bırakana kadar kimse alamaz, herkes sırayla alır. API: <code>php/api/voice.php</code> (GET status, POST take/release/heartbeat/leave). Alınca sohbete “🎤 X mikrofon aldı”, bırakınca “🎤 X mikrofonu bıraktı” düşer.</li>
  <li>💬 Odalar, özel mesaj, hediyeler, puan, seviyeler, blog, lisans, radyo/DJ, okey salonu, kamera, moderasyon.</li>
  <li>📱 Mobil uyumlu + PWA. Kurulum: <a href="kurulum.php">Kurulum sihirbazı</a>.</li>
</ul>
<p><a href="kurulum.php">Kurulum sihirbazı</a> | <a href="/sitemap.xml">Sitemap</a> | <a href="/robots.txt">robots.txt</a> | <a href="api/voice.php?room=1&user_id=0">Ses API durumu (demo)</a></p>
<?php include __DIR__ . '/sitemap_gen.php'; ?>
</body>
</html>
