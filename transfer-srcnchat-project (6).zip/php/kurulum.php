<?php
require __DIR__ . '/config.php';
$installed = file_exists(__DIR__ . '/installed.lock');
if ($installed) { header('Location: index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  file_put_contents(__DIR__ . '/installed.lock', date('c'));
  echo "<p>Kurulum tamamlandı. Kurucu: ".htmlspecialchars($_POST['username'])." — <a href='index.php'>Sohbete git</a></p>"; exit;
}
?>
<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Kurulum — SrcnChat</title></head><body>
<h1>SrcnChat Kurulum Sihirbazı</h1>
<form method="post">
<label>Site adı <input name="site_name" value="SrcnChat" required></label><br>
<label>Alan adı <input name="domain" placeholder="srcnchat.com"></label><br>
<label>SEO başlık <input name="seo_title" value="SrcnChat — Sohbetin yeni adresi"></label><br>
<label>Kurucu kullanıcı <input name="username" value="Sercan" required> Şifre <input name="password" type="password" value="Sercan123" required></label><br>
<button>Kurulumu Tamamla</button>
</form>
<p><small>Not: .htaccess SEO linkleri, robots.txt ve sitemap otomatik oluşturulur.</small></p>
</body></html>
