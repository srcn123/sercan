User-agent: *
Allow: /sohbet.html
Allow: /oda-*.html
Disallow: /php/admin.php
Sitemap: <?= SITE_URL ?>/sitemap.xml
