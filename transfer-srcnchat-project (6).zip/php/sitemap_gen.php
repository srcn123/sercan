<?php
// Dinamik sitemap üretici — php/sitemap_gen.php?echo=1 ile çağrılabilir
if (php_sapi_name() !== 'cli' && !isset($_GET['echo'])) return;
$base = SITE_URL;
$urls = ["$base/sohbet.html", "$base/kurulum.html", "$base/admin.html"];
echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
foreach ($urls as $u) echo "<url><loc>".htmlspecialchars($u)."</loc><changefreq>daily</changefreq></url>";
echo '</urlset>';
