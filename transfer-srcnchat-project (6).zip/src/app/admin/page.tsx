import { redirect } from "next/navigation";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { getCurrentUser, publicUser } from "@/lib/auth";
import { PERM, rankLevel } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
export const dynamic = "force-dynamic";
export default async function AdminPage() {
  await ensureSeed();
  const user = await getCurrentUser();
  if (!user) redirect("/?mode=login");
  if (rankLevel(user.rank) < PERM.adminPanel) redirect("/chat");
  return <AdminPanel me={publicUser(user)} />;
}
