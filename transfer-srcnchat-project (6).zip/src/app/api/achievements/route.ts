import { db } from "@/db";
import { achievements } from "@/db/schema";
import { getCurrentUser, grantAchievement } from "@/lib/auth";
import { levelFromXp } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (levelFromXp(me.xp) >= 10) await grantAchievement(me.id, "seviye_10");
  const rows = await db.select().from(achievements).where(eq(achievements.userId, me.id));
  return Response.json({ achievements: rows.filter((r) => r.key !== "spin") });
}
