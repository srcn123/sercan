import { db } from "@/db";
import { activityLog, users } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { desc, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const rows = await db.select({ id: activityLog.id, userId: activityLog.userId, username: activityLog.username, ip: activityLog.ip, city: activityLog.city, country: activityLog.country, action: activityLog.action, createdAt: activityLog.createdAt, isBanned: users.isBanned, rank: users.rank }).from(activityLog).leftJoin(users, eq(activityLog.userId, users.id)).orderBy(desc(activityLog.id)).limit(200);
  return Response.json({ activity: rows });
}
