import { db } from "@/db";
import { users } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { setSetting } from "@/lib/auth";
import { USERNAME_REGEX } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const bots = await db.select({ id: users.id, username: users.username, botKind: users.botKind, botEnabled: users.botEnabled, botRoomMode: users.botRoomMode, botRoomId: users.botRoomId, color: users.color, avatarUrl: users.avatarUrl, bannerUrl: users.bannerUrl, about: users.about }).from(users).where(eq(users.isBot, true));
  return Response.json({ bots });
}
export async function POST(req: Request) {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  if (b.action === "toggleAll") { await setSetting("botsEnabled", b.value ? "1" : "0"); await db.update(users).set({ botEnabled: !!b.value }).where(eq(users.isBot, true)); return Response.json({ ok: true }); }
  if (b.action === "create") {
    const name = String(b.username ?? "").trim();
    if (!USERNAME_REGEX.test(name)) return Response.json({ error: "Geçersiz bot adı" }, { status: 400 });
    const kind = ["nova", "dj", "security", "user"].includes(b.botKind) ? b.botKind : "security";
    const rank = kind === "user" ? "uye" : "vip";
    const col = kind === "nova" ? "#a855f7" : kind === "dj" ? "#f59e0b" : kind === "user" ? "#22c55e" : "#ef4444";
    const [bot] = await db.insert(users).values({ username: name, usernameLower: name.toLocaleLowerCase("tr"), isBot: true, isGuest: false, rank, botKind: kind, color: col, botRoomMode: kind === "security" ? "all" : "roam", isVerified: true, lastSeen: new Date() }).returning();
    return Response.json({ bot });
  }
  const [bot] = await db.select().from(users).where(eq(users.id, Number(b.id))).limit(1);
  if (!bot?.isBot) return Response.json({ error: "Bot yok" }, { status: 404 });
  if (b.action === "delete") { await db.delete(users).where(eq(users.id, bot.id)); return Response.json({ ok: true }); }
  if (b.action === "update") {
    const patch: Partial<typeof users.$inferInsert> = {};
    if (typeof b.username === "string" && USERNAME_REGEX.test(b.username.trim())) { patch.username = b.username.trim(); patch.usernameLower = b.username.trim().toLocaleLowerCase("tr"); }
    if (typeof b.botEnabled === "boolean") patch.botEnabled = b.botEnabled;
    if (["all", "roam", "fixed"].includes(b.botRoomMode)) patch.botRoomMode = b.botRoomMode;
    if (b.botRoomId === null || typeof b.botRoomId === "number") patch.botRoomId = b.botRoomId;
    if (typeof b.avatarUrl === "string") patch.avatarUrl = b.avatarUrl.slice(0, 400000) || null;
    if (typeof b.bannerUrl === "string") patch.bannerUrl = b.bannerUrl.slice(0, 600000) || null;
    if (typeof b.about === "string") patch.about = b.about.slice(0, 300);
    if (typeof b.color === "string") patch.color = b.color.slice(0, 16);
    await db.update(users).set(patch).where(eq(users.id, bot.id));
    return Response.json({ ok: true });
  }
  if (b.action === "say") {
    const { messages } = await import("@/db/schema");
    await db.insert(messages).values({ roomId: Number(b.roomId), userId: bot.id, username: bot.username, color: bot.color, rank: bot.rank, avatarUrl: bot.avatarUrl, content: String(b.text ?? "").slice(0, 500) });
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
