import { db } from "@/db";
import { licenses } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
export const dynamic = "force-dynamic";
export async function GET() {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  if (me.username.toLowerCase() !== "sercan") return Response.json({ error: "Lisans kodları sadece en yüksek yetkili Sercan tarafından görülebilir" }, { status: 403 });
  const list = await db.select().from(licenses);
  return Response.json({ licenses: list });
}
export async function POST(req: Request) {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  if (me.username.toLowerCase() !== "sercan") return Response.json({ error: "Sadece Sercan lisans üretebilir" }, { status: 403 });
  const b = await req.json().catch(()=>({}));
  if (b.action === "generate") {
    const count = Math.min(100, Math.max(1, Number(b.count) || 10));
    const crypto = await import("crypto");
    const newKeys: string[] = [];
    for(let i=0;i<count;i++){
      const s = crypto.randomBytes(8).toString("hex").toUpperCase();
      const key = 'SRCN-'+s.slice(0,4)+'-'+s.slice(4,8)+'-'+s.slice(8,12)+'-'+s.slice(12,16);
      try { await db.insert(licenses).values({ key }).onConflictDoNothing(); newKeys.push(key); } catch {}
    }
    return Response.json({ ok: true, keys: newKeys });
  }
  if (b.action === "status") {
    const { eq } = await import("drizzle-orm");
    const { licenses: l } = await import("@/db/schema");
    await db.update(l).set({ status: String(b.status), note: String(b.note ?? "").slice(0,200), expiresAt: b.expiresAt ? new Date(b.expiresAt) : null }).where(eq(l.key, String(b.key)));
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
