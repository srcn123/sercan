import { db } from "@/db";
import { bans, users } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { eq, desc, gt, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
// Adminlere özel: sadece yasak/ban ve susturma listesi, sadece kaldırma yetkisi
export async function GET() {
  const { me, res } = await adminGuard();
  if (!me) return res;
  // muted: mutedUntil > now
  const muted = await db.select({ id: users.id, username: users.username, color: users.color, avatarUrl: users.avatarUrl, rank: users.rank, mutedUntil: users.mutedUntil }).from(users).where(gt(users.mutedUntil, sql`now()`));
  const banned = await db.select({ id: bans.id, userId: bans.userId, username: bans.username, ip: bans.ip, reason: bans.reason, byUsername: bans.byUsername, active: bans.active, createdAt: bans.createdAt }).from(bans).where(eq(bans.active, true)).orderBy(desc(bans.id)).limit(50);
  return Response.json({ muted, banned });
}
export async function POST(req: Request) {
  const { me, res } = await adminGuard();
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  if (b.action === "unmute") {
    const [t] = await db.select().from(users).where(eq(users.id, Number(b.id))).limit(1);
    if (!t) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
    await db.update(users).set({ mutedUntil: null }).where(eq(users.id, t.id));
    // chatte bildirim: susturma açıldı
    try {
      const { messages, rooms } = await import("@/db/schema");
      const [room] = await db.select({ id: rooms.id }).from(rooms).where(eq(rooms.isDefault, true)).limit(1);
      if (room) await db.insert(messages).values({ roomId: room.id, username: "Sistem", color: "#10b981", rank: "admin", content: `🔊 ${t.username} susturulması ${me.username} tarafından açıldı.`, kind: "system" });
    } catch {}
    return Response.json({ ok: true });
  }
  if (b.action === "unban") {
    await db.update(users).set({ isBanned: false, violations: 0, mutedUntil: null }).where(eq(users.id, Number(b.userId)));
    await db.update(bans).set({ active: false }).where(eq(bans.id, Number(b.id)));
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
