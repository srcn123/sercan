import { db } from "@/db";
import { rooms } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  const [room] = await db.select().from(rooms).where(eq(rooms.id, Number(b.id))).limit(1);
  if (!room) return Response.json({ error: "Oda yok" }, { status: 404 });
  if (b.action === "delete") { if (room.isDefault) return Response.json({ error: "Lobi silinemez" }, { status: 400 }); await db.delete(rooms).where(eq(rooms.id, room.id)); return Response.json({ ok: true }); }
  const patch: Partial<typeof rooms.$inferInsert> = {};
  if (typeof b.name === "string" && b.name.trim().length >= 2) patch.name = b.name.trim().slice(0, 40);
  if (typeof b.description === "string") patch.description = b.description.slice(0, 160);
  if (typeof b.icon === "string" && b.icon) patch.icon = b.icon.slice(0, 8);
  if (typeof b.imageUrl === "string") patch.imageUrl = b.imageUrl.slice(0, 400000) || null;
  if (typeof b.bgUrl === "string") patch.bgUrl = b.bgUrl.slice(0, 600000) || null;
  if (b.ownerId === null || typeof b.ownerId === "number") patch.ownerId = b.ownerId;
  if (["chat", "ai", "radio", "okey", "music"].includes(b.kind)) patch.kind = b.kind;
  if (typeof b.sortOrder === "number") patch.sortOrder = b.sortOrder;
  await db.update(rooms).set(patch).where(eq(rooms.id, room.id));
  return Response.json({ ok: true });
}
