import { db } from "@/db";
import { wordRules, bans } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { desc, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  return Response.json({ rules: await db.select().from(wordRules).orderBy(wordRules.id), bans: await db.select().from(bans).orderBy(desc(bans.id)).limit(100) });
}
export async function POST(req: Request) {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  if (b.action === "addRule") { const [r] = await db.insert(wordRules).values({ word: String(b.word).trim().slice(0, 40), replacement: String(b.replacement || "***").slice(0, 40) }).returning(); return Response.json({ rule: r }); }
  if (b.action === "deleteRule") { await db.delete(wordRules).where(eq(wordRules.id, Number(b.id))); return Response.json({ ok: true }); }
  if (b.action === "liftBan") { await db.update(bans).set({ active: false }).where(eq(bans.id, Number(b.id))); return Response.json({ ok: true }); }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
