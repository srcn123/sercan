import { adminGuard } from "@/lib/adminGuard";
import { setSetting } from "@/lib/auth";
export const dynamic = "force-dynamic";
const ALLOWED = ["siteName", "domain", "seoTitle", "seoDescription", "seoKeywords", "logoText", "logoUrl", "defaultTheme", "radioEnabled", "radioStation", "customRadioUrl", "announcement", "securityMuteMinutes", "securityBanAfter", "botsEnabled", "iosAppStoreUrl", "androidPlayStoreUrl", "androidApkUrl", "iosIcon", "androidIcon", "mobileDescription", "mobileEnabled", "mobileAppName", "mobileAppShortName", "mobileAppDescription", "mobileAppIcon", "mobileAppThemeColor", "mobileAppBackgroundColor", "mobileAppBrand", "appStoreDescription", "playStoreDescription"];
export async function POST(req: Request) {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  for (const k of ALLOWED) if (typeof b[k] === "string") await setSetting(k, k === "logoText" ? b[k].slice(0, 15) : b[k].slice(0, k === "logoUrl" ? 400000 : 500));
  return Response.json({ ok: true });
}
