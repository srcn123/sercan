import { db } from "@/db";
import { activityLog, giftLog, messages, privateMessages, rooms, users, pointLog } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { getSettings } from "@/lib/auth";
import { ONLINE_WINDOW_MS } from "@/lib/constants";
import { and, count, eq, gt, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const { me, res } = await adminGuard();
  if (!me) return res;
  const since = new Date(Date.now() - ONLINE_WINDOW_MS);
  const c = async <T>(q: Promise<{ value: T }[]>) => (await q)[0]?.value ?? 0;
  const [usersTotal, members, guests, online, msgs, dms, roomCount, gifts, today, bannedCount] = await Promise.all([
    c(db.select({ value: count() }).from(users).where(eq(users.isBot, false))),
    c(db.select({ value: count() }).from(users).where(and(eq(users.isGuest, false), eq(users.isBot, false)))),
    c(db.select({ value: count() }).from(users).where(eq(users.isGuest, true))),
    c(db.select({ value: count() }).from(users).where(and(gt(users.lastSeen, since), eq(users.isBot, false)))),
    c(db.select({ value: count() }).from(messages)),
    c(db.select({ value: count() }).from(privateMessages)),
    c(db.select({ value: count() }).from(rooms)),
    c(db.select({ value: count() }).from(giftLog)),
    c(db.select({ value: count() }).from(activityLog).where(gt(activityLog.createdAt, sql`now() - interval '1 day'`))),
    c(db.select({ value: count() }).from(users).where(eq(users.isBanned, true))),
  ]);
  return Response.json({ stats: { usersTotal, members, guests, online, msgs, dms, roomCount, gifts, today, bannedCount }, settings: await getSettings(), me: { rank: me.rank, username: me.username } });
}
export async function POST() {
  const { me, res } = await adminGuard(true);
  if (!me) return res;
  await db.delete(pointLog);
  await db.delete(activityLog);
  await db.update(users).set({ totalMessages: 0, giftsSent: 0, giftsReceived: 0, onlineSeconds: 0 });
  return Response.json({ ok: true });
}
