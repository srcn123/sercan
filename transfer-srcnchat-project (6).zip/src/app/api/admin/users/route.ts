import { db } from "@/db";
import { users, sessions, bans } from "@/db/schema";
import { adminGuard } from "@/lib/adminGuard";
import { hashPassword } from "@/lib/auth";
import { RANKS, rankLevel, levelFromXp, type RankKey, USERNAME_REGEX } from "@/lib/constants";
import { count, desc, eq, ilike, and } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const { me, res } = await adminGuard();
  if (!me) return res;
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? 1));
  const q = url.searchParams.get("q") ?? "";
  const where = and(eq(users.isBot, false), q ? ilike(users.username, `%${q}%`) : undefined);
  const [{ value: total }] = await db.select({ value: count() }).from(users).where(where);
  const rows = await db.select({ id: users.id, username: users.username, email: users.email, rank: users.rank, isGuest: users.isGuest, isDj: users.isDj, points: users.points, xp: users.xp, isBanned: users.isBanned, mutedUntil: users.mutedUntil, lastIp: users.lastIp, lastSeen: users.lastSeen, createdAt: users.createdAt, totalMessages: users.totalMessages, color: users.color, avatarUrl: users.avatarUrl, isVerified: users.isVerified }).from(users).where(where).orderBy(desc(users.lastSeen)).limit(25).offset((page - 1) * 25);
  return Response.json({ users: rows.map((r) => ({ ...r, level: levelFromXp(r.xp) })), total, page, pages: Math.ceil(total / 25) });
}
export async function POST(req: Request) {
  const { me, res } = await adminGuard();
  if (!me) return res;
  const b = await req.json().catch(() => ({}));
  const [t] = await db.select().from(users).where(eq(users.id, Number(b.id))).limit(1);
  if (!t) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
  const myLevel = rankLevel(me.rank);
  if (t.id !== me.id && rankLevel(t.rank) >= myLevel) return Response.json({ error: "Bu kullanıcıya işlem yapamazsın" }, { status: 403 });
  switch (b.action) {
    case "rank": {
      const r = String(b.rank) as RankKey;
      if (!(r in RANKS) || RANKS[r].level >= myLevel) return Response.json({ error: "Geçersiz rütbe" }, { status: 400 });
      if (t.isGuest && r !== "misafir") return Response.json({ error: "Misafire rütbe verilemez" }, { status: 400 });
      await db.update(users).set({ rank: r }).where(eq(users.id, t.id)); break;
    }
    case "dj": if (me.rank !== "kurucu") return Response.json({ error: "Yalnızca Kurucu" }, { status: 403 }); await db.update(users).set({ isDj: !!b.value }).where(eq(users.id, t.id)); break;
    case "points": if (me.rank !== "kurucu") return Response.json({ error: "Yalnızca Kurucu" }, { status: 403 }); await db.update(users).set({ points: Math.max(0, Number(b.value) || 0) }).where(eq(users.id, t.id)); break;
    case "password": await db.update(users).set({ passwordHash: hashPassword(String(b.value || "1234")) }).where(eq(users.id, t.id)); await db.delete(sessions).where(eq(sessions.userId, t.id)); break;
    case "delete": if (me.rank !== "kurucu") return Response.json({ error: "Yalnızca Kurucu" }, { status: 403 }); await db.delete(users).where(eq(users.id, t.id)); break;
    case "ban": await db.update(users).set({ isBanned: true }).where(eq(users.id, t.id)); await db.insert(bans).values({ userId: t.id, username: t.username, ip: b.withIp ? t.lastIp : null, reason: "Panel", byUsername: me.username }); await db.delete(sessions).where(eq(sessions.userId, t.id)); break;
    case "unban": await db.update(users).set({ isBanned: false, violations: 0, mutedUntil: null }).where(eq(users.id, t.id)); await db.update(bans).set({ active: false }).where(eq(bans.userId, t.id)); break;
    case "kick": await db.update(users).set({ kickedAt: new Date(), currentRoomId: null }).where(eq(users.id, t.id)); await db.delete(sessions).where(eq(sessions.userId, t.id)); break;
    case "unmute": await db.update(users).set({ mutedUntil: null }).where(eq(users.id, t.id)); break;
    case "update": {
      if (me.rank !== "kurucu") return Response.json({ error: "Yalnızca Kurucu" }, { status: 403 });
      const patch: Record<string, unknown> = {};
      if (typeof b.username === "string" && USERNAME_REGEX.test(b.username.trim())) { patch.username = b.username.trim(); patch.usernameLower = b.username.trim().toLocaleLowerCase("tr"); }
      if (typeof b.email === "string") patch.email = b.email.trim().toLowerCase() || null;
      if (typeof b.color === "string" && /^#[0-9a-f]{6}$/i.test(b.color)) patch.color = b.color;
      if (Object.keys(patch).length) await db.update(users).set(patch).where(eq(users.id, t.id));
      break;
    }
    case "profile": {
      if (me.rank !== "kurucu") return Response.json({ error: "Yalnızca Kurucu" }, { status: 403 });
      const patch: Record<string, unknown> = {};
      if (typeof b.status === "string") patch.status = b.status.slice(0, 80);
      if (typeof b.about === "string") patch.about = b.about.slice(0, 300);
      if (typeof b.country === "string") patch.country = b.country.slice(0, 40);
      if (typeof b.city === "string") patch.city = b.city.slice(0, 40);
      if (Object.keys(patch).length) await db.update(users).set(patch).where(eq(users.id, t.id));
      break;
    }
    default: return Response.json({ error: "Geçersiz" }, { status: 400 });
  }
  return Response.json({ ok: true });
}
