import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, verifyPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { randomInt } from "crypto";
export const dynamic = "force-dynamic";
// step: "request" (email → code via SMTP if configured) | "secret" (secret word reset) | "code" (code reset)
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const step = String(body.step ?? "");
  const username = String(body.username ?? "").trim();
  const [user] = await db.select().from(users).where(eq(users.usernameLower, username.toLocaleLowerCase("tr"))).limit(1);
  if (!user || user.isGuest) return Response.json({ error: "Kayıtlı kullanıcı bulunamadı." }, { status: 404 });
  const newPassword = String(body.newPassword ?? "");
  if (step === "request") {
    const code = String(randomInt(100000, 999999));
    await db.update(users).set({ resetCode: code }).where(eq(users.id, user.id));
    const smtp = process.env.SMTP_URL || process.env.RESEND_API_KEY;
    if (!smtp) {
      return Response.json({ ok: true, mailed: false, message: "Sunucuda e-posta ayarı yok. Gizli kelimenle sıfırlayabilirsin." });
    }
    try {
      if (process.env.RESEND_API_KEY && user.email) {
        await fetch("https://api.resend.com/emails", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.RESEND_API_KEY}` }, body: JSON.stringify({ from: process.env.MAIL_FROM || "SrcnChat <onboarding@resend.dev>", to: [user.email], subject: "SrcnChat şifre sıfırlama kodu", text: `Şifre sıfırlama kodun: ${code}` }) });
      }
    } catch {}
    return Response.json({ ok: true, mailed: true, message: `Kod e-postana gönderildi (${user.email?.replace(/(.{2}).+(@.+)/, "$1***$2")}).` });
  }
  if (newPassword.length < 4) return Response.json({ error: "Yeni şifre en az 4 karakter olmalı." }, { status: 400 });
  if (step === "secret") {
    const secret = String(body.secretWord ?? "").trim().toLocaleLowerCase("tr");
    if (!verifyPassword(secret, user.secretWordHash)) return Response.json({ error: "Gizli kelime hatalı." }, { status: 401 });
  } else if (step === "code") {
    const code = String(body.code ?? "");
    if (!user.resetCode || user.resetCode !== code) return Response.json({ error: "Kod hatalı." }, { status: 401 });
  } else return Response.json({ error: "Geçersiz adım" }, { status: 400 });
  await db.update(users).set({ passwordHash: hashPassword(newPassword), resetCode: null }).where(eq(users.id, user.id));
  return Response.json({ ok: true, message: "Şifren güncellendi. Şimdi giriş yapabilirsin." });
}
