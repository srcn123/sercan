import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, getIp, isIpBanned, logActivity, publicUser } from "@/lib/auth";
import { AVATAR_COLORS, USERNAME_HINT, USERNAME_REGEX } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  await ensureSeed();
  if (await isIpBanned(await getIp())) return Response.json({ error: "Bu IP adresi yasaklı." }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const username = String(body.username ?? "").trim();
  const color = String(body.color ?? AVATAR_COLORS[0]);
  if (!USERNAME_REGEX.test(username)) return Response.json({ error: USERNAME_HINT }, { status: 400 });
  if (!(AVATAR_COLORS as readonly string[]).includes(color)) return Response.json({ error: "Geçersiz renk." }, { status: 400 });
  const lower = username.toLocaleLowerCase("tr");
  const [existing] = await db.select().from(users).where(eq(users.usernameLower, lower)).limit(1);
  let user = existing;
  if (user && (!user.isGuest || user.isBot)) return Response.json({ error: "Bu kullanıcı adı kayıtlı bir üyeye ait. Giriş yapın veya başka bir ad seçin." }, { status: 409 });
  if (user && user.isBanned) return Response.json({ error: "Bu hesap yasaklı." }, { status: 403 });
  if (user) {
    [user] = await db.update(users).set({ color, lastSeen: new Date(), kickedAt: null }).where(eq(users.id, user.id)).returning();
  } else {
    [user] = await db.insert(users).values({ username, usernameLower: lower, color, isGuest: true, rank: "misafir" }).returning();
  }
  await logActivity(user, "guest");
  await createSession(user.id, Boolean(body.rememberMe));
  return Response.json({ user: publicUser(user) });
}
