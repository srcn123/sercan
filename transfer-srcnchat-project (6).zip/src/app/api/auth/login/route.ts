import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, getIp, isIpBanned, logActivity, publicUser, verifyPassword } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  await ensureSeed();
  if (await isIpBanned(await getIp())) return Response.json({ error: "Bu IP adresi yasaklı." }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");
  const rememberMe = Boolean(body.rememberMe);
  const [user] = await db.select().from(users).where(eq(users.usernameLower, username.toLocaleLowerCase("tr"))).limit(1);
  if (!user || user.isGuest || !verifyPassword(password, user.passwordHash)) return Response.json({ error: "Kullanıcı adı veya şifre hatalı." }, { status: 401 });
  if (user.isBanned) return Response.json({ error: "Bu hesap yasaklandı." }, { status: 403 });
  await db.update(users).set({ lastSeen: new Date(), kickedAt: null }).where(eq(users.id, user.id));
  await logActivity(user, "login");
  await createSession(user.id, rememberMe);
  return Response.json({ user: publicUser(user) });
}
