import { destroySession, getCurrentUser, logActivity } from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST() {
  const user = await getCurrentUser();
  if (user) {
    await db.update(users).set({ currentRoomId: null, cameraOn: false, lastSeen: sql`now() - interval '1 hour'` }).where(eq(users.id, user.id));
    await logActivity(user, "logout");
  }
  await destroySession();
  return Response.json({ ok: true });
}
