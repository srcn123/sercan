import { db } from "@/db";
import { users } from "@/db/schema";
import { addPoints, createSession, getIp, hashPassword, isIpBanned, logActivity, publicUser } from "@/lib/auth";
import { AVATAR_COLORS, USERNAME_HINT, USERNAME_REGEX, WELCOME_BONUS } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  await ensureSeed();
  if (await isIpBanned(await getIp())) return Response.json({ error: "Bu IP adresi yasaklı." }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const username = String(body.username ?? "").trim();
  const password = String(body.password ?? "");
  const email = String(body.email ?? "").trim().toLowerCase();
  const secretWord = String(body.secretWord ?? "").trim();
  const color = String(body.color ?? AVATAR_COLORS[0]);
  const gender = String(body.gender ?? "");
  const country = String(body.country ?? "");
  const city = String(body.city ?? "").slice(0,40);
  if (!USERNAME_REGEX.test(username)) return Response.json({ error: USERNAME_HINT }, { status: 400 });
  if (password.length < 4 || password.length > 64) return Response.json({ error: "Şifre 4-64 karakter olmalı." }, { status: 400 });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return Response.json({ error: "Geçerli bir e-posta gir." }, { status: 400 });
  if (secretWord.length < 2) return Response.json({ error: "Gizli kelime en az 2 karakter olmalı (şifre sıfırlamada kullanılır)." }, { status: 400 });
  if (!(AVATAR_COLORS as readonly string[]).includes(color)) return Response.json({ error: "Geçersiz renk." }, { status: 400 });
  if (gender && !["", "kadin", "erkek", "diger"].includes(gender)) return Response.json({ error: "Geçersiz cinsiyet" }, { status: 400 });
  const lower = username.toLocaleLowerCase("tr");
  const [existing] = await db.select().from(users).where(eq(users.usernameLower, lower)).limit(1);
  const [emailTaken] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (emailTaken) return Response.json({ error: "Bu e-posta zaten kayıtlı." }, { status: 409 });
  let user = existing;
  const data = { passwordHash: hashPassword(password), secretWordHash: hashPassword(secretWord.toLocaleLowerCase("tr")), email, isGuest: false, rank: "uye", color, gender, country, city, lastSeen: new Date() };
  if (user) {
    if (!user.isGuest) return Response.json({ error: "Bu kullanıcı adı zaten alınmış." }, { status: 409 });
    [user] = await db.update(users).set(data).where(eq(users.id, user.id)).returning();
  } else {
    [user] = await db.insert(users).values({ username, usernameLower: lower, ...data }).returning();
  }
  await addPoints(user.id, WELCOME_BONUS, "hosgeldin");
  await logActivity(user, "register");
  await createSession(user.id, Boolean(body.rememberMe));
  return Response.json({ user: publicUser({ ...user, points: user.points + WELCOME_BONUS }), bonus: WELCOME_BONUS });
}
