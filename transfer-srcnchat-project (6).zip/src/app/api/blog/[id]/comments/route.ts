import { db } from "@/db";
import { blogComments } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me || me.isGuest) return Response.json({ error: "Yorum için kayıt olmalısın" }, { status: 403 });
  const { id } = await ctx.params;
  const b = await req.json().catch(()=>({}));
  const content = String(b.content ?? "").trim().slice(0,500);
  if (content.length < 2) return Response.json({ error: "Yorum en az 2 karakter" }, { status: 400 });
  const [c]=await db.insert(blogComments).values({ postId: Number(id), userId: me.id, username: me.username, content }).returning();
  return Response.json({ comment: c });
}
export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const list = await db.select().from(blogComments).where(eq(blogComments.postId, Number(id))).orderBy(blogComments.createdAt);
  return Response.json({ comments: list });
}
