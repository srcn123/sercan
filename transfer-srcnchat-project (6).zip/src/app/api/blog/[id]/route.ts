import { db } from "@/db";
import { blogPosts, blogComments, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const pid = Number(id); const isSlug = isNaN(pid);
  const [post] = isSlug ? await db.select().from(blogPosts).where(eq(blogPosts.slug, id)).limit(1) : await db.select().from(blogPosts).where(eq(blogPosts.id, pid)).limit(1);
  if (!post) return Response.json({ error: "Bulunamadı" }, { status: 404 });
  await db.update(blogPosts).set({ views: post.views + 1 }).where(eq(blogPosts.id, post.id));
  const comments = await db.select({ id: blogComments.id, username: blogComments.username, content: blogComments.content, createdAt: blogComments.createdAt, userId: blogComments.userId }).from(blogComments).where(eq(blogComments.postId, post.id)).orderBy(blogComments.createdAt);
  return Response.json({ post: { ...post, views: post.views + 1 }, comments });
}
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser(); if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok" }, { status: 403 });
  const { id } = await ctx.params;
  const b = await req.json().catch(()=>({}));
  const patch: Record<string, unknown> = {};
  if (typeof b.title === "string" && b.title.trim().length >=3) patch.title = b.title.trim().slice(0,120);
  if (typeof b.excerpt === "string") patch.excerpt = b.excerpt.slice(0,200);
  if (typeof b.content === "string") patch.content = b.content;
  if (typeof b.imageUrl === "string") patch.imageUrl = b.imageUrl.slice(0,600000) || null;
  if (!Object.keys(patch).length) return Response.json({ error: "Değişiklik yok" },{status:400});
  // @ts-ignore
  patch.updatedAt = new Date();
  const [updated]=await db.update(blogPosts).set(patch).where(eq(blogPosts.id, Number(id))).returning();
  return Response.json({ post: updated });
}
export async function DELETE(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser(); if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok" }, { status: 403 });
  const { id } = await ctx.params;
  await db.delete(blogPosts).where(eq(blogPosts.id, Number(id)));
  return Response.json({ ok: true });
}
