import { db } from "@/db";
import { blogComments } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function DELETE(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser(); if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const [c]=await db.select().from(blogComments).where(eq(blogComments.id, Number(id))).limit(1);
  if (!c) return Response.json({ error: "Yorum yok" }, { status: 404 });
  if (c.userId !== me.id && me.rank !== "kurucu") return Response.json({ error: "Yetki yok" }, { status: 403 });
  await db.delete(blogComments).where(eq(blogComments.id, Number(id)));
  return Response.json({ ok: true });
}
