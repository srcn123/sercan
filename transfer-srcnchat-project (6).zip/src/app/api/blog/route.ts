import { db } from "@/db";
import { blogPosts, blogComments, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { desc, eq, sql, count } from "drizzle-orm";
export const dynamic = "force-dynamic";
function slugify(s: string) { return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0,80) || "post"; }
export async function GET() {
  const posts = await db.select({ id: blogPosts.id, slug: blogPosts.slug, title: blogPosts.title, excerpt: blogPosts.excerpt, imageUrl: blogPosts.imageUrl, authorName: blogPosts.authorName, views: blogPosts.views, createdAt: blogPosts.createdAt }).from(blogPosts).orderBy(desc(blogPosts.createdAt));
  // add comment counts
  const withCounts = await Promise.all(posts.map(async (p) => {
    const [{ value }] = await db.select({ value: count() }).from(blogComments).where(eq(blogComments.postId, p.id));
    return { ...p, commentCount: value };
  }));
  return Response.json({ posts: withCounts });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const title = String(b.title ?? "").trim().slice(0,120);
  if (title.length < 3) return Response.json({ error: "Başlık en az 3 karakter" }, { status: 400 });
  let slug = slugify(title);
  for (let i=2;i<20;i++) { const [ex]=await db.select({id:blogPosts.id}).from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1); if (!ex) break; slug=`${slugify(title)}-${i}`; }
  const [post]=await db.insert(blogPosts).values({ slug, title, excerpt: String(b.excerpt ?? "").slice(0,200), content: String(b.content ?? ""), imageUrl: b.imageUrl ? String(b.imageUrl).slice(0,600000): null, authorId: me.id, authorName: me.username }).returning();
  return Response.json({ post });
}
