import { db } from "@/db";
import { camViewers, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, gt, sql, and } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { on } = await req.json().catch(() => ({}));
  await db.update(users).set({ cameraOn: !!on }).where(eq(users.id, me.id));
  if (!on) await db.delete(camViewers).where(eq(camViewers.broadcasterId, me.id));
  return Response.json({ ok: true });
}
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const bc = await db.select({ id: users.id, username: users.username, color: users.color, avatarUrl: users.avatarUrl, rank: users.rank }).from(users).where(and(eq(users.cameraOn, true), gt(users.lastSeen, sql`now() - interval '60 seconds'`)));
  const viewers = await db.select({ broadcasterId: camViewers.broadcasterId, username: users.username, viewerId: camViewers.viewerId }).from(camViewers).innerJoin(users, eq(camViewers.viewerId, users.id)).where(gt(camViewers.lastSeen, sql`now() - interval '20 seconds'`));
  return Response.json({ broadcasters: bc.map((b) => ({ ...b, viewers: viewers.filter((v) => v.broadcasterId === b.id).map((v) => v.username) })) });
}
