import { db } from "@/db";
import { camViewers } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { broadcasterId, leave } = await req.json().catch(() => ({}));
  const bid = Number(broadcasterId);
  if (leave) { await db.delete(camViewers).where(and(eq(camViewers.broadcasterId, bid), eq(camViewers.viewerId, me.id))); return Response.json({ ok: true }); }
  const [ex] = await db.select().from(camViewers).where(and(eq(camViewers.broadcasterId, bid), eq(camViewers.viewerId, me.id))).limit(1);
  if (ex) await db.update(camViewers).set({ lastSeen: new Date() }).where(eq(camViewers.id, ex.id));
  else await db.insert(camViewers).values({ broadcasterId: bid, viewerId: me.id });
  return Response.json({ ok: true });
}
