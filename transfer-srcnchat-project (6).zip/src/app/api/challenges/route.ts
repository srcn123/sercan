import { db } from "@/db";
import { challenges, messages } from "@/db/schema";
import { addPoints, getCurrentUser } from "@/lib/auth";
import { desc, eq, gt, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const list = await db.select().from(challenges).where(gt(challenges.endsAt, sql`now() - interval '1 hour'`)).orderBy(desc(challenges.id)).limit(10);
  return Response.json({ challenges: list });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  if (b.action === "create") {
    const target = Math.max(50, Math.min(100000, Number(b.target) || 1000));
    const minutes = Math.max(5, Math.min(1440, Number(b.minutes) || 10));
    const [c] = await db.insert(challenges).values({ creatorId: me.id, creatorName: me.username, title: String(b.title || `${minutes} dakikada ${target} puan topla!`).slice(0, 120), target, endsAt: new Date(Date.now() + minutes * 60000) }).returning();
    if (me.currentRoomId) await db.insert(messages).values({ roomId: me.currentRoomId, userId: me.id, username: me.username, color: me.color, rank: me.rank, content: `🏁 Meydan okuma başlattı: "${c.title}" — destek olmak için Meydan Okumalar panelini aç!`, kind: "system" });
    return Response.json({ challenge: c });
  }
  if (b.action === "support") {
    const amount = Math.max(1, Math.min(me.points, Number(b.amount) || 10));
    const [c] = await db.select().from(challenges).where(eq(challenges.id, Number(b.id))).limit(1);
    if (!c || c.endsAt.getTime() < Date.now()) return Response.json({ error: "Meydan okuma bitti." }, { status: 400 });
    if (c.creatorId === me.id) return Response.json({ error: "Kendi meydan okumana destek olamazsın." }, { status: 400 });
    await addPoints(me.id, -amount, "destek");
    await addPoints(c.creatorId, amount, "destek_al");
    const [u] = await db.update(challenges).set({ progress: sql`${challenges.progress} + ${amount}` }).where(eq(challenges.id, c.id)).returning();
    return Response.json({ challenge: u });
  }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
