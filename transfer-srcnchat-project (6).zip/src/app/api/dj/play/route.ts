import { db } from "@/db";
import { messages, rooms } from "@/db/schema";
import { getCurrentUser, setSetting } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (!(me.isDj || me.rank === "kurucu")) return Response.json({ error: "DJ yetkin yok — Kurucu sana DJ yetkisi vermeli" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  if (b.action === "stop") { await setSetting("nowPlaying", ""); return Response.json({ ok: true }); }
  let t = b.track;
  if (!t && b.query) {
    const q = String(b.query).trim();
    // if query is direct YouTube URL, extract ID instantly — no search needed
    const yt = q.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([\w-]{11})/);
    if (yt) t = { title: "YouTube", artist: "", youtubeId: yt[1] };
    else {
      const r = await fetch(`${new URL(req.url).origin}/api/music/search?q=${encodeURIComponent(q)}`, { headers: { Cookie: req.headers.get("cookie") ?? "" } });
      if (r.ok) { const d = await r.json(); t = d.results?.[0]; }
      // if still nothing, try to treat query as-is as YouTube title with empty ID — will be handled as manual
      if (!t) t = { title: q, artist: "", youtubeId: "" };
    }
  }
  if (!t) return Response.json({ error: "Parça bulunamadı — farklı bir isim dene" }, { status: 404 });
  // enforce full-song: if we have youtubeId it's full, otherwise preview is demo — still allow but mark
  const track = { title: String(t.title ?? t.trackName ?? "Bilinmeyen"), artist: String(t.artist ?? t.artistName ?? ""), youtubeId: String(t.youtubeId ?? ""), previewUrl: t.previewUrl ? String(t.previewUrl) : null, artwork: t.artwork ? String(t.artwork) : (t.youtubeId ? `https://img.youtube.com/vi/${t.youtubeId}/mqdefault.jpg` : null), duration: t.duration ? String(t.duration) : null };
  await setSetting("nowPlaying", JSON.stringify({ ...track, djName: me.username, djId: me.id, startedAt: Date.now() }));
  const [music] = await db.select().from(rooms).where(eq(rooms.kind, "music")).limit(1);
  if (music) await db.insert(messages).values({ roomId: music.id, userId: me.id, username: me.username, color: me.color, rank: me.rank, avatarUrl: me.avatarUrl, content: `🎧 DJ ${me.username} çalıyor: ${track.title} — ${track.artist}${track.youtubeId ? " (tam sürüm)" : ""}`, kind: "nowplaying", meta: track as unknown as Record<string,unknown> });
  return Response.json({ ok: true, track });
}
