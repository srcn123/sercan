import { db } from "@/db";
import { djRequests } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { searchTrack } from "@/lib/bots";
import { desc, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const rows = await db.select().from(djRequests).orderBy(desc(djRequests.id)).limit(30);
  return Response.json({ requests: rows, isDj: me.isDj || me.rank === "kurucu" });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  if (b.action === "request") {
    const q = String(b.query ?? "").trim();
    if (q.length < 2) return Response.json({ error: "Şarkı adı yaz" }, { status: 400 });
    const t = await searchTrack(q);
    const [r] = await db.insert(djRequests).values({ userId: me.id, username: me.username, title: t?.title ?? q, artist: t?.artist ?? "", previewUrl: t?.previewUrl ?? null, artwork: t?.artwork ?? null }).returning();
    return Response.json({ request: r });
  }
  if (!(me.isDj || me.rank === "kurucu")) return Response.json({ error: "DJ yetkin yok" }, { status: 403 });
  const id = Number(b.id);
  if (b.action === "approve") { const [r] = await db.update(djRequests).set({ status: "approved" }).where(eq(djRequests.id, id)).returning(); return Response.json({ request: r }); }
  if (b.action === "reject") { const [r] = await db.update(djRequests).set({ status: "rejected" }).where(eq(djRequests.id, id)).returning(); return Response.json({ request: r }); }
  if (b.action === "delete") { await db.delete(djRequests).where(eq(djRequests.id, id)); return Response.json({ ok: true }); }
  return Response.json({ error: "Geçersiz" }, { status: 400 });
}
