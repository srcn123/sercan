import { db } from "@/db";
import { privateMessages, users } from "@/db/schema";
import { addPoints, getCurrentUser, isMuted } from "@/lib/auth";
import { applyFilters, novaReply } from "@/lib/bots";
import { checkPref } from "@/lib/privacy";
import { POINTS } from "@/lib/constants";
import { and, asc, desc, eq, gt, or, sql, lt, isNotNull } from "drizzle-orm";
export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ userId: string }> };
export async function GET(req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { userId } = await ctx.params;
  const other = Number(userId);
  const url = new URL(req.url);
  const after = Number(url.searchParams.get("after") ?? 0);
  const between = or(and(eq(privateMessages.fromUserId, me.id), eq(privateMessages.toUserId, other)), and(eq(privateMessages.fromUserId, other), eq(privateMessages.toUserId, me.id)));
  await db.update(privateMessages).set({ isRead: true }).where(and(eq(privateMessages.fromUserId, other), eq(privateMessages.toUserId, me.id), eq(privateMessages.isRead, false)));
  // expire ephemeral media 5s after first view
  await db.update(privateMessages).set({ content: "", kind: "expired", meta: {} }).where(and(eq(privateMessages.kind, "ephemeral"), isNotNull(privateMessages.viewedAt), lt(privateMessages.viewedAt, sql`now() - interval '5 seconds'`)));
  const [peer] = await db.select({ id: users.id, username: users.username, color: users.color, rank: users.rank, avatarUrl: users.avatarUrl, isBot: users.isBot, typingAt: users.typingAt, typingTarget: users.typingTarget, presence: users.presence, lastSeen: users.lastSeen, prefDm: users.prefDm, prefAudio: users.prefAudio, prefImage: users.prefImage }).from(users).where(eq(users.id, other)).limit(1);
  const typing = !!peer && peer.typingTarget === `dm:${me.id}` && !!peer.typingAt && Date.now() - peer.typingAt.getTime() < 4000;
  const base = { peer: peer ? { ...peer, typing } : null };
  if (after > 0) {
    const rows = await db.select().from(privateMessages).where(and(between, gt(privateMessages.id, after))).orderBy(asc(privateMessages.id)).limit(200);
    const upd = await db.select({ id: privateMessages.id, isRead: privateMessages.isRead, kind: privateMessages.kind, content: privateMessages.content }).from(privateMessages).where(and(between, gt(privateMessages.id, after - 30))).orderBy(asc(privateMessages.id));
    return Response.json({ ...base, messages: rows, updates: upd });
  }
  const rows = await db.select().from(privateMessages).where(between).orderBy(desc(privateMessages.id)).limit(80);
  return Response.json({ ...base, messages: rows.reverse() });
}
export async function POST(req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { userId } = await ctx.params;
  const other = Number(userId);
  if (!Number.isInteger(other) || other === me.id) return Response.json({ error: "Geçersiz kullanıcı" }, { status: 400 });
  if (await isMuted(me)) return Response.json({ error: "Susturulmuşsun." }, { status: 403 });
  const [peer] = await db.select().from(users).where(eq(users.id, other)).limit(1);
  if (!peer) return Response.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });
  const body = await req.json().catch(() => ({}));
  const action = String(body.action ?? "send");
  if (action === "view") {
    await db.update(privateMessages).set({ viewedAt: new Date() }).where(and(eq(privateMessages.id, Number(body.id)), eq(privateMessages.toUserId, me.id), sql`${privateMessages.viewedAt} is null`));
    return Response.json({ ok: true });
  }
  const kind = body.kind === "ephemeral" ? "ephemeral" : "text";
  let content = String(body.content ?? "").trim().slice(0, kind === "ephemeral" ? 400000 : 1000);
  if (!content) return Response.json({ error: "Boş mesaj gönderilemez." }, { status: 400 });
  if (!peer.isBot) {
    const isAudio = /data:audio|(\.mp3|\.ogg|\.wav|\.m4a)(\?|$)/i.test(content);
    const prefKey = kind === "ephemeral" ? (isAudio ? (peer as unknown as { prefAudio?: string }).prefAudio : (peer as unknown as { prefImage?: string }).prefImage) : (peer as unknown as { prefDm?: string }).prefDm;
    const chk = await checkPref(prefKey, me.id, other);
    if (!chk.ok) {
      if (chk.reason === "kapalı") return Response.json({ error: kind === "ephemeral" ? "Bu kullanıcı özelden ses/görsel kabul etmiyor." : "Bu kullanıcı özel mesajları kapatmış." }, { status: 403 });
      return Response.json({ error: "Bu kullanıcı sadece dostlarından özel mesaj alıyor." }, { status: 403 });
    }
  }
  if (kind === "text") content = (await applyFilters(content, me)).text;
  const [msg] = await db.insert(privateMessages).values({ fromUserId: me.id, toUserId: other, content, kind, meta: kind === "ephemeral" ? { ttl: 5 } : {} }).returning();
  await addPoints(me.id, POINTS.dm, "ozel_mesaj");
  await db.update(users).set({ typingAt: null, piggyBank: sql`${users.piggyBank} + 1` }).where(eq(users.id, me.id));
  if (peer.isBot && peer.botKind === "nova" && peer.botEnabled && kind === "text") {
    const reply = await novaReply(content, me.username);
    await db.insert(privateMessages).values({ fromUserId: peer.id, toUserId: me.id, content: reply });
  }
  return Response.json({ message: msg });
}
