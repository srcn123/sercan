import { db } from "@/db";
import { friendships, users } from "@/db/schema";
import { checkPref } from "@/lib/privacy";
import { getCurrentUser, grantAchievement } from "@/lib/auth";
import { ONLINE_WINDOW_MS, levelFromXp } from "@/lib/constants";
import { and, eq, or, count } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const url = new URL(req.url);
  const forUser = Number(url.searchParams.get("user") ?? me.id);
  const rows = await db.select().from(friendships).where(or(eq(friendships.requesterId, forUser), eq(friendships.addresseeId, forUser)));
  const ids = Array.from(new Set(rows.map((r) => (r.requesterId === forUser ? r.addresseeId : r.requesterId))));
  const people = ids.length ? await db.select({ id: users.id, username: users.username, color: users.color, rank: users.rank, avatarUrl: users.avatarUrl, lastSeen: users.lastSeen, xp: users.xp, presence: users.presence, isBot: users.isBot }).from(users).where(or(...ids.map((i) => eq(users.id, i)))) : [];
  const pmap = new Map(people.map((p) => [p.id, p]));
  const since = Date.now() - ONLINE_WINDOW_MS;
  const out = rows.map((r) => {
    const pid = r.requesterId === forUser ? r.addresseeId : r.requesterId;
    const p = pmap.get(pid);
    return p ? { id: r.id, status: r.status, incoming: r.addresseeId === forUser && r.status === "pending", user: { ...p, level: levelFromXp(p.xp), online: p.isBot || p.lastSeen.getTime() > since } } : null;
  }).filter(Boolean);
  return Response.json({ friends: out });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { action, userId, id } = await req.json().catch(() => ({}));
  if (action === "request") {
    const target = Number(userId);
    if (target === me.id) return Response.json({ error: "Kendine istek gönderemezsin" }, { status: 400 });
    const [exists] = await db.select().from(friendships).where(or(and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, target)), and(eq(friendships.requesterId, target), eq(friendships.addresseeId, me.id)))).limit(1);
    if (exists) return Response.json({ error: exists.status === "accepted" ? "Zaten arkadaşsınız" : "İstek zaten gönderilmiş" }, { status: 409 });
    const [t] = await db.select({ isBot: users.isBot, prefFollow: users.prefFollow }).from(users).where(eq(users.id, target)).limit(1);
    if (!t) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
    if (!t.isBot) {
      const chk = await checkPref(t.prefFollow, me.id, target);
      if (!chk.ok) {
        if (chk.reason === "kapalı") return Response.json({ error: "Bu kullanıcı takip isteklerini kapatmış." }, { status: 403 });
        return Response.json({ error: "Bu kullanıcıya takip isteği gönderemezsin." }, { status: 403 });
      }
    }
    await db.insert(friendships).values({ requesterId: me.id, addresseeId: target, status: t.isBot ? "accepted" : "pending" });
    return Response.json({ ok: true, accepted: t.isBot });
  }
  const [f] = await db.select().from(friendships).where(eq(friendships.id, Number(id))).limit(1);
  if (!f || (f.requesterId !== me.id && f.addresseeId !== me.id)) return Response.json({ error: "Bulunamadı" }, { status: 404 });
  if (action === "accept" && f.addresseeId === me.id) {
    await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, f.id));
    for (const uid of [f.requesterId, f.addresseeId]) {
      const [{ value }] = await db.select({ value: count() }).from(friendships).where(and(eq(friendships.status, "accepted"), or(eq(friendships.requesterId, uid), eq(friendships.addresseeId, uid))));
      if (value >= 10) await grantAchievement(uid, "dost_10");
    }
    return Response.json({ ok: true });
  }
  if (action === "reject" || action === "remove") {
    await db.delete(friendships).where(eq(friendships.id, f.id));
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
}
