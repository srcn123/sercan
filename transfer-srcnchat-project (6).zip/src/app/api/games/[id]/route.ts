import { db } from "@/db";
import { miniGames, privateMessages } from "@/db/schema";
import { addPoints, getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const [g] = await db.select().from(miniGames).where(eq(miniGames.id, Number(id))).limit(1);
  if (!g || (g.player1 !== me.id && g.player2 !== me.id)) return Response.json({ error: "Oyun yok" }, { status: 404 });
  if (g.status === "done") return Response.json({ game: g });
  const b = await req.json().catch(() => ({}));
  const st = { ...(g.state as Record<string, unknown>) } as Record<string, Record<string, unknown> | unknown>;
  const key = String(me.id);
  let winnerId: number | null = null;
  let done = false;
  const other = g.player1 === me.id ? g.player2 : g.player1;
  if (g.type === "rps") {
    const moves = { ...((st.moves as Record<string, string>) ?? {}) };
    if (!["tas", "kagit", "makas"].includes(b.move)) return Response.json({ error: "Geçersiz hamle" }, { status: 400 });
    moves[key] = b.move;
    st.moves = moves;
    if (moves[String(other)]) {
      const a = moves[key], o = moves[String(other)];
      done = true;
      if (a !== o) winnerId = (a === "tas" && o === "makas") || (a === "kagit" && o === "tas") || (a === "makas" && o === "kagit") ? me.id : other;
    }
  } else if (g.type === "trivia") {
    const answers = { ...((st.answers as Record<string, number>) ?? {}) };
    answers[key] = Number(b.answer);
    st.answers = answers;
    const q = st.q as { c: number };
    if (answers[String(other)] !== undefined) {
      done = true;
      const meOk = answers[key] === q.c, otherOk = answers[String(other)] === q.c;
      if (meOk !== otherOk) winnerId = meOk ? me.id : other;
    }
  } else if (g.type === "word") {
    const guesses = { ...((st.guesses as Record<string, string[]>) ?? {}) };
    const guess = String(b.guess ?? "").toLocaleLowerCase("tr").trim();
    (guesses[key] ??= []).push(guess);
    st.guesses = guesses;
    if (guess === st.word) { done = true; winnerId = me.id; }
    else if ((guesses[key]?.length ?? 0) >= 5 && (guesses[String(other)]?.length ?? 0) >= 5) done = true;
  } else if (g.type === "truth") {
    const d = { ...((st.done as Record<string, string>) ?? {}) };
    d[key] = String(b.answer ?? "").slice(0, 200);
    st.done = d;
    if (d[String(other)]) done = true;
  }
  const [u] = await db.update(miniGames).set({ state: st as Record<string, unknown>, status: done ? "done" : "active", winnerId }).where(eq(miniGames.id, g.id)).returning();
  if (done && g.bet > 0 && winnerId) {
    const loser = winnerId === g.player1 ? g.player2 : g.player1;
    await addPoints(winnerId, g.bet, "oyun_kazan");
    await addPoints(loser, -g.bet, "oyun_kaybet");
  }
  if (done) await db.insert(privateMessages).values({ fromUserId: me.id, toUserId: other, content: winnerId ? `🏆 Oyun bitti! Kazanan: ${winnerId === me.id ? me.username : "sen"}${g.bet ? ` (+${g.bet} puan)` : ""}` : "🤝 Oyun berabere bitti!", kind: "text", meta: { gameId: g.id } });
  return Response.json({ game: u });
}
