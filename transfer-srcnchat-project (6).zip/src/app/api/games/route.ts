import { db } from "@/db";
import { miniGames, privateMessages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { TRIVIA, TRUTH_DARE, WORD_GUESS } from "@/lib/constants";
import { and, desc, eq, or } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const peer = Number(new URL(req.url).searchParams.get("peer"));
  const rows = await db.select().from(miniGames).where(and(or(and(eq(miniGames.player1, me.id), eq(miniGames.player2, peer)), and(eq(miniGames.player1, peer), eq(miniGames.player2, me.id))))).orderBy(desc(miniGames.id)).limit(1);
  return Response.json({ game: rows[0] ?? null });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const type = String(b.type ?? "rps");
  const peer = Number(b.peer);
  const bet = Math.max(0, Math.min(me.points, Number(b.bet) || 0));
  let state: Record<string, unknown> = {};
  if (type === "trivia") state = { q: TRIVIA[Math.floor(Math.random() * TRIVIA.length)], answers: {} };
  else if (type === "word") { const w = WORD_GUESS[Math.floor(Math.random() * WORD_GUESS.length)]; state = { word: w, hint: w[0] + "_".repeat(w.length - 1), guesses: {} }; }
  else if (type === "truth") state = { prompt: Math.random() < 0.5 ? { kind: "Doğruluk", text: TRUTH_DARE.truth[Math.floor(Math.random() * TRUTH_DARE.truth.length)] } : { kind: "Cesaret", text: TRUTH_DARE.dare[Math.floor(Math.random() * TRUTH_DARE.dare.length)] }, done: {} };
  else state = { moves: {} };
  const [g] = await db.insert(miniGames).values({ type, player1: me.id, player2: peer, bet, state, status: "active" }).returning();
  await db.insert(privateMessages).values({ fromUserId: me.id, toUserId: peer, content: `🎮 ${me.username} seni ${type === "rps" ? "Taş-Kağıt-Makas" : type === "trivia" ? "Trivia" : type === "word" ? "Kelime Tahmin" : "Doğruluk mu Cesaret mi"} oyununa davet etti${bet ? ` (bahis: ${bet} puan)` : ""}!`, kind: "game", meta: { gameId: g.id, type } });
  return Response.json({ game: g });
}
