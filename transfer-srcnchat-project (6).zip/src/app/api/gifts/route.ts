import { db } from "@/db";
import { giftLog, messages, users } from "@/db/schema";
import { addPoints, getCurrentUser, grantAchievement } from "@/lib/auth";
import { GIFTS } from "@/lib/constants";
import { eq, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { giftKey, toUserId, roomId } = await req.json().catch(() => ({}));
  const gift = GIFTS.find((g) => g.key === giftKey);
  if (!gift) return Response.json({ error: "Hediye bulunamadı" }, { status: 400 });
  if (toUserId === me.id) return Response.json({ error: "Kendine hediye gönderemezsin" }, { status: 400 });
  const [target] = await db.select().from(users).where(eq(users.id, Number(toUserId))).limit(1);
  if (!target) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
  if (me.points < gift.points) return Response.json({ error: `Yetersiz puan. ${gift.name} için ${gift.points} puan gerekli, sende ${me.points} var.` }, { status: 402 });
  await addPoints(me.id, -gift.points, "hediye_gonder");
  await addPoints(target.id, Math.floor(gift.points / 2), "hediye_al");
  await db.update(users).set({ giftsSent: sql`${users.giftsSent} + 1` }).where(eq(users.id, me.id));
  await db.update(users).set({ giftsReceived: sql`${users.giftsReceived} + 1` }).where(eq(users.id, target.id));
  await db.insert(giftLog).values({ giftKey: gift.key, fromUserId: me.id, toUserId: target.id, roomId: roomId ?? null, points: gift.points });
  const first = await grantAchievement(me.id, "ilk_hediye");
  // Hediye bildirimi sadece kısa süreli toast olarak gösterilsin, chatte kalıcı mesaj olmasın (kısa süre sonra kaybolur)
  return Response.json({ ok: true, firstGift: first, points: me.points - gift.points, gift: { key: gift.key, name: gift.name, emoji: gift.emoji, from: me.username, to: target.username, points: gift.points } });
}
