import { db } from "@/db";
import { giftLog, pointLog, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { and, desc, eq, gt, sql, sum, count } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const period = new URL(req.url).searchParams.get("period") === "month" ? 30 : 7;
  const since = new Date(Date.now() - period * 86400000);
  const base = { id: users.id, username: users.username, color: users.color, avatarUrl: users.avatarUrl, rank: users.rank };
  const points = await db.select({ ...base, value: sum(pointLog.delta) }).from(pointLog).innerJoin(users, eq(pointLog.userId, users.id)).where(and(gt(pointLog.createdAt, since), gt(pointLog.delta, 0), eq(users.isBot, false))).groupBy(users.id).orderBy(desc(sum(pointLog.delta))).limit(10);
  const gifts = await db.select({ ...base, value: sum(giftLog.points) }).from(giftLog).innerJoin(users, eq(giftLog.fromUserId, users.id)).where(gt(giftLog.createdAt, since)).groupBy(users.id).orderBy(desc(sum(giftLog.points))).limit(10);
  const online = await db.select({ ...base, value: count() }).from(pointLog).innerJoin(users, eq(pointLog.userId, users.id)).where(and(gt(pointLog.createdAt, since), eq(pointLog.reason, "cevrimici"))).groupBy(users.id).orderBy(desc(count())).limit(10);
  const alltime = await db.select({ ...base, value: users.points }).from(users).where(eq(users.isBot, false)).orderBy(desc(users.points)).limit(10);
  // analytics for me
  const hourly = await db.select({ hour: sql<number>`extract(hour from ${pointLog.createdAt} at time zone 'Europe/Istanbul')::int`, value: sum(pointLog.delta) }).from(pointLog).where(and(eq(pointLog.userId, me.id), gt(pointLog.delta, 0), gt(pointLog.createdAt, since))).groupBy(sql`1`).orderBy(sql`1`);
  const giftCountries = await db.select({ country: users.country, value: count() }).from(giftLog).innerJoin(users, eq(giftLog.fromUserId, users.id)).where(eq(giftLog.toUserId, me.id)).groupBy(users.country).orderBy(desc(count())).limit(5);
  return Response.json({ points, gifts, online: online.map((o) => ({ ...o, value: Number(o.value) * 2 })), alltime, analytics: { hourly, giftCountries } });
}
