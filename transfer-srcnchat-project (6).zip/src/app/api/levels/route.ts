import { db } from "@/db";
import { users, settings } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { levelFromXp } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
async function ensureMonthReset() {
  const now = new Date();
  const curKey = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
  const [row]=await db.select().from(settings).where(eq(settings.key, "levelResetMonth")).limit(1);
  if (!row) { await db.insert(settings).values({ key: "levelResetMonth", value: curKey }).onConflictDoNothing(); return; }
  if (row.value !== curKey) {
    // reset all xp/levels
    await db.update(users).set({ xp: 0, onlineSeconds: 0, totalMessages: 0 });
    await db.update(settings).set({ value: curKey }).where(eq(settings.key, "levelResetMonth"));
  }
}
export async function GET() {
  const me = await getCurrentUser(); if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  await ensureMonthReset();
  // leaderboard by level/xp
  const all = await db.select({ id: users.id, username: users.username, color: users.color, avatarUrl: users.avatarUrl, xp: users.xp, rank: users.rank }).from(users).where(eq(users.isBot, false));
  const withLevel = all.map((u)=>({ ...u, level: levelFromXp(u.xp) })).sort((a,b)=> b.level - a.level || b.xp - a.xp).slice(0,50);
  return Response.json({ users: withLevel });
}
export async function POST() {
  const me = await getCurrentUser(); if (!me || me.rank!=="kurucu") return Response.json({ error: "Yetki yok"},{status:403});
  await db.update(users).set({ xp: 0 });
  await db.update(settings).set({ value: `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,"0")}` }).where(eq(settings.key, "levelResetMonth"));
  return Response.json({ ok: true });
}
