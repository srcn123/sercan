import { db } from "@/db";
import { settings } from "@/db/schema";
import { getCurrentUser, setSetting } from "@/lib/auth";
import { consumeLicense, normalizeKey, validateLicense } from "@/lib/licenses";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (me.rank !== "kurucu") return Response.json({ error: "Sadece Kurucu lisans girebilir" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const license = String(b.licenseKey ?? b.license ?? "").trim();
  if (!license) return Response.json({ error: "Lisans anahtarı boş" }, { status: 400 });
  // Zaten aktif lisans varsa başka aktivasyon yok
  const [cur] = await db.select().from(settings).where(eq(settings.key, "licenseKey")).limit(1);
  if (cur?.value) {
    const { licenses } = await import("@/db/schema");
    const [curRow] = await db.select().from(licenses).where(eq(licenses.key, cur.value)).limit(1);
    if (curRow && curRow.status === "active") {
      return Response.json({ error: `Zaten aktif lisans var: ${curRow.key} — aktif edildi ✓ Başka aktivasyon alamazsınız.` }, { status: 400 });
    }
  }
  const v = await validateLicense(license);
  if (!v.valid) return Response.json({ error: v.reason ?? "Geçersiz lisans" }, { status: 400 });
  await consumeLicense(license, me.username);
  await setSetting("licenseKey", normalizeKey(license));
  await setSetting("installed", "1");
  return Response.json({ ok: true, key: normalizeKey(license) });
}
export async function DELETE() {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok" }, { status: 403 });
  await db.delete(settings).where(eq(settings.key, "licenseKey"));
  return Response.json({ ok: true });
}
