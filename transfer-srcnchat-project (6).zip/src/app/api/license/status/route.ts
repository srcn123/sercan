import { db } from "@/db";
import { licenses, settings } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const [installed] = await db.select().from(settings).where(eq(settings.key, "installed")).limit(1);
  const [licenseKey] = await db.select().from(settings).where(eq(settings.key, "licenseKey")).limit(1);
  const key = licenseKey?.value ?? "";
  let license = null;
  if (key) {
    const [row] = await db.select().from(licenses).where(eq(licenses.key, key)).limit(1);
    license = row ? { key: row.key, status: row.status, isUsed: row.isUsed, usedBy: row.usedBy, usedAt: row.usedAt, expiresAt: row.expiresAt, note: row.note } : null;
  }
  const isSuspended = license?.status === "suspended";
  const isExpired = license?.status === "expired" || (license?.expiresAt && new Date(license.expiresAt) < new Date());
  return Response.json({
    installed: installed?.value === "1",
    license,
    status: !license ? "no-license" : isSuspended ? "suspended" : isExpired ? "expired" : "active",
    message: !license ? "Lisans bulunamadı" : isSuspended ? "Lisansınız askıya alındı — lütfen satıcıyla iletişime geçin" : isExpired ? "Lisans süreniz doldu" : "Lisans aktif",
  });
}
