import { db } from "@/db";
import { settings, licenses } from "@/db/schema";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
// Herkese açık doğrulama — müşteri sitesi periyodik çağırır, şeffaf
export async function GET(req: Request) {
  const url = new URL(req.url);
  const key = url.searchParams.get("key")?.trim().toUpperCase();
  if (!key) {
    const [lic] = await db.select().from(settings).where(eq(settings.key, "licenseKey")).limit(1);
    if (!lic?.value) return Response.json({ valid: false, status: "no-license", message: "Bu kurulumda lisans yok" });
    const [row] = await db.select().from(licenses).where(eq(licenses.key, lic.value)).limit(1);
    if (!row) return Response.json({ valid: false, status: "invalid", message: "Geçersiz lisans" });
    const expired = row.expiresAt && new Date(row.expiresAt) < new Date();
    return Response.json({ valid: row.status === "active" && !expired, status: row.status, key: row.key, usedBy: row.usedBy, expiresAt: row.expiresAt, message: row.status === "active" && !expired ? "Lisans aktif" : row.status === "suspended" ? "Askıda" : "Süresi doldu" });
  }
  const [row] = await db.select().from(licenses).where(eq(licenses.key, key)).limit(1);
  if (!row) return Response.json({ valid: false, status: "invalid", message: "Geçersiz anahtar" });
  return Response.json({ valid: row.status === "active", status: row.status, key: row.key, note: row.note });
}
