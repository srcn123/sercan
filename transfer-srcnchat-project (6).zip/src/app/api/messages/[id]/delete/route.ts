import { db } from "@/db";
import { messages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { PERM, rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const [m] = await db.select().from(messages).where(eq(messages.id, Number(id))).limit(1);
  if (!m) return Response.json({ error: "Mesaj yok" }, { status: 404 });
  if (m.userId !== user.id && rankLevel(user.rank) < PERM.deleteMsg) return Response.json({ error: "Yetkin yok" }, { status: 403 });
  await db.update(messages).set({ deleted: true, content: "", meta: {} }).where(eq(messages.id, m.id));
  return Response.json({ ok: true });
}
