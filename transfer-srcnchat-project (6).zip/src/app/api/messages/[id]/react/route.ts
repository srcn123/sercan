import { db } from "@/db";
import { reactions } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { REACTION_EMOJIS } from "@/lib/constants";
import { and, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const { emoji } = await req.json().catch(() => ({}));
  if (!REACTION_EMOJIS.includes(emoji)) return Response.json({ error: "Geçersiz tepki" }, { status: 400 });
  const messageId = Number(id);
  const [exists] = await db.select().from(reactions).where(and(eq(reactions.messageId, messageId), eq(reactions.userId, user.id), eq(reactions.emoji, emoji))).limit(1);
  if (exists) await db.delete(reactions).where(eq(reactions.id, exists.id));
  else await db.insert(reactions).values({ messageId, userId: user.id, emoji });
  return Response.json({ ok: true, added: !exists });
}
