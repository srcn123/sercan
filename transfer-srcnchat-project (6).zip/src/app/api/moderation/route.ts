import { db } from "@/db";
import { bans, messages, rooms, users, activityLog } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { MUTE_DURATIONS, PERM, RANKS, rankLevel, type RankKey } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const [target] = await db.select().from(users).where(eq(users.id, Number(b.userId))).limit(1);
  if (!target) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
  const myLevel = rankLevel(me.rank);
  const tLevel = rankLevel(target.rank);
  const action = String(b.action);
  if (action !== "unban" && tLevel >= myLevel) return Response.json({ error: "Kendinden yüksek veya eşit rütbeye işlem yapamazsın." }, { status: 403 });
  const roomId = Number(b.roomId) || me.currentRoomId;
  const sys = async (text: string) => { if (roomId) await db.insert(messages).values({ roomId, username: "Sistem", color: "#64748b", rank: "admin", content: text, kind: "system" }); };
  // room owner protection
  if ((action === "kick" || action === "ban") && roomId) {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
    if (room?.ownerId === target.id && myLevel < PERM.clearRoom) return Response.json({ error: "Oda sahibini kendi odasında yalnızca Admin veya Kurucu atabilir." }, { status: 403 });
  }
  switch (action) {
    case "rank": {
      const newRank = String(b.rank) as RankKey;
      if (!(newRank in RANKS)) return Response.json({ error: "Geçersiz rütbe" }, { status: 400 });
      if (RANKS[newRank].level >= myLevel) return Response.json({ error: "Kendi rütbenden yüksek/eşit rütbe veremezsin." }, { status: 403 });
      if (target.isGuest && newRank !== "misafir") return Response.json({ error: "Misafirlere rütbe verilemez, önce kayıt olmalılar." }, { status: 400 });
      await db.update(users).set({ rank: newRank }).where(eq(users.id, target.id));
      await sys(`👑 ${target.username} artık ${RANKS[newRank].label} (veren: ${me.username})`);
      return Response.json({ ok: true });
    }
    case "mute": {
      if (myLevel < PERM.mute) return Response.json({ error: "Yetkin yok" }, { status: 403 });
      const mins = MUTE_DURATIONS.some((d) => d.minutes === Number(b.minutes)) ? Number(b.minutes) : 5;
      await db.update(users).set({ mutedUntil: new Date(Date.now() + mins * 60000) }).where(eq(users.id, target.id));
      await sys(`🔇 ${target.username}, ${me.username} tarafından ${mins >= 1440 ? "1 gün" : mins + " dk"} susturuldu.`);
      return Response.json({ ok: true });
    }
    case "unmute": {
      await db.update(users).set({ mutedUntil: null }).where(eq(users.id, target.id));
      await sys(`🔊 ${target.username} susturulması ${me.username} tarafından açıldı — sohbetine devam edebilir.`);
      return Response.json({ ok: true });
    }
    case "kick": {
      if (myLevel < PERM.kick) return Response.json({ error: "Yetkin yok" }, { status: 403 });
      await db.update(users).set({ kickedAt: new Date(), currentRoomId: null }).where(eq(users.id, target.id));
      await db.insert(activityLog).values({ userId: target.id, username: target.username, ip: target.lastIp ?? "", action: "kick" });
      await sys(`👢 ${target.username}, ${me.username} tarafından odadan atıldı.`);
      return Response.json({ ok: true });
    }
    case "ban": {
      if (myLevel < PERM.ban) return Response.json({ error: "Yetkin yok" }, { status: 403 });
      await db.update(users).set({ isBanned: true, currentRoomId: null }).where(eq(users.id, target.id));
      await db.insert(bans).values({ userId: target.id, username: target.username, ip: b.withIp ? target.lastIp : null, reason: String(b.reason ?? "").slice(0, 160), byUsername: me.username });
      await db.insert(activityLog).values({ userId: target.id, username: target.username, ip: target.lastIp ?? "", action: "ban" });
      await sys(`🚫 ${target.username} siteden yasaklandı.`);
      return Response.json({ ok: true });
    }
    case "unban": {
      if (myLevel < PERM.ban) return Response.json({ error: "Yetkin yok" }, { status: 403 });
      await db.update(users).set({ isBanned: false, violations: 0, mutedUntil: null }).where(eq(users.id, target.id));
      await db.update(bans).set({ active: false }).where(eq(bans.userId, target.id));
      return Response.json({ ok: true });
    }
    case "dj": {
      if (me.rank !== "kurucu") return Response.json({ error: "DJ yetkisini yalnızca Kurucu verir." }, { status: 403 });
      await db.update(users).set({ isDj: !!b.value }).where(eq(users.id, target.id));
      await sys(b.value ? `🎧 ${target.username} artık DJ!` : `${target.username} DJ yetkisi alındı.`);
      return Response.json({ ok: true });
    }
  }
  return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
}
