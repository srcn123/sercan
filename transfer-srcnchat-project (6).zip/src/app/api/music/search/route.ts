import { getCurrentUser } from "@/lib/auth";
export const dynamic = "force-dynamic";

async function ytSearch(q: string) {
  // try multiple public Piped + Invidious mirrors — all return full YouTube results
  const enc = encodeURIComponent(q);
  const candidates: string[] = [
    `https://pipedapi.kavin.rocks/search?q=${enc}`,
    `https://pipedapi.adminforge.de/search?q=${enc}`,
    `https://api.piped.private.coffee/search?q=${enc}`,
    `https://pipedapi.syncpundit.io/search?q=${enc}`,
    `https://inv.nadeko.net/api/v1/search?q=${enc}`,
    `https://yt.artemislena.eu/api/v1/search?q=${enc}`,
    `https://invidious.nerdvpn.de/api/v1/search?q=${enc}`,
  ];
  for (const url of candidates) {
    try {
      const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 3000);
      const r = await fetch(url, { signal: ctrl.signal, headers: { "User-Agent": "SrcnChat/1.0" } });
      clearTimeout(t);
      if (!r.ok) continue;
      const d = await r.json();
      const items = (Array.isArray(d) ? d : d.items ?? d) as {
        type?: string; title?: string; name?: string; uploaderName?: string; author?: string; uploader?: string;
        url?: string; videoId?: string; id?: string; videoId2?: string;
        thumbnail?: string; thumbnails?: { url: string }[]; duration?: number; lengthSeconds?: number;
      }[];
      const vids = items
        .filter((x) => {
          const t = (x.type ?? "").toLowerCase();
          return t === "stream" || t === "video" || t === "short" || (!t && (x.url?.startsWith("/watch") || x.videoId || x.id));
        })
        .slice(0, 8)
        .map((x) => {
          const vid = (x.url?.split("v=")[1]?.split("&")[0]) ?? x.videoId ?? x.id ?? "";
          if (!vid || vid.length < 5) return null;
          const secs = (x.duration ?? x.lengthSeconds ?? 0) as number;
          return {
            title: (x.title ?? x.name ?? "Bilinmeyen") as string,
            artist: (x.uploaderName ?? x.author ?? x.uploader ?? "") as string,
            youtubeId: vid,
            artwork: (x.thumbnail ?? x.thumbnails?.[0]?.url ?? `https://img.youtube.com/vi/${vid}/mqdefault.jpg`) as string,
            duration: secs ? `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, "0")}` : undefined,
          };
        })
        .filter(Boolean) as { title: string; artist: string; youtubeId: string; artwork?: string; duration?: string }[];
      if (vids.length) return vids;
    } catch {}
  }
  return [];
}
async function itunesSearch(q: string) {
  try {
    const r = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&limit=4&country=tr`);
    if (!r.ok) return [];
    const d = await r.json();
    return (d.results ?? []).map((x: { trackName: string; artistName: string; previewUrl: string; artworkUrl100: string; trackTimeMillis: number }) => ({
      title: x.trackName, artist: x.artistName, youtubeId: "", previewUrl: x.previewUrl, artwork: x.artworkUrl100?.replace("100x100","300x300"), duration: x.trackTimeMillis ? `${Math.floor(x.trackTimeMillis/60000)}:${String(Math.floor((x.trackTimeMillis%60000)/1000)).padStart(2,"0")}` : undefined
    }));
  } catch { return []; }
}
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const q = new URL(req.url).searchParams.get("q")?.trim() ?? "";
  if (q.length < 2) return Response.json({ results: [] });
  let results = await ytSearch(q);
  if (!results.length) results = await itunesSearch(q);
  return Response.json({ results });
}
