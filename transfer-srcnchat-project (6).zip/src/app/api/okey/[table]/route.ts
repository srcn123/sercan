import { db } from "@/db";
import { okeyTables, users } from "@/db/schema";
import { addPoints, getCurrentUser, grantAchievement } from "@/lib/auth";
import { OKEY_TABLE_COUNT, POINTS, rankLevel } from "@/lib/constants";
import { arrange, autoArrange, discard, draw, emptyState, finish, normalize, startGame, viewFor, type OkeyState } from "@/lib/okey";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ table: string }> };
async function load(id: number): Promise<OkeyState> {
  const [row] = await db.select().from(okeyTables).where(eq(okeyTables.id, id)).limit(1);
  return normalize((row?.state ?? {}) as Record<string, unknown>);
}
async function save(id: number, s: OkeyState) {
  await db.insert(okeyTables).values({ id, state: s as unknown as Record<string, unknown>, updatedAt: new Date() }).onConflictDoUpdate({ target: okeyTables.id, set: { state: s as unknown as Record<string, unknown>, updatedAt: new Date() } });
}
export async function GET(_: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { table } = await ctx.params;
  const id = Number(table);
  if (id === 0) {
    const all = await db.select().from(okeyTables);
    return Response.json({ tables: Array.from({ length: OKEY_TABLE_COUNT }, (_, i) => { const s = normalize((all.find((t) => t.id === i + 1)?.state ?? {}) as Record<string, unknown>); return { id: i + 1, players: s.seats.filter(Boolean).map((p) => p!.username), phase: s.phase, spectators: s.spectators.length }; }) });
  }
  const s = await load(id);
  if (!s.spectators.includes(me.id) && !s.seats.some((x) => x?.userId === me.id)) { s.spectators.push(me.id); await save(id, s); }
  return Response.json({ state: viewFor(s, me.id) });
}
export async function POST(req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { table } = await ctx.params;
  const id = Number(table);
  const b = await req.json().catch(() => ({}));
  let s = await load(id);
  const seat = s.seats.findIndex((x) => x?.userId === me.id);
  try {
    switch (b.action) {
      case "sit": {
        const i = Number(b.seat);
        if (seat >= 0) throw new Error("Zaten masadasın");
        if (s.seats[i]) throw new Error("Koltuk dolu");
        if (s.phase === "playing") throw new Error("Oyun devam ediyor, bitmesini bekle");
        s.seats[i] = { userId: me.id, username: me.username, color: me.color, rack: Array(26).fill(null), drawn: false };
        s.spectators = s.spectators.filter((x) => x !== me.id);
        break;
      }
      case "leave": {
        if (seat < 0) throw new Error("Masada değilsin");
        s.seats[seat] = null;
        if (s.phase === "playing") { s.phase = "finished"; s.log.push(`${me.username} masadan kalktı, oyun bitti.`); }
        break;
      }
      case "start": if (seat < 0) throw new Error("Önce otur"); s = startGame(s); break;
      case "draw": s = draw(s, seat, b.from === "left" ? "left" : "middle"); break;
      case "discard": s = discard(s, seat, Number(b.tileId)); break;
      case "arrange": s = arrange(s, seat, b.rack ?? []); break;
      case "auto": { if (seat < 0) throw new Error("Masada değilsin"); s.seats[seat]!.rack = autoArrange(s.seats[seat]!.rack, b.mode === "cift" ? "cift" : "seri", s.okey); break; }
      case "finish": {
        s = finish(s, seat, Number(b.tileId));
        const pairs = s.winner?.pairs;
        await addPoints(me.id, pairs ? POINTS.okeyPairWin : POINTS.okeyWin, pairs ? "okey_cift" : "okey_bitir");
        await grantAchievement(me.id, "okey_kazan");
        break;
      }
      case "chat": { s.chat = [...s.chat.slice(-30), { user: me.username, text: String(b.text ?? "").slice(0, 200), t: Date.now() }]; break; }
      case "reset": {
        if (seat < 0 && rankLevel(me.rank) < 3) throw new Error("Yetkin yok");
        s = { ...s, ...emptyState(), seats: s.seats.map((x) => (x ? { ...x, rack: Array(26).fill(null), drawn: false } : null)), spectators: s.spectators, chat: s.chat, log: ["Masa sıfırlandı"] };
        break;
      }
      case "destroy": { if (rankLevel(me.rank) < 3 && seat < 0) throw new Error("Yetkin yok"); s = emptyState(); s.log = ["Masa bozuldu"]; break; }
      default: throw new Error("Geçersiz işlem");
    }
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 400 });
  }
  await save(id, s);
  await db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, me.id));
  return Response.json({ state: viewFor(s, me.id) });
}
