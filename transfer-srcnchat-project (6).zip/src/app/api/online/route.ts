import { db } from "@/db";
import { friendships, privateMessages, settings, users } from "@/db/schema";
import { addPoints, getCurrentUser, getSettings } from "@/lib/auth";
import { ONLINE_WINDOW_MS, POINTS, RANK_ORDER, levelFromXp } from "@/lib/constants";
import { and, count, eq, gt, or, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  // ay sonu level sıfırlama — her çağrıda kontrol et
  try {
    const curKey = `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,"0")}`;
    const [row] = await db.select().from(settings).where(eq(settings.key, "levelResetMonth")).limit(1);
    if (row && row.value !== curKey) {
      await db.update(users).set({ xp: 0 });
      await db.update(settings).set({ value: curKey }).where(eq(settings.key, "levelResetMonth"));
    } else if (!row) {
      await db.insert(settings).values({ key: "levelResetMonth", value: curKey }).onConflictDoNothing();
    }
  } catch {}
  // presence tick + points every 2 minutes
  const now = Date.now();
  const tick = me.lastPointTickAt?.getTime() ?? 0;
  const patch: Partial<typeof users.$inferInsert> = { lastSeen: new Date() };
  if (now - tick >= 120000) {
    patch.lastPointTickAt = new Date();
    if (tick && now - tick < 10 * 60000) {
      patch.onlineSeconds = sql`${users.onlineSeconds} + 120` as unknown as number;
      await addPoints(me.id, POINTS.onlineTick, "cevrimici");
    }
  }
  await db.update(users).set(patch).where(eq(users.id, me.id));
  const since = new Date(now - ONLINE_WINDOW_MS);
  const rows = await db.select({ id: users.id, username: users.username, color: users.color, nickColor: users.nickColor, rank: users.rank, isGuest: users.isGuest, isBot: users.isBot, isDj: users.isDj, isVerified: users.isVerified, status: users.status, presence: users.presence, mood: users.mood, avatarUrl: users.avatarUrl, avatarFrame: users.avatarFrame, nickEffect: users.nickEffect, textStyle: users.textStyle, gender: users.gender, currentRoomId: users.currentRoomId, cameraOn: users.cameraOn, ghostMode: users.ghostMode, xp: users.xp, country: users.country, mutedUntil: users.mutedUntil, prefDm: users.prefDm, prefVideo: users.prefVideo, prefFollow: users.prefFollow }).from(users).where(and(or(gt(users.lastSeen, since), eq(users.isBot, true)), eq(users.isBanned, false), or(eq(users.ghostMode, false), eq(users.id, me.id))));
  rows.sort((a, b) => RANK_ORDER.indexOf(a.rank as never) - RANK_ORDER.indexOf(b.rank as never) || a.username.localeCompare(b.username, "tr"));
  const unread = await db.select({ from: privateMessages.fromUserId, value: count() }).from(privateMessages).where(and(eq(privateMessages.toUserId, me.id), eq(privateMessages.isRead, false))).groupBy(privateMessages.fromUserId);
  const pending = await db.select({ value: count() }).from(friendships).where(and(eq(friendships.addresseeId, me.id), eq(friendships.status, "pending")));
  const [fresh] = await db.select({ points: users.points, xp: users.xp, mutedUntil: users.mutedUntil, kickedAt: users.kickedAt, isBanned: users.isBanned, piggyBank: users.piggyBank, rank: users.rank, isDj: users.isDj }).from(users).where(eq(users.id, me.id));
  const s = await getSettings();
  let nowPlaying: unknown = null;
  try { nowPlaying = s.nowPlaying ? JSON.parse(s.nowPlaying) : null; } catch {}
  return Response.json({
    users: rows.map((r) => ({ ...r, level: levelFromXp(r.xp), mutedUntil: r.mutedUntil && r.mutedUntil.getTime() > now ? r.mutedUntil : null })),
    unread: Object.fromEntries(unread.map((u) => [u.from, u.value])),
    pendingFriends: pending[0]?.value ?? 0,
    me: { ...fresh, level: levelFromXp(fresh.xp), kicked: !!fresh.kickedAt && now - fresh.kickedAt.getTime() < 10 * 60000 },
    announcement: s.announcement ?? "",
    radio: { enabled: s.radioEnabled === "1", station: s.radioStation, customUrl: s.customRadioUrl },
    nowPlaying,
  });
}
