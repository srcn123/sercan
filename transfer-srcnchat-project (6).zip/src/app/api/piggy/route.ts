import { db } from "@/db";
import { users } from "@/db/schema";
import { addPoints, getCurrentUser } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (me.piggyBank < 20) return Response.json({ error: "Kumbarada en az 20 bonus puan birikmeli." }, { status: 400 });
  const isVip = rankLevel(me.rank) >= 2;
  const fee = isVip ? 0 : Math.ceil(me.piggyBank * 0.25);
  if (!isVip && me.points < fee) return Response.json({ error: `Kumbarayı açmak için ${fee} puan (veya VIP üyelik) gerekli.` }, { status: 402 });
  const gained = me.piggyBank;
  await db.update(users).set({ piggyBank: 0 }).where(eq(users.id, me.id));
  await addPoints(me.id, gained - fee, "kumbara");
  return Response.json({ ok: true, gained, fee });
}
