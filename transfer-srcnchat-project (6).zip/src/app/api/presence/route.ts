import { getCurrentUser, touchPresence } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  await touchPresence(user.id, typeof body.roomId === "number" ? body.roomId : undefined);
  return Response.json({ ok: true });
}
