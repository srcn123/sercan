import { db } from "@/db";
import { messages, rooms, users } from "@/db/schema";
import { ONLINE_WINDOW_MS } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
import { and, count, desc, eq, gt, isNull } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  await ensureSeed();
  const [lobby] = await db.select().from(rooms).where(eq(rooms.isDefault, true)).limit(1);
  const recent = lobby ? await db.select({ id: messages.id, username: messages.username, color: messages.color, content: messages.content, createdAt: messages.createdAt }).from(messages).where(and(eq(messages.roomId, lobby.id), eq(messages.deleted, false), isNull(messages.whisperTo), eq(messages.kind, "text"))).orderBy(desc(messages.id)).limit(8) : [];
  const since = new Date(Date.now() - ONLINE_WINDOW_MS);
  const [{ value: online }] = await db.select({ value: count() }).from(users).where(and(gt(users.lastSeen, since), eq(users.isBot, false)));
  const [{ value: roomCount }] = await db.select({ value: count() }).from(rooms);
  return Response.json({ messages: recent.reverse(), online, roomCount });
}
