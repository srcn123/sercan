import { db } from "@/db";
import { achievements, friendships, giftLog, users } from "@/db/schema";
import { getCurrentUser, publicUser } from "@/lib/auth";
import { and, desc, eq, or, count } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const [u] = await db.select().from(users).where(eq(users.id, Number(id))).limit(1);
  if (!u) return Response.json({ error: "Kullanıcı yok" }, { status: 404 });
  const gifts = await db.select({ giftKey: giftLog.giftKey, from: users.username, createdAt: giftLog.createdAt }).from(giftLog).leftJoin(users, eq(giftLog.fromUserId, users.id)).where(eq(giftLog.toUserId, u.id)).orderBy(desc(giftLog.id)).limit(30);
  const ach = await db.select({ key: achievements.key, earnedAt: achievements.earnedAt }).from(achievements).where(eq(achievements.userId, u.id));
  const [{ value: friendCount }] = await db.select({ value: count() }).from(friendships).where(and(eq(friendships.status, "accepted"), or(eq(friendships.requesterId, u.id), eq(friendships.addresseeId, u.id))));
  const [rel] = await db.select().from(friendships).where(or(and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, u.id)), and(eq(friendships.requesterId, u.id), eq(friendships.addresseeId, me.id)))).limit(1);
  return Response.json({ user: { ...publicUser(u), lastSeen: u.lastSeen, isBanned: u.isBanned, violations: u.violations }, gifts, achievements: ach, friendCount, relation: rel ? { id: rel.id, status: rel.status, incoming: rel.addresseeId === me.id } : null });
}
