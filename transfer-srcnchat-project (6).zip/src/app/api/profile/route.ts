import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, grantAchievement, publicUser, verifyPassword, hashPassword } from "@/lib/auth";
import { AVATAR_COLORS, THEMES, rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function PATCH(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const patch: Partial<typeof users.$inferInsert> = {};
  if (typeof b.color === "string" && (AVATAR_COLORS as readonly string[]).includes(b.color)) patch.color = b.color;
  if (typeof b.theme === "string" && THEMES.some((t) => t.key === b.theme)) patch.theme = b.theme;
  if (typeof b.status === "string") patch.status = b.status.trim().slice(0, 80);
  if (typeof b.presence === "string" && ["online", "busy", "away"].includes(b.presence)) patch.presence = b.presence;
  if (typeof b.nickColor === "string") patch.nickColor = /^#[0-9a-f]{6}$/i.test(b.nickColor) ? b.nickColor : null;
  if (b.textStyle && typeof b.textStyle === "object") patch.textStyle = { color: /^#[0-9a-f]{6}$/i.test(b.textStyle.color ?? "") ? b.textStyle.color : undefined, bold: !!b.textStyle.bold, italic: !!b.textStyle.italic, neon: !!b.textStyle.neon, gradient: typeof b.textStyle.gradient === "string" ? b.textStyle.gradient.slice(0,80) : undefined, animation: typeof b.textStyle.animation === "string" ? b.textStyle.animation.slice(0,20) : undefined, };
  if (typeof b.nickEffect === "string") (patch as Record<string,unknown>).nickEffect = b.nickEffect.slice(0,20);
  if (typeof b.avatarFrame === "string") (patch as Record<string,unknown>).avatarFrame = b.avatarFrame.slice(0,20);
  if (typeof b.gender === "string" && ["", "kadin", "erkek", "diger"].includes(b.gender)) (patch as Record<string,unknown>).gender = b.gender;
  for (const k of ["prefDm", "prefVoice", "prefVideo", "prefAudio", "prefImage", "prefFollow", "prefNotif"] as const) {
    if (typeof b[k] === "string" && ["everyone", "friends", "nobody"].includes(b[k])) (patch as Record<string, unknown>)[k] = b[k];
  }
  for (const k of ["country", "city", "mood"] as const) if (typeof b[k] === "string") patch[k] = b[k].trim().slice(0, 40);
  if (typeof b.about === "string") patch.about = b.about.trim().slice(0, 300);
  if (typeof b.avatarUrl === "string") patch.avatarUrl = b.avatarUrl.slice(0, 400000) || null;
  if (typeof b.bannerUrl === "string") patch.bannerUrl = b.bannerUrl.slice(0, 600000) || null;
  if (typeof b.ghostMode === "boolean") {
    if (rankLevel(me.rank) < 2) return Response.json({ error: "Hayalet modu VIP ve üstü içindir." }, { status: 403 });
    patch.ghostMode = b.ghostMode;
  }
  if (b.verify === true) {
    patch.isVerified = true;
    if (typeof b.selfie === "string" && !me.avatarUrl) patch.avatarUrl = b.selfie.slice(0, 400000);
    await grantAchievement(me.id, "dogrulandi");
  }
  if (typeof b.newPassword === "string") {
    if (!verifyPassword(String(b.currentPassword ?? ""), me.passwordHash)) return Response.json({ error: "Mevcut şifre hatalı." }, { status: 401 });
    if (b.newPassword.length < 4) return Response.json({ error: "Yeni şifre en az 4 karakter." }, { status: 400 });
    patch.passwordHash = hashPassword(b.newPassword);
  }
  if (Object.keys(patch).length === 0) return Response.json({ user: publicUser(me) });
  const [updated] = await db.update(users).set(patch).where(eq(users.id, me.id)).returning();
  return Response.json({ user: publicUser(updated) });
}
