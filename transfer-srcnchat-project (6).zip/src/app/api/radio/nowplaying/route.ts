import { getCurrentUser, getSettings } from "@/lib/auth";
import { announceRadioTrack, fetchRadioNowPlaying } from "@/lib/bots";
import { RADIO_STATIONS } from "@/lib/constants";
export const dynamic = "force-dynamic";
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const s = await getSettings();
  const st = RADIO_STATIONS.find((x) => x.id === s.radioStation);
  if (!st || s.radioEnabled !== "1") return Response.json({ track: null });
  const track = await fetchRadioNowPlaying(st.np);
  if (track) await announceRadioTrack(track);
  return Response.json({ track, station: st.name });
}
