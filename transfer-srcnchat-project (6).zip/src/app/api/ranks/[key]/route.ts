import { db } from "@/db";
import { ranks } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function PATCH(req: Request, ctx: { params: Promise<{ key: string }> }) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok — sadece Kurucu" }, { status: 403 });
  const { key } = await ctx.params;
  const b = await req.json().catch(()=>({}));
  const [existing] = await db.select().from(ranks).where(eq(ranks.key, key)).limit(1);
  if (!existing) return Response.json({ error: "Rütbe yok" }, { status: 404 });
  const patch: Record<string, unknown> = {};
  if (typeof b.label === "string" && b.label.trim()) patch.label = b.label.trim().slice(0,30);
  if (typeof b.level === "number" || typeof b.level === "string") patch.level = Math.max(0, Math.min(100, Number(b.level)));
  if (typeof b.color === "string" && /^#[0-9a-fA-F]{6}$/.test(b.color)) patch.color = b.color;
  if (typeof b.icon === "string" && b.icon.trim()) patch.icon = b.icon.trim().slice(0,4);
  if (b.perms && typeof b.perms === "object") patch.perms = b.perms;
  if (typeof b.sprite === "number") patch.sprite = b.sprite;
  if (!Object.keys(patch).length) return Response.json({ error: "Değişiklik yok" }, { status: 400 });
  const [updated] = await db.update(ranks).set(patch).where(eq(ranks.key, key)).returning();
  return Response.json({ rank: updated });
}
export async function DELETE(_: Request, ctx: { params: Promise<{ key: string }> }) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok — sadece Kurucu" }, { status: 403 });
  const { key } = await ctx.params;
  const [existing] = await db.select().from(ranks).where(eq(ranks.key, key)).limit(1);
  if (!existing) return Response.json({ error: "Yok" }, { status: 404 });
  if (existing.isSystem) return Response.json({ error: "Sistem rütbesi silinemez" }, { status: 400 });
  await db.delete(ranks).where(eq(ranks.key, key));
  return Response.json({ ok: true });
}
