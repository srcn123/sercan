import { db } from "@/db";
import { getCurrentUser, setSetting } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok — sadece Kurucu" }, { status: 403 });
  const { pack } = await req.json().catch(()=>({}));
  const allowed = ["pack1","pack2","pack3","pack4","pack5"];
  if (!allowed.includes(pack)) return Response.json({ error: "Geçersiz paket" }, { status: 400 });
  await setSetting("rankPack", pack);
  return Response.json({ ok: true, pack });
}
export async function GET() {
  const { getSetting } = await import("@/lib/auth");
  const pack = await getSetting("rankPack", "pack1");
  return Response.json({ pack });
}
