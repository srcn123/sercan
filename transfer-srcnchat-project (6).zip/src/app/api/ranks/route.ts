import { db } from "@/db";
import { ranks } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
import { asc, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET() {
  const list = await db.select().from(ranks).orderBy(asc(ranks.level));
  const { getSetting } = await import("@/lib/auth");
  const pack = await getSetting("rankPack", "pack1");
  return Response.json({ ranks: list.sort((a,b) => b.level - a.level), pack });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok - sadece Kurucu" }, { status: 403 });
  const b = await req.json().catch(()=>({}));
  const key = String(b.key ?? "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0,20);
  const label = String(b.label ?? "").trim().slice(0,30);
  if (!key || !label) return Response.json({ error: "Key ve etiket zorunlu" }, { status: 400 });
  if (key.length < 2) return Response.json({ error: "Key en az 2 karakter" }, { status: 400 });
  const level = Math.max(0, Math.min(100, Number(b.level) || 0));
  const color = String(b.color || "#94a3b8").slice(0,16);
  const icon = String(b.icon || "●").slice(0,4);
  const perms = (b.perms && typeof b.perms === "object") ? b.perms : {};
  const [exists] = await db.select().from(ranks).where(eq(ranks.key, key)).limit(1);
  if (exists) return Response.json({ error: "Bu anahtar zaten var" }, { status: 409 });
  const [created] = await db.insert(ranks).values({ key, label, level, color, icon, sprite: listLength(), perms }).returning();
  return Response.json({ rank: created });
  function listLength() { return 0; }
}
