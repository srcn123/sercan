import { db } from "@/db";
import { ranks } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || me.rank !== "kurucu") return Response.json({ error: "Yetki yok — sadece Kurucu" }, { status: 403 });
  const form = await req.formData();
  const file = form.get("file") as File | null;
  const key = String(form.get("rank") ?? "").trim();
  if (!file || !key) return Response.json({ error: "Dosya ve rütbe gerekli" }, { status: 400 });
  if (file.size > 2_000_000) return Response.json({ error: "Dosya çok büyük (max 2MB)" }, { status: 400 });
  const buf = Buffer.from(await file.arrayBuffer());
  const b64 = `data:${file.type};base64,${buf.toString("base64")}`;
  const [existing] = await db.select().from(ranks).where(eq(ranks.key, key)).limit(1);
  if (!existing) return Response.json({ error: "Rütbe yok" }, { status: 404 });
  await db.update(ranks).set({ iconUrl: b64 } as unknown as Record<string, unknown>).where(eq(ranks.key, key));
  return Response.json({ ok: true });
}
