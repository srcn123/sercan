import { db } from "@/db";
import { messages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { PERM, rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user || rankLevel(user.rank) < PERM.clearRoom) return Response.json({ error: "Yetkin yok" }, { status: 403 });
  const { id } = await ctx.params;
  await db.delete(messages).where(eq(messages.roomId, Number(id)));
  await db.insert(messages).values({ roomId: Number(id), username: "Sistem", color: "#64748b", rank: "admin", content: `🧹 Oda geçmişi ${user.username} tarafından temizlendi.`, kind: "system" });
  return Response.json({ ok: true });
}
