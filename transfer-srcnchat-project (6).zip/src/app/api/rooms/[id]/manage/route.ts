import { db } from "@/db";
import { rooms } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { rankLevel } from "@/lib/constants";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };
export async function PATCH(req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const roomId = Number(id);
  const [room] = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  if (!room) return Response.json({ error: "Oda yok" }, { status: 404 });
  const isOwner = room.ownerId === me.id;
  const isKurucu = me.rank === "kurucu";
  const isAdmin = rankLevel(me.rank) >= 5;
  if (!isOwner && !isKurucu && !isAdmin) return Response.json({ error: "Sadece oda sahibi veya Kurucu düzenleyebilir" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};
  if (typeof b.name === "string" && b.name.trim().length >= 2 && b.name.trim().length <= 40) patch.name = b.name.trim();
  if (typeof b.description === "string") patch.description = b.description.slice(0, 160);
  if (typeof b.icon === "string" && b.icon.trim()) patch.icon = b.icon.trim().slice(0, 8);
  if (typeof b.imageUrl === "string") patch.imageUrl = b.imageUrl.slice(0, 600000) || null;
  if (typeof b.bgUrl === "string") patch.bgUrl = b.bgUrl.slice(0, 600000) || null;
  if (isKurucu && (b.ownerId === null || typeof b.ownerId === "number")) patch.ownerId = b.ownerId;
  if (isOwner && typeof b.ownerId === "number" && b.ownerId !== me.id) {
    // owner can transfer to another user (only Kurucu could originally, but owner can give away)
    patch.ownerId = b.ownerId;
  }
  if (Object.keys(patch).length === 0) return Response.json({ error: "Değişiklik yok" }, { status: 400 });
  const [updated] = await db.update(rooms).set(patch).where(eq(rooms.id, roomId)).returning();
  return Response.json({ room: updated });
}
export async function GET(_: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const [room] = await db.select().from(rooms).where(eq(rooms.id, Number(id))).limit(1);
  if (!room) return Response.json({ error: "Oda yok" }, { status: 404 });
  const canEdit = room.ownerId === me.id || me.rank === "kurucu" || rankLevel(me.rank) >= 5;
  return Response.json({ room, canEdit });
}
