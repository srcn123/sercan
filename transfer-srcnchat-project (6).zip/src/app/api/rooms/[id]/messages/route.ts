import { db } from "@/db";
import { messages, reactions, rooms, users } from "@/db/schema";
import { addPoints, getCurrentUser, grantAchievement, isMuted, touchPresence } from "@/lib/auth";
import { applyFilters, checkFlood, handleBots, punish, translateText } from "@/lib/bots";
import { POINTS, RANKS, RANK_ORDER, rankLevel, PERM, MUTE_DURATIONS, type RankKey } from "@/lib/constants";
import { and, asc, desc, eq, gt, inArray, or, isNull, sql, lt } from "drizzle-orm";
export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };

async function withReactions(rows: (typeof messages.$inferSelect)[]) {
  if (!rows.length) return [];
  const ids = rows.map((r) => r.id);
  const rx = await db.select().from(reactions).where(inArray(reactions.messageId, ids));
  const map = new Map<number, Record<string, number[]>>();
  for (const r of rx) {
    const m = map.get(r.messageId) ?? {};
    (m[r.emoji] ??= []).push(r.userId);
    map.set(r.messageId, m);
  }
  return rows.map((r) => ({ ...r, reactions: map.get(r.id) ?? {} }));
}

export async function GET(req: Request, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (user.kickedAt && Date.now() - user.kickedAt.getTime() < 10 * 60000) return Response.json({ error: "kicked" }, { status: 403 });
  const { id } = await ctx.params;
  const roomId = Number(id);
  if (!Number.isInteger(roomId)) return Response.json({ error: "Geçersiz oda" }, { status: 400 });
  const url = new URL(req.url);
  const after = Number(url.searchParams.get("after") ?? 0);
  await touchPresence(user.id, roomId);
  // 40 dakika önceki mesajları otomatik sil (her odada)
  try {
    const cutoff = new Date(Date.now() - 40 * 60 * 1000);
    await db.delete(messages).where(and(eq(messages.roomId, roomId), lt(messages.createdAt, cutoff)));
  } catch {}
  const visible = and(eq(messages.roomId, roomId), or(isNull(messages.whisperTo), eq(messages.whisperTo, user.id), eq(messages.userId, user.id)));
  const typing = await db.select({ username: users.username }).from(users).where(and(eq(users.typingTarget, `room:${roomId}`), gt(users.typingAt, sql`now() - interval '4 seconds'`), sql`${users.id} <> ${user.id}`));
  if (after > 0) {
    const rows = await db.select().from(messages).where(and(visible, gt(messages.id, after))).orderBy(asc(messages.id)).limit(200);
    // also return recently changed (deleted/reacted) ids among last 50
    const recent = await db.select().from(messages).where(and(visible, gt(messages.id, Math.max(0, after - 50)), sql`${messages.id} <= ${after}`)).orderBy(asc(messages.id));
    return Response.json({ messages: await withReactions(rows), updates: await withReactions(recent), typing: typing.map((t) => t.username) });
  }
  const rows = await db.select().from(messages).where(visible).orderBy(desc(messages.id)).limit(80);
  return Response.json({ messages: await withReactions(rows.reverse()), typing: typing.map((t) => t.username) });
}

export async function POST(req: Request, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const roomId = Number(id);
  const [room] = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  if (!room) return Response.json({ error: "Oda bulunamadı" }, { status: 404 });
  if (await isMuted(user)) return Response.json({ error: `Susturuldun. Kalan: ${Math.ceil((user.mutedUntil!.getTime() - Date.now()) / 60000)} dk` }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const raw = String(body.content ?? "").trim().slice(0, 1000);
  if (!raw) return Response.json({ error: "Boş mesaj gönderilemez." }, { status: 400 });
  if (checkFlood(user.id)) {
    await db.update(users).set({ mutedUntil: new Date(Date.now() + 60000) }).where(eq(users.id, user.id));
    return Response.json({ error: "Çok hızlı yazıyorsun (flood). 1 dakika susturuldun." }, { status: 429 });
  }

  // commands
  if (raw.startsWith("/yardim") || raw.startsWith("/yardım")) {
    return Response.json({ local: "Komutlar: /me <eylem>, /temizle, /rütbe, /fısılda <kullanıcı> <mesaj> (5 puan), /çevir <dil> <metin>, /sustur <kullanıcı> <dk>, /at <kullanıcı>, /yasakla <kullanıcı>, /tema <ad>, /zar" });
  }
  if (raw.startsWith("/rütbe") || raw.startsWith("/rutbe")) {
    return Response.json({ local: "Rütbeler: " + RANK_ORDER.map((r) => `${RANKS[r].icon} ${RANKS[r].label}`).join(" > ") + `. Senin rütben: ${RANKS[user.rank as RankKey]?.label ?? "Misafir"}` });
  }
  if (raw === "/zar") {
    const n = 1 + Math.floor(Math.random() * 6);
    const [m] = await db.insert(messages).values({ roomId, userId: user.id, username: user.username, color: user.color, rank: user.rank, avatarUrl: user.avatarUrl, content: `zar attı: 🎲 ${n}`, kind: "action" }).returning();
    return Response.json({ message: { ...m, reactions: {} } });
  }
  const modCmd = raw.match(/^\/(sustur|at|yasakla)\s+(\S+)(?:\s+(\d+))?/i);
  if (modCmd) {
    const [, cmd, targetName, minutes] = modCmd;
    const [target] = await db.select().from(users).where(eq(users.usernameLower, targetName.toLocaleLowerCase("tr"))).limit(1);
    if (!target) return Response.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });
    const need = cmd === "yasakla" ? PERM.ban : cmd === "at" ? PERM.kick : PERM.mute;
    if (rankLevel(user.rank) < need || rankLevel(target.rank) >= rankLevel(user.rank)) return Response.json({ error: "Bu işlem için yetkin yok." }, { status: 403 });
    const mins = Number(minutes) || 5;
    const allowed = MUTE_DURATIONS.some((d) => d.minutes === mins) ? mins : 5;
    const [m] = await db.insert(messages).values({ roomId, userId: null, username: "Sistem", color: "#64748b", rank: "admin", content: cmd === "sustur" ? `🔇 ${target.username}, ${user.username} tarafından ${allowed} dk susturuldu.` : cmd === "at" ? `👢 ${target.username} odadan atıldı.` : `🚫 ${target.username} yasaklandı.`, kind: "system" }).returning();
    if (cmd === "sustur") await db.update(users).set({ mutedUntil: new Date(Date.now() + allowed * 60000) }).where(eq(users.id, target.id));
    if (cmd === "at") await db.update(users).set({ kickedAt: new Date(), currentRoomId: null }).where(eq(users.id, target.id));
    if (cmd === "yasakla") await db.update(users).set({ isBanned: true }).where(eq(users.id, target.id));
    return Response.json({ message: { ...m, reactions: {} } });
  }
  const tr = raw.match(/^\/(çevir|cevir)\s+(\w{2})\s+([\s\S]+)/i);
  let content = raw;
  let kind = "text";
  let whisperTo: number | null = null;
  let meta: Record<string, unknown> = {};
  if (tr) {
    const translated = await translateText(tr[3], tr[2]);
    content = `${tr[3]}\n🌐 (${tr[2]}) ${translated}`;
    meta = { translated: true };
  }
  const wh = raw.match(/^\/(fısılda|fisilda)\s+(\S+)\s+([\s\S]+)/i);
  if (wh) {
    const [target] = await db.select().from(users).where(eq(users.usernameLower, wh[2].toLocaleLowerCase("tr"))).limit(1);
    if (!target) return Response.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });
    if (user.points < POINTS.whisperCost) return Response.json({ error: `Fısıldamak için ${POINTS.whisperCost} puan gerekli.` }, { status: 402 });
    await addPoints(user.id, -POINTS.whisperCost, "fisilti");
    content = wh[3];
    kind = "whisper";
    whisperTo = target.id;
    meta = { to: target.username };
  }
  if (content.startsWith("/me ")) {
    kind = "action";
    content = content.slice(4).trim();
  }
  // filters
  const filtered = await applyFilters(content, user);
  content = filtered.text;
  const yt = content.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
  if (yt) meta = { ...meta, youtube: yt[1] };
  const img = content.match(/https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(\?\S*)?/i);
  if (img) meta = { ...meta, image: img[0] };
  const mentions = Array.from(content.matchAll(/@([\wÇĞİÖŞÜçğıöşü.-]{2,18})/g)).map((m) => m[1]);
  if (mentions.length) meta = { ...meta, mentions };

  const enrichedStyle = { ...(user.textStyle as Record<string, unknown> ?? {}), nickEffect: (user as unknown as { nickEffect?: string }).nickEffect ?? "none", avatarFrame: (user as unknown as { avatarFrame?: string }).avatarFrame ?? "none" };
  const enrichedMeta = { ...meta, nickEffect: (user as unknown as { nickEffect?: string }).nickEffect ?? "none", avatarFrame: (user as unknown as { avatarFrame?: string }).avatarFrame ?? "none" };
  const [msg] = await db.insert(messages).values({ roomId, userId: user.id, username: user.username, color: user.nickColor || user.color, rank: user.rank, avatarUrl: user.avatarUrl, textStyle: enrichedStyle as typeof user.textStyle, content, kind, meta: enrichedMeta, whisperTo }).returning();
  await db.update(users).set({ totalMessages: sql`${users.totalMessages} + 1`, piggyBank: sql`${users.piggyBank} + 1`, lastSeen: new Date(), currentRoomId: roomId, typingAt: null }).where(eq(users.id, user.id));
  await addPoints(user.id, POINTS.roomMsg, "oda_mesaj");
  const total = user.totalMessages + 1;
  const newAch: string[] = [];
  if (total === 1 && (await grantAchievement(user.id, "ilk_mesaj"))) newAch.push("ilk_mesaj");
  if (total >= 100 && (await grantAchievement(user.id, "sohbet_100"))) newAch.push("sohbet_100");
  if (total >= 1000 && (await grantAchievement(user.id, "sohbet_1000"))) newAch.push("sohbet_1000");
  const hour = Number(new Date().toLocaleString("en-US", { hour: "numeric", hour12: false, timeZone: "Europe/Istanbul" }));
  if (hour >= 2 && hour < 5 && (await grantAchievement(user.id, "gece_kusu"))) newAch.push("gece_kusu");

  let punished: string | null = null;
  if (filtered.violation || filtered.smart) punished = await punish(user, roomId, filtered.smart ? "reklam/numara paylaşımı yasak" : "yasaklı kelime kullandın");
  if (kind === "text" && !whisperTo) await handleBots(room, { content, username: user.username, userId: user.id }, user).catch(() => {});
  return Response.json({ message: { ...msg, reactions: {} }, achievements: newAch, punished });
}
