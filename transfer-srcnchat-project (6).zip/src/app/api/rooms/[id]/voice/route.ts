import { db } from "@/db";
import { messages, voiceHolders, voiceQueue } from "@/db/schema";
import { getCurrentUser, isMuted } from "@/lib/auth";
import { and, asc, eq, lt, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };
// Kilit kuralı: mikrofonu alan bırakana kadar kimse alamaz, herkes sırayla alır.
// Kalp atışı 5sn'de bir gelir; sadece 60sn'dir sinyal alınamayan ölü tutucular otomatik düşer.
const STALE_MS = 60_000;

async function prune(roomId: number) {
  try {
    await db
      .delete(voiceQueue)
      .where(and(eq(voiceQueue.roomId, roomId), lt(voiceQueue.createdAt, sql`now() - interval '10 minutes'`)));
  } catch {}
}

async function getState(roomId: number) {
  const [holder] = await db.select().from(voiceHolders).where(eq(voiceHolders.roomId, roomId)).limit(1);
  const queue = await db
    .select({ id: voiceQueue.id, userId: voiceQueue.userId, username: voiceQueue.username, createdAt: voiceQueue.createdAt })
    .from(voiceQueue)
    .where(eq(voiceQueue.roomId, roomId))
    .orderBy(asc(voiceQueue.createdAt))
    .limit(20);
  return { holder: holder ?? null, queue };
}

async function systemMsg(roomId: number, content: string) {
  await db.insert(messages).values({
    roomId,
    userId: null,
    username: "Sistem",
    color: "#64748b",
    rank: "admin",
    content,
    kind: "system",
  });
}

export async function GET(_req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const roomId = Number(id);
  if (!Number.isInteger(roomId)) return Response.json({ error: "Geçersiz oda" }, { status: 400 });

  await prune(roomId);
  let { holder, queue } = await getState(roomId);

  // Otomatik devir: holder 25sn'dir kalp atışı göndermediyse düşmüş say
  if (holder && Date.now() - new Date(holder.updatedAt).getTime() > STALE_MS) {
    await db.delete(voiceHolders).where(eq(voiceHolders.roomId, roomId));
    await systemMsg(roomId, `🎤 ${holder.username} mikrofonu bıraktı`);
    const next = queue[0];
    if (next) {
      await db.delete(voiceQueue).where(eq(voiceQueue.id, next.id));
      await db.insert(voiceHolders).values({ roomId, userId: next.userId, username: next.username }).onConflictDoNothing();
      await systemMsg(roomId, `🎤 ${next.username} mikrofon aldı`);
    }
    ({ holder, queue } = await getState(roomId));
  }

  const amHolder = !!holder && holder.userId === me.id;
  const myPosition = queue.findIndex((q) => q.userId === me.id) + 1; // 0 = sırada değil
  return Response.json({ holder, queue, amHolder, myPosition });
}

export async function POST(req: Request, ctx: Ctx) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { id } = await ctx.params;
  const roomId = Number(id);
  if (!Number.isInteger(roomId)) return Response.json({ error: "Geçersiz oda" }, { status: 400 });
  if (await isMuted(me)) return Response.json({ error: "Susturulmuşsun, mikrofon alamazsın." }, { status: 403 });

  const body = await req.json().catch(() => ({}));
  const action = String(body.action ?? "take");
  await prune(roomId);

  let { holder, queue } = await getState(roomId);
  if (holder && Date.now() - new Date(holder.updatedAt).getTime() > STALE_MS) {
    await db.delete(voiceHolders).where(eq(voiceHolders.roomId, roomId));
    await systemMsg(roomId, `🎤 ${holder.username} mikrofonu bıraktı`);
    const next = queue[0];
    if (next) {
      await db.delete(voiceQueue).where(eq(voiceQueue.id, next.id));
      await db.insert(voiceHolders).values({ roomId, userId: next.userId, username: next.username }).onConflictDoNothing();
      await systemMsg(roomId, `🎤 ${next.username} mikrofon aldı`);
    }
    ({ holder, queue } = await getState(roomId));
  }

  if (action === "heartbeat") {
    if (holder && holder.userId === me.id) {
      await db.update(voiceHolders).set({ updatedAt: new Date() }).where(eq(voiceHolders.roomId, roomId));
    }
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: !!s.holder && s.holder.userId === me.id, myPosition: s.queue.findIndex((q) => q.userId === me.id) + 1 });
  }

  if (action === "leave") {
    await db.delete(voiceQueue).where(and(eq(voiceQueue.roomId, roomId), eq(voiceQueue.userId, me.id)));
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: !!s.holder && s.holder.userId === me.id, myPosition: 0 });
  }

  if (action === "release") {
    if (!holder || holder.userId !== me.id) return Response.json({ error: "Mikrofon sende değil." }, { status: 400 });
    await db.delete(voiceHolders).where(eq(voiceHolders.roomId, roomId));
    await systemMsg(roomId, `🎤 ${me.username} mikrofonu bıraktı`);
    const s0 = await getState(roomId);
    const next = s0.queue[0];
    if (next) {
      await db.delete(voiceQueue).where(eq(voiceQueue.id, next.id));
      await db.insert(voiceHolders).values({ roomId, userId: next.userId, username: next.username }).onConflictDoNothing();
      await systemMsg(roomId, `🎤 ${next.username} mikrofon aldı`);
    }
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: false, myPosition: 0 });
  }

  // default: take
  if (holder && holder.userId === me.id) {
    await db.update(voiceHolders).set({ updatedAt: new Date() }).where(eq(voiceHolders.roomId, roomId));
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: true, myPosition: 0 });
  }
  if (holder) {
    const pos = queue.findIndex((q) => q.userId === me.id);
    if (pos >= 0) {
      return Response.json({ holder, queue, amHolder: false, myPosition: pos + 1 });
    }
    await db.insert(voiceQueue).values({ roomId, userId: me.id, username: me.username }).onConflictDoNothing();
    // aynı kullanıcıdan çift kayıt olmasın
    await db.execute(sql`DELETE FROM voice_queue a USING voice_queue b WHERE a.room_id = ${roomId} AND a.user_id = ${me.id} AND b.room_id = ${roomId} AND b.user_id = ${me.id} AND a.id > b.id`);
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: false, myPosition: s.queue.findIndex((q) => q.userId === me.id) + 1, queued: true });
  }
  // Yarış durumu koruması: aynı anda iki kişi boş mikrofona basarsa kazanan dışında kalan sıraya girer, üzerine yazılmaz.
  await db.insert(voiceHolders).values({ roomId, userId: me.id, username: me.username }).onConflictDoNothing();
  const after = await getState(roomId);
  if (!after.holder || after.holder.userId !== me.id) {
    const pos = after.queue.findIndex((q) => q.userId === me.id);
    if (pos < 0) {
      await db.insert(voiceQueue).values({ roomId, userId: me.id, username: me.username }).onConflictDoNothing();
      await db.execute(sql`DELETE FROM voice_queue a USING voice_queue b WHERE a.room_id = ${roomId} AND a.user_id = ${me.id} AND b.room_id = ${roomId} AND b.user_id = ${me.id} AND a.id > b.id`);
    }
    const s = await getState(roomId);
    return Response.json({ ...s, amHolder: false, myPosition: s.queue.findIndex((q) => q.userId === me.id) + 1, queued: true });
  }
  await db.delete(voiceQueue).where(and(eq(voiceQueue.roomId, roomId), eq(voiceQueue.userId, me.id)));
  await systemMsg(roomId, `🎤 ${me.username} mikrofon aldı`);
  const s = await getState(roomId);
  return Response.json({ ...s, amHolder: true, myPosition: 0 });
}
