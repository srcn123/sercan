import { db } from "@/db";
import { rooms, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ONLINE_WINDOW_MS, PERM, rankLevel } from "@/lib/constants";
import { ensureSeed } from "@/lib/seed";
import { asc, count, eq, gt, and, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export function slugify(name: string) {
  const map: Record<string, string> = { ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u", İ: "i" };
  return name.toLocaleLowerCase("tr").replace(/[çğıöşüİ]/g, (c) => map[c] ?? c).replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}
export async function GET() {
  await ensureSeed();
  const since = new Date(Date.now() - ONLINE_WINDOW_MS);
  const counts = await db.select({ roomId: users.currentRoomId, value: count() }).from(users).where(and(gt(users.lastSeen, since), sql`${users.currentRoomId} is not null`, eq(users.ghostMode, false))).groupBy(users.currentRoomId);
  const countMap = new Map(counts.map((c) => [c.roomId, c.value]));
  const list = await db.select({ id: rooms.id, name: rooms.name, slug: rooms.slug, description: rooms.description, icon: rooms.icon, imageUrl: rooms.imageUrl, bgUrl: rooms.bgUrl, kind: rooms.kind, ownerId: rooms.ownerId, isDefault: rooms.isDefault, sortOrder: rooms.sortOrder, ownerName: users.username }).from(rooms).leftJoin(users, eq(rooms.ownerId, users.id)).orderBy(asc(rooms.sortOrder), asc(rooms.id));
  return Response.json({ rooms: list.map((r) => ({ ...r, online: countMap.get(r.id) ?? 0 })) });
}
export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (rankLevel(user.rank) < PERM.createRoom) return Response.json({ error: "Yeni oda yalnızca Kurucu tarafından açılabilir." }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const name = String(body.name ?? "").trim();
  if (name.length < 2 || name.length > 40) return Response.json({ error: "Oda adı 2-40 karakter olmalı." }, { status: 400 });
  const base = slugify(name) || "oda";
  let slug = base;
  for (let i = 2; i < 50; i++) {
    const [exists] = await db.select({ id: rooms.id }).from(rooms).where(eq(rooms.slug, slug)).limit(1);
    if (!exists) break;
    slug = `${base}-${i}`;
  }
  const [{ value: n }] = await db.select({ value: count() }).from(rooms);
  const [room] = await db.insert(rooms).values({ name, slug, description: String(body.description ?? "").slice(0, 160), icon: String(body.icon ?? "💬").slice(0, 8) || "💬", imageUrl: body.imageUrl || null, bgUrl: body.bgUrl || null, kind: ["chat", "ai", "radio", "okey", "music"].includes(body.kind) ? body.kind : "chat", ownerId: typeof body.ownerId === "number" ? body.ownerId : null, createdBy: user.id, sortOrder: n }).returning();
  return Response.json({ room: { ...room, online: 0 } });
}
