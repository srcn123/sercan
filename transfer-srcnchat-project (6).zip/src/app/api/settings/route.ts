import { getSettings } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
export const dynamic = "force-dynamic";
export async function GET() {
  await ensureSeed();
  const s = await getSettings();
  const { siteName, domain, seoTitle, seoDescription, logoText, logoUrl, defaultTheme, announcement, radioEnabled, radioStation, customRadioUrl, installed } = s;
  return Response.json({ siteName, domain, seoTitle, seoDescription, logoText, logoUrl, defaultTheme, announcement, radioEnabled, radioStation, customRadioUrl, installed });
}
