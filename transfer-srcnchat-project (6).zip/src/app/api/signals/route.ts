import { db } from "@/db";
import { signals, streamQuality, users } from "@/db/schema";
import { checkPref } from "@/lib/privacy";
import { getCurrentUser } from "@/lib/auth";
import { and, asc, eq, gt, lt, sql } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const after = Number(new URL(req.url).searchParams.get("after") ?? 0);
  const rows = await db.select().from(signals).where(and(eq(signals.toUserId, me.id), gt(signals.id, after))).orderBy(asc(signals.id)).limit(100);
  await db.delete(signals).where(lt(signals.createdAt, sql`now() - interval '2 minutes'`));
  return Response.json({ signals: rows });
}
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  if (b.quality) {
    await db.insert(streamQuality).values({ userId: me.id, latencyMs: Number(b.quality.latency) || 0, bitrateKbps: Number(b.quality.bitrate) || 0 }).onConflictDoUpdate({ target: streamQuality.userId, set: { latencyMs: Number(b.quality.latency) || 0, bitrateKbps: Number(b.quality.bitrate) || 0, updatedAt: new Date() } });
    return Response.json({ ok: true });
  }
  const toId = Number(b.to);
  const channel = String(b.channel ?? "cam").slice(0, 12);
  const type = String(b.type).slice(0, 12);
  if (type === "offer" && channel === "call" && Number.isInteger(toId)) {
    const [peer] = await db.select({ isBot: users.isBot, prefVideo: users.prefVideo, prefVoice: users.prefVoice }).from(users).where(eq(users.id, toId)).limit(1);
    if (peer && !peer.isBot) {
      const isVoice = (b.payload as Record<string, unknown> | undefined)?.["voiceOnly"] === true || (b.payload as Record<string, unknown> | undefined)?.["audioOnly"] === true;
      const chk = await checkPref(isVoice ? peer.prefVoice : peer.prefVideo, me.id, toId);
      if (!chk.ok) {
        if (chk.reason === "kapalı") return Response.json({ error: isVoice ? "Bu kullanıcı sesli aramaları kapatmış." : "Bu kullanıcı görüntülü aramaları kapatmış." }, { status: 403 });
        return Response.json({ error: "Bu kullanıcı sadece dostlarından arama alıyor." }, { status: 403 });
      }
    }
  }
  const [s] = await db.insert(signals).values({ fromUserId: me.id, toUserId: toId, channel, type, payload: b.payload ?? {} }).returning({ id: signals.id });
  return Response.json({ id: s.id });
}
