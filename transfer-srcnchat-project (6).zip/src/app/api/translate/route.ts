import { getCurrentUser } from "@/lib/auth";
import { translateText } from "@/lib/bots";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { text, target } = await req.json().catch(() => ({}));
  if (!text) return Response.json({ error: "Metin yok" }, { status: 400 });
  return Response.json({ translated: await translateText(String(text).slice(0, 500), String(target || "en").slice(0, 5)) });
}
