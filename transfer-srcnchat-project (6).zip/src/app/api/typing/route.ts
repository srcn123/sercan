import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { target } = await req.json().catch(() => ({}));
  await db.update(users).set({ typingAt: new Date(), typingTarget: String(target ?? "").slice(0, 20) }).where(eq(users.id, me.id));
  return Response.json({ ok: true });
}
