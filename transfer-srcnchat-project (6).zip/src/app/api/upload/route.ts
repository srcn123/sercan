import { getCurrentUser } from "@/lib/auth";
export const dynamic = "force-dynamic";
// Accepts a data URL and returns it (stored inline by caller). Validates size/type.
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  const { dataUrl } = await req.json().catch(() => ({}));
  if (typeof dataUrl !== "string" || !/^data:image\/(png|jpe?g|gif|webp);base64,/.test(dataUrl)) return Response.json({ error: "Geçersiz görsel" }, { status: 400 });
  if (dataUrl.length > 600000) return Response.json({ error: "Görsel çok büyük (maks ~450KB)" }, { status: 413 });
  return Response.json({ url: dataUrl });
}
