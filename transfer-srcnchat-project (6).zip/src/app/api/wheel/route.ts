import { db } from "@/db";
import { users, achievements } from "@/db/schema";
import { addPoints, getCurrentUser, grantAchievement } from "@/lib/auth";
import { and, count, eq } from "drizzle-orm";
export const dynamic = "force-dynamic";
export const WHEEL = [
  { label: "10 Puan", type: "points", value: 10 },
  { label: "25 Puan", type: "points", value: 25 },
  { label: "Pas", type: "none", value: 0 },
  { label: "50 Puan", type: "points", value: 50 },
  { label: "VIP 1 Gün", type: "vip", value: 1 },
  { label: "100 Puan", type: "points", value: 100 },
  { label: "Özel Emoji 🎰", type: "emoji", value: 0 },
  { label: "250 Puan", type: "points", value: 250 },
];
export async function POST() {
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Oturum yok" }, { status: 401 });
  if (me.isGuest) return Response.json({ error: "Çark üyeler içindir. Kayıt ol!" }, { status: 403 });
  const last = me.lastWheelAt?.getTime() ?? 0;
  if (Date.now() - last < 20 * 3600000) return Response.json({ error: `Çarkı bugün çevirdin. ${Math.ceil((20 * 3600000 - (Date.now() - last)) / 3600000)} saat sonra tekrar gel.` }, { status: 429 });
  const weights = [25, 20, 15, 15, 5, 10, 7, 3];
  let r = Math.random() * weights.reduce((a, b) => a + b, 0);
  let idx = 0;
  for (; idx < weights.length; idx++) { r -= weights[idx]; if (r <= 0) break; }
  const prize = WHEEL[Math.min(idx, WHEEL.length - 1)];
  await db.update(users).set({ lastWheelAt: new Date() }).where(eq(users.id, me.id));
  if (prize.type === "points") await addPoints(me.id, prize.value, "cark");
  if (prize.type === "vip" && me.rank === "uye") await db.update(users).set({ rank: "vip" }).where(eq(users.id, me.id));
  if (prize.type === "emoji") await addPoints(me.id, 15, "cark_emoji");
  const [{ value: spins }] = await db.select({ value: count() }).from(achievements).where(and(eq(achievements.userId, me.id), eq(achievements.key, "spin")));
  await db.insert(achievements).values({ userId: me.id, key: "spin" });
  if (spins + 1 >= 7) await grantAchievement(me.id, "cark_7");
  return Response.json({ prize, index: idx });
}
