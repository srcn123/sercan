import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { BlogDetail } from "@/components/BlogDetail";
export const dynamic = "force-dynamic";
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  if (!post) notFound();
  return <BlogDetail post={{ ...post, createdAt: post.createdAt.toISOString(), updatedAt: post.updatedAt.toISOString() } as unknown as Parameters<typeof BlogDetail>[0]["post"]} />;
}
