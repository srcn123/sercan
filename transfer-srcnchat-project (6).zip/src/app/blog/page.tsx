import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { desc } from "drizzle-orm";
import Link from "next/link";
export const dynamic = "force-dynamic";
export default async function BlogIndex() {
  const posts = await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt));
  return (
    <main className="grid-bg min-h-screen p-6">
      <div className="mx-auto max-w-4xl"><Link href="/" className="text-sm font-bold underline" style={{ color: "var(--brand)" }}>← Ana sayfa</Link>
      <h1 className="mt-4 text-3xl font-black">📝 Blog</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {posts.map((p) => (
          <Link key={p.id} href={`/blog/${p.slug}`} className="card overflow-hidden rounded-3xl">
            {p.imageUrl && <img src={p.imageUrl} alt={p.title} className="h-48 w-full object-cover" />}
            <div className="p-4"><div className="text-lg font-black">{p.title}</div><div className="mt-1 text-sm muted line-clamp-2">{p.excerpt}</div><div className="mt-2 text-xs muted">{new Date(p.createdAt).toLocaleDateString("tr-TR")} · 👁 {p.views}</div></div>
          </Link>
        ))}
        {posts.length===0 && <div className="col-span-2 py-10 text-center text-sm muted">Henüz yazı yok.</div>}
      </div></div>
    </main>
  );
}
