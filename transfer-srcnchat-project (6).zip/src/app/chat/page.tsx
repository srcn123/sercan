import { redirect } from "next/navigation";
import { ChatApp } from "@/components/chat/ChatApp";
import { getCurrentUser, getSettings, publicUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
export const dynamic = "force-dynamic";
export default async function ChatPage() {
  await ensureSeed();
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const s = await getSettings();
  return <ChatApp initialUser={publicUser(user)} site={{ siteName: s.siteName, logoText: s.logoText, logoUrl: s.logoUrl, defaultTheme: s.defaultTheme }} />;
}
