import { redirect } from "next/navigation";
import { getSettings } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { SetupWizard } from "@/components/SetupWizard";
export const dynamic = "force-dynamic";
export default async function KurulumPage() {
  await ensureSeed();
  const s = await getSettings();
  if (s.installed === "1") redirect("/");
  return <SetupWizard defaults={s} />;
}
