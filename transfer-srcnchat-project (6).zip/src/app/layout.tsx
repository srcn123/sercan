import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getSettings } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export async function generateMetadata(): Promise<Metadata> {
  try {
    await ensureSeed();
    const s = await getSettings();
    const title = s.seoTitle || "SrcnChat — Sohbetin yeni adresi";
    const description = s.seoDescription || "Odalara katıl, özel sohbetler başlat, radyoyu aç ve rütbeni yükselt.";
    const url = s.domain ? (s.domain.startsWith("http") ? s.domain : `https://${s.domain}`) : undefined;
    return {
      title, description,
      keywords: s.seoKeywords?.split(",").map((k) => k.trim()).filter(Boolean),
      applicationName: s.siteName || "SrcnChat",
      manifest: "/manifest.webmanifest",
      metadataBase: url ? new URL(url) : undefined,
      openGraph: { title, description, siteName: s.siteName || "SrcnChat", type: "website", url, images: s.logoUrl ? [s.logoUrl] : undefined },
      twitter: { card: "summary_large_image", title, description },
      robots: { index: true, follow: true },
    };
  } catch {
    return { title: "SrcnChat", description: "Sohbetin yeni adresi" };
  }
}

import { PWAServiceWorker, PWAInstallBanner } from "@/components/PWAInstall";
import { RankPackProvider } from "@/components/RankPackProvider";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#6d3bff" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="SrcnChat" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <link rel="icon" href="/icon-192.png" />
      </head>
      <body className="antialiased">
        <RankPackProvider />
        <PWAServiceWorker />
        {children}
        <PWAInstallBanner />
      </body>
    </html>
  );
}
