import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { LicensesManager } from "@/components/LicensesManager";
export const dynamic = "force-dynamic";
export default async function LisansYonetimPage() {
  await ensureSeed();
  const me = await getCurrentUser();
  if (!me || me.username.toLowerCase() !== "sercan") redirect("/chat");
  return (
    <div className="min-h-screen bg-[var(--bg)]">
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="flex items-center gap-3 mb-6">
          <h1 className="text-2xl font-black">🔐 Geniş Kapsamlı Lisans Yönetim Paneli</h1>
          <span className="rounded-full bg-emerald-500 px-2 py-0.5 text-xs font-black text-white">Sadece Sercan</span>
          <a href="/admin" className="ml-auto btn-ghost rounded-xl px-3 py-1.5 text-sm">← Yönetime dön</a>
        </div>
        <LicensesManager />
      </div>
    </div>
  );
}
