import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function manifest(): Promise<import("next").MetadataRoute.Manifest> {
  let cfg: Record<string, string> = {};
  try {
    const rows = await db.select().from(settings);
    cfg = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  } catch {}
  const name = cfg.mobileAppName || cfg.siteName || "SrcnChat";
  const short = cfg.mobileAppShortName || cfg.mobileAppName || cfg.siteName || "SrcnChat";
  const desc = cfg.mobileAppDescription || cfg.seoDescription || "Odalara katıl, özel sohbetler başlat, radyoyu aç ve rütbeni yükselt.";
  const theme = cfg.mobileAppThemeColor || cfg.mobileAppThemeColor || "#6d3bff";
  const bg = cfg.mobileAppBackgroundColor || "#0b1020";
  const icon = cfg.mobileAppIcon || "/icon-512.png";
  return {
    name,
    short_name: short.slice(0, 12),
    description: desc,
    start_url: "/chat?utm_source=pwa",
    display: "standalone",
    display_override: ["standalone", "window-controls-overlay"],
    background_color: bg,
    theme_color: theme,
    orientation: "any",
    scope: "/",
    lang: "tr",
    categories: ["social", "communication", "entertainment"],
    icons: [
      { src: icon, sizes: "512x512", type: "image/png", purpose: "any" },
      { src: icon.replace("512", "192") || "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: icon, sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    screenshots: [
      { src: "/screenshots/chat.png", sizes: "1280x720", type: "image/png", form_factor: "wide", label: "Sohbet odaları" },
      { src: "/screenshots/mobile.png", sizes: "750x1334", type: "image/png", form_factor: "narrow", label: "Mobil sohbet" },
    ],
    shortcuts: [
      { name: "Sohbete Katıl", url: "/chat", description: "Hemen sohbete bağlan", icons: [{ src: "/icon-192.png", sizes: "192x192" }] },
      { name: "Okey Oyna", url: "/chat?room=okey-salonu", description: "Okey masasına otur" },
    ],
    related_applications: [],
    prefer_related_applications: false,
  };
}
