import { redirect } from "next/navigation";
import { Landing } from "@/components/Landing";
import { getCurrentUser, getSettings } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";
import { db } from "@/db";
import { blogPosts } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function HomePage({ searchParams }: { searchParams: Promise<{ mode?: string }> }) {
  await ensureSeed();
  const s = await getSettings();
  if (s.installed !== "1") redirect("/kurulum");
  const user = await getCurrentUser();
  if (user) redirect("/chat");
  const { mode } = await searchParams;
  const initialMode = mode === "login" || mode === "register" || mode === "forgot" ? mode : "guest";

  // blog for SSR — so search engines and first paint see it
  let initialPosts: { id: number; slug: string; title: string; excerpt: string; imageUrl: string | null; authorName: string; views: number; createdAt: string; commentCount: number }[] = [];
  try {
    const posts = await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt)).limit(6);
    initialPosts = posts.map((p) => ({ ...p, createdAt: p.createdAt.toISOString(), commentCount: 0 } as unknown as typeof initialPosts[number]));
  } catch {}

  return <Landing initialMode={initialMode} site={{ siteName: s.siteName, logoText: s.logoText, logoUrl: s.logoUrl, defaultTheme: s.defaultTheme, announcement: s.announcement }} initialPosts={initialPosts} />;
}
