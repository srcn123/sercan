import type { MetadataRoute } from "next";
import { getSettings } from "@/lib/auth";
export const dynamic = "force-dynamic";
export default async function robots(): Promise<MetadataRoute.Robots> {
  const s = await getSettings().catch(() => ({} as Record<string, string>));
  const base = (s.domain ? (s.domain.startsWith("http") ? s.domain : `https://${s.domain}`) : "http://localhost:3000").replace(/\/$/, "");
  return {
    rules: { userAgent: "*", allow: ["/", "/sohbet.html", "/oda-*.html", "/profil-*.html"], disallow: ["/api/", "/admin", "/php/"] },
    sitemap: `${base}/sitemap.xml`,
  };
}
