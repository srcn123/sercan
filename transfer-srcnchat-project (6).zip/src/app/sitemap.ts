import type { MetadataRoute } from "next";
import { db } from "@/db";
import { rooms } from "@/db/schema";
import { getSettings } from "@/lib/auth";
export const dynamic = "force-dynamic";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const s = await getSettings().catch(() => ({} as Record<string, string>));
  const base = (s.domain ? (s.domain.startsWith("http") ? s.domain : `https://${s.domain}`) : "http://localhost:3000").replace(/\/$/, "");
  const now = new Date();
  const baseUrls: MetadataRoute.Sitemap = [
    { url: `${base}/`, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${base}/sohbet.html`, lastModified: now, changeFrequency: "hourly", priority: 0.95 },
    { url: `${base}/kurulum.html`, lastModified: now, changeFrequency: "monthly", priority: 0.3 },
    { url: `${base}/admin.html`, lastModified: now, changeFrequency: "weekly", priority: 0.5 },
    { url: `${base}/chat`, lastModified: now, changeFrequency: "hourly", priority: 0.9 },
  ];
  try {
    const list = await db.select({ slug: rooms.slug }).from(rooms);
    for (const r of list) baseUrls.push({ url: `${base}/oda-${r.slug}.html`, lastModified: now, changeFrequency: "hourly", priority: 0.7 });
  } catch {}
  // profil örnekleri SEO için
  baseUrls.push({ url: `${base}/profil-1.html`, lastModified: now, changeFrequency: "daily", priority: 0.6 });
  return baseUrls;
}
