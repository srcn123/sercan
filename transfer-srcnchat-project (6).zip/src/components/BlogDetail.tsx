"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
type Post = { id: number; slug: string; title: string; excerpt: string; content: string; imageUrl: string | null; authorName: string; views: number; createdAt: string };
type Comment = { id: number; username: string; content: string; createdAt: string; userId: number | null };
export function BlogDetail({ post }: { post: Post }) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [me, setMe] = useState<{ isGuest?: boolean } | null>(null);
  const load = () => fetch(`/api/blog/${post.id}`, { cache: "no-store" }).then((r) => r.json()).then((d) => setComments(d.comments ?? []));
  useEffect(() => { load(); fetch("/api/auth/me", { cache: "no-store" }).then((r) => r.json()).then((d) => setMe(d.user)).catch(()=> setMe(null)); }, [post.id]);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await fetch(`/api/blog/${post.id}/comments`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: text }) });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) alert(d.error ?? "Gönderilemedi"); else { setText(""); load(); }
  };
  const del = async (id: number) => {
    if (!confirm("Yorum silinsin mi?")) return;
    await fetch(`/api/blog/comments/${id}`, { method: "DELETE" }); load();
  };
  return (
    <main className="grid-bg min-h-screen p-4 md:p-8">
      <div className="mx-auto max-w-3xl">
        <Link href="/" className="text-sm font-bold underline" style={{ color: "var(--brand)" }}>← Ana sayfa</Link>
        <Link href="/blog" className="ml-3 text-sm muted underline">Tüm yazılar</Link>
        <article className="card mt-4 overflow-hidden rounded-3xl">
          {post.imageUrl && <img src={post.imageUrl} alt={post.title} className="h-64 w-full object-cover" />}
          <div className="p-6">
            <h1 className="text-2xl font-black">{post.title}</h1>
            <div className="mt-1 text-xs muted">{post.authorName} · {new Date(post.createdAt).toLocaleDateString("tr-TR")} · 👁 {post.views}</div>
            <div className="prose prose-sm mt-4 max-w-none whitespace-pre-wrap leading-relaxed" style={{ color: "var(--text)" }}>{post.content || post.excerpt}</div>
          </div>
        </article>
        <div className="card mt-6 rounded-3xl p-5">
          <h3 className="font-black">💬 Yorumlar ({comments.length})</h3>
          <div className="mt-3 space-y-2">
            {comments.map((c) => (
              <div key={c.id} className="soft flex gap-2 rounded-xl p-3">
                <div className="min-w-0 flex-1"><div className="text-xs font-black">{c.username} <span className="muted">· {new Date(c.createdAt).toLocaleDateString("tr-TR")}</span></div><div className="mt-1 text-sm">{c.content}</div></div>
                <button onClick={() => del(c.id)} className="text-xs muted hover:text-rose-500">Sil</button>
              </div>
            ))}
            {comments.length===0 && <div className="py-4 text-center text-xs muted">Henüz yorum yok — ilk yorumu sen yaz!</div>}
          </div>
          {me && !me.isGuest ? (
            <form onSubmit={submit} className="mt-4 flex gap-2"><input value={text} onChange={(e)=>setText(e.target.value)} maxLength={500} placeholder="Yorum yaz..." className="input flex-1 rounded-xl px-3 py-2 text-sm" /><button className="btn-primary rounded-xl px-4 text-sm font-extrabold">Gönder</button></form>
          ) : <div className="mt-4 rounded-xl bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700">Yorum yazmak için <Link href="/?mode=register" className="underline">kayıt ol</Link> / giriş yap</div>}
        </div>
      </div>
    </main>
  );
}
