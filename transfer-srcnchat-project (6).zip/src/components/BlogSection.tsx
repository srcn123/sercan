"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
type Post = { id: number; slug: string; title: string; excerpt: string; imageUrl: string | null; authorName: string; views: number; createdAt: string; commentCount: number };
export function BlogSection({ initialPosts }: { initialPosts?: Post[] }) {
  const [posts, setPosts] = useState<Post[]>(initialPosts ?? []);
  useEffect(() => {
    if (initialPosts?.length) return;
    fetch("/api/blog", { cache: "no-store" }).then((r) => r.json()).then((d) => setPosts(d.posts ?? [])).catch(() => {});
  }, [initialPosts]);
  return (
    <section className="w-full max-w-5xl mt-8">
      <div className="card rounded-3xl p-5 md:p-6 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.15)]">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-xl md:text-2xl font-black flex items-center gap-2">📝 Blog & Duyurular <span className="hidden sm:inline text-xs font-bold muted">— güncel haberler, rehberler, etkinlikler</span></h2>
          <Link href="/blog" className="btn-ghost rounded-xl px-3 py-1.5 text-xs font-extrabold">Tümünü gör →</Link>
        </div>
        {posts.length === 0 ? (
          <div className="mt-6 rounded-2xl border-2 border-dashed p-8 text-center" style={{ borderColor: "var(--border)", background: "var(--surface-2)" }}>
            <div className="text-3xl">✍️</div>
            <div className="mt-2 text-sm font-black">Henüz blog yazısı yok</div>
            <div className="text-xs muted">Yönetim panelinden ilk konuyu ekleyin — ana sayfada burada görünecek.</div>
            <Link href="/admin" className="btn-primary mt-3 inline-block rounded-xl px-4 py-2 text-xs font-extrabold">Yönetime git</Link>
          </div>
        ) : (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {posts.slice(0, 6).map((p) => (
              <Link key={p.id} href={`/blog/${p.slug}`} className="group card flex flex-col overflow-hidden rounded-2xl transition hover:shadow-lg hover:-translate-y-0.5">
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.title} className="h-36 w-full object-cover" />
                ) : (
                  <div className="flex h-36 items-center justify-center text-3xl" style={{ background: "var(--brand-soft)" }}>📝</div>
                )}
                <div className="p-4 flex flex-col flex-1">
                  <div className="line-clamp-2 text-sm font-black leading-tight group-hover:underline">{p.title}</div>
                  <div className="mt-1 line-clamp-2 text-xs muted flex-1">{p.excerpt || "Devamını oku…"}</div>
                  <div className="mt-3 flex items-center gap-3 text-[11px] muted">
                    <span>👤 {p.authorName}</span><span>👁 {p.views}</span><span>💬 {p.commentCount}</span>
                    <span className="ml-auto">{new Date(p.createdAt).toLocaleDateString("tr-TR")}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
        <div className="mt-4 flex flex-wrap gap-2 text-[11px] muted"><span>💡 Yönetim → 📝 Blog’dan konu, resim ve içerik ekleyebilir, yorumları silebilirsin.</span><span>·</span><span>Kayıtlı üyeler her yazıya yorum bırakabilir.</span></div>
      </div>
    </section>
  );
}
