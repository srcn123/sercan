"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "./Logo";
import { AVATAR_COLORS, COUNTRIES, USERNAME_HINT, USERNAME_REGEX, WELCOME_BONUS } from "@/lib/constants";
import { BlogSection } from "./BlogSection";
import { MobileDownloadSection } from "./MobileDownloadSection";

type Mode = "guest" | "login" | "register" | "forgot";
type PreviewMsg = { id: number; username: string; color: string; content: string };
type Site = { siteName: string; logoText: string; logoUrl: string; defaultTheme: string; announcement: string };

const FEATURES = [
  { icon: "💬", label: "7+ oda" }, { icon: "🔒", label: "Özel sohbet" }, { icon: "📻", label: "Canlı radyo & DJ" },
  { icon: "🛡️", label: "7 rütbe" }, { icon: "📹", label: "Kamera" }, { icon: "🀄", label: "Okey salonu" },
  { icon: "🎁", label: "12 hediye" }, { icon: "🤖", label: "Nova AI" }, { icon: "🎨", label: "10 tema" },
];
const FALLBACK = [
  { username: "MaviBalina", color: "#06b6d4", content: "odada kuralları okumayı unutmayın" },
  { username: "KediliAnne", color: "#f472b6", content: "günaydın herkese, kahveler hazır" },
  { username: "Turbo", color: "#1e90ff", content: "bu gece oyun gecesi var" },
  { username: "Luna", color: "#6d3bff", content: "yeni gelenlere hoş geldiniz" },
];

export function Landing({ initialMode = "guest", site, initialPosts }: { initialMode?: Mode; site: Site; initialPosts?: { id: number; slug: string; title: string; excerpt: string; imageUrl: string | null; authorName: string; views: number; createdAt: string; commentCount: number }[] }) {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>(initialMode);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [secretWord, setSecretWord] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [code, setCode] = useState("");
  const [forgotWay, setForgotWay] = useState<"secret" | "code">("secret");
  const [color, setColor] = useState<string>(AVATAR_COLORS[13]);
  const [gender, setGender] = useState("");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<PreviewMsg[]>([]);
  const [online, setOnline] = useState<number | null>(null);
  const [splash, setSplash] = useState(true);

  useEffect(() => {
    document.documentElement.dataset.theme = site.defaultTheme || "mor";
    const t = setTimeout(() => setSplash(false), 2000);
    return () => clearTimeout(t);
  }, [site.defaultTheme]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("srcn_remember");
      if (saved) {
        const d = JSON.parse(saved);
        if (d.username) setUsername(d.username);
        if (d.color) setColor(d.color);
        if (typeof d.rememberMe === "boolean") setRememberMe(d.rememberMe);
      }
    } catch {}
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await fetch("/api/preview", { cache: "no-store" });
        if (!res.ok) return;
        const d = await res.json();
        if (!alive) return;
        setPreview(d.messages ?? []);
        setOnline(d.online ?? 0);
      } catch {}
    };
    load();
    const t = setInterval(load, 8000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  const usernameValid = USERNAME_REGEX.test(username.trim());
  const showHint = touched && !usernameValid;
  const ticker = useMemo(() => { const src = preview.length >= 3 ? preview.slice(-6) : FALLBACK; return [...src, ...src]; }, [preview]);
  const previewList = preview.length ? preview.slice(-3) : [{ id: 1, username: "Luna", color: "#6d3bff", content: "sohbete hepiniz hoş geldiniz" }, { id: 2, username: "Turbo", color: "#1e90ff", content: "bu gece oyun gecesi var, kaçırmayın" }, { id: 3, username: "GeceKuşu", color: "#d946ef", content: "radyodaki şarkı çok iyi değil mi?" }];

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setTouched(true); setError(null); setInfo(null);
    if (!usernameValid) return;
    setLoading(true);
    try {
      if (mode === "forgot") {
        if (forgotWay === "code" && !code) {
          const r = await fetch("/api/auth/forgot", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ step: "request", username: username.trim() }) });
          const d = await r.json();
          if (!r.ok) setError(d.error); else { setInfo(d.message); if (!d.mailed) setForgotWay("secret"); }
          return;
        }
        const r = await fetch("/api/auth/forgot", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ step: forgotWay, username: username.trim(), secretWord, code, newPassword }) });
        const d = await r.json();
        if (!r.ok) setError(d.error); else { setInfo(d.message); setMode("login"); setPassword(""); }
        return;
      }
      if (mode !== "guest" && password.length < 4) { setError("Şifre en az 4 karakter olmalı."); return; }
      const endpoint = mode === "guest" ? "/api/auth/guest" : mode === "login" ? "/api/auth/login" : "/api/auth/register";
      const res = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: username.trim(), password, color, email, secretWord, gender, country, city, rememberMe }) });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { setError(data.error ?? "Bir şeyler ters gitti."); return; }
      try {
        if (rememberMe) localStorage.setItem("srcn_remember", JSON.stringify({ username: username.trim(), color, rememberMe }));
        else localStorage.removeItem("srcn_remember");
      } catch {}
      if (data.bonus) sessionStorage.setItem("srcn_bonus", String(data.bonus));
      router.push("/chat"); router.refresh();
    } catch { setError("Sunucuya ulaşılamadı."); } finally { setLoading(false); }
  }

  const cta = mode === "guest" ? "Sohbete Hemen Katıl" : mode === "login" ? "Giriş Yap" : mode === "register" ? `Kayıt Ol (+${WELCOME_BONUS} puan)` : forgotWay === "code" && !code ? "Kod Gönder" : "Şifreyi Sıfırla";

  return (
    <main className="grid-bg flex min-h-screen flex-col items-center p-4 md:p-8">
      {splash && (
        <div className="splash">
          <Logo size="md" live={false} text={site.logoText || site.siteName} imageUrl={site.logoUrl} />
          <div className="splash-bar" />
          <div className="text-sm font-bold text-white/70">Sohbete bağlanıyor…</div>
        </div>
      )}
      <div className="card grid w-full max-w-5xl overflow-hidden rounded-3xl shadow-[0_30px_80px_-30px_rgba(60,30,140,0.35)] md:grid-cols-[1.1fr_1fr]">
        <section className="relative overflow-hidden p-7 md:p-10" style={{ background: "linear-gradient(160deg, color-mix(in srgb, var(--brand-soft) 70%, var(--surface)) 0%, var(--surface) 60%)" }}>
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full border-2 border-dashed opacity-60" style={{ borderColor: "color-mix(in srgb, var(--brand) 35%, transparent)" }} />
          <div className="pointer-events-none absolute -right-6 -top-6 h-36 w-36 rounded-full border-2 border-dashed opacity-60" style={{ borderColor: "color-mix(in srgb, var(--brand) 35%, transparent)" }} />
          <div className="flex justify-center md:justify-start"><Logo text={site.logoText || site.siteName} imageUrl={site.logoUrl} /></div>
          <h1 className="mt-8 text-4xl font-black leading-[1.05] tracking-tight md:text-5xl">Sohbetin yeni <span className="text-gradient">adresine</span> hoş geldin.</h1>
          <p className="mt-4 max-w-md text-[15px] leading-relaxed muted">Odalara katıl, özel sohbetler başlat, radyoyu aç, okey oyna, kamerayı aç ve rütbeni yükselt. Kayıt bile olmadan, misafir olarak hemen konuşmaya başlayabilirsin.</p>

          <div className="soft mt-7 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-widest">
              <span className="flex gap-1"><span className="h-2 w-2 rounded-full bg-rose-400" /><span className="h-2 w-2 rounded-full bg-amber-400" /><span className="h-2 w-2 rounded-full bg-emerald-400" /></span>
              <span style={{ color: "var(--brand)" }}>•</span><span className="muted">Lobi — Canlı önizleme</span>
              {online !== null && <span className="ml-auto rounded-full px-2 py-0.5 text-[10px]" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>{online} çevrimiçi</span>}
            </div>
            <div className="mt-3 space-y-3">
              {previewList.map((m) => (
                <div key={m.id} className="fade-in flex items-start gap-3">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-black text-white" style={{ background: m.color }}>{m.username[0]?.toUpperCase()}</div>
                  <div className="min-w-0 text-sm"><span className="font-extrabold" style={{ color: m.color }}>{m.username}</span> <span className="text-[11px] muted">şimdi</span><div className="truncate">{m.content}</div></div>
                </div>
              ))}
            </div>
          </div>
          <div className="soft mt-4 overflow-hidden rounded-2xl p-3">
            <div className="flex items-center gap-2 px-1 text-[11px] font-extrabold uppercase tracking-widest muted"><span style={{ color: "var(--brand)" }}>•</span> Şu an sohbette</div>
            <div className="mt-2 overflow-hidden"><div className="ticker-track">{ticker.map((m, i) => <div key={i} className="card flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs shadow-sm"><span className="font-extrabold" style={{ color: m.color }}>{m.username}:</span><span className="max-w-[220px] truncate">{m.content}</span></div>)}</div></div>
          </div>
          <div className="mt-6 grid grid-cols-3 gap-2.5">{FEATURES.map((f) => <div key={f.label} className="card flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold shadow-sm"><span className="text-sm">{f.icon}</span><span>{f.label}</span></div>)}</div>
        </section>

        <section className="p-7 md:p-10">
          <div className="soft flex rounded-2xl p-1">
            {(["guest", "login", "register"] as Mode[]).map((m) => (
              <button key={m} type="button" onClick={() => { setMode(m); setError(null); setInfo(null); }} className={`flex-1 rounded-xl py-2.5 text-sm font-extrabold transition ${mode === m ? "brand-gradient text-white shadow-md" : "muted"}`}>{m === "guest" ? "Misafir" : m === "login" ? "Giriş" : "Kayıt"}</button>
            ))}
          </div>
          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === "forgot" && <div className="text-lg font-black">Şifremi unuttum</div>}
            <div>
              <label className="label">Kullanıcı adı</label>
              <div className="relative">
                <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm muted">☺</span>
                <input className="input w-full rounded-2xl py-3 pl-10 pr-4 text-sm font-semibold" placeholder="ör. GeceFeneri" value={username} maxLength={18} autoComplete="username" onChange={(e) => setUsername(e.target.value)} onBlur={() => setTouched(true)} />
              </div>
            </div>
            {(mode === "login" || mode === "register") && (
              <div className="fade-in"><label className="label">Şifre</label><input type="password" className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder={mode === "register" ? "En az 4 karakter" : "Şifren"} value={password} autoComplete={mode === "register" ? "new-password" : "current-password"} onChange={(e) => setPassword(e.target.value)} /></div>
            )}
            {mode === "register" && (
              <div className="fade-in space-y-4">
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div><label className="label">E-posta</label><input type="email" className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder="sen@ornek.com" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
                  <div><label className="label">Gizli kelime</label><input className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder="Şifre sıfırlama için" value={secretWord} onChange={(e) => setSecretWord(e.target.value)} /></div>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div><label className="label">Cinsiyet</label><select value={gender} onChange={(e)=>setGender(e.target.value)} className="input w-full rounded-2xl px-3 py-3 text-sm font-bold"><option value="">Belirtme</option><option value="kadin">♀ Kadın</option><option value="erkek">♂ Erkek</option><option value="diger">⚧ Diğer</option></select></div>
                  <div><label className="label">Ülke</label><select value={country} onChange={(e)=>setCountry(e.target.value)} className="input w-full rounded-2xl px-3 py-3 text-sm font-bold"><option value="">Seç</option>{COUNTRIES.map((c)=> <option key={c.code||c.name} value={c.name}>{c.flag} {c.name}</option>)}</select></div>
                  <div><label className="label">Şehir</label><input value={city} onChange={(e)=>setCity(e.target.value)} placeholder="İstanbul" className="input w-full rounded-2xl px-3 py-3 text-sm font-semibold" /></div>
                </div>
              </div>
            )}
            {mode === "forgot" && (
              <div className="fade-in space-y-3">
                <div className="soft flex rounded-xl p-1 text-xs font-extrabold">
                  <button type="button" onClick={() => setForgotWay("secret")} className={`flex-1 rounded-lg py-2 ${forgotWay === "secret" ? "brand-gradient text-white" : "muted"}`}>Gizli kelime ile</button>
                  <button type="button" onClick={() => setForgotWay("code")} className={`flex-1 rounded-lg py-2 ${forgotWay === "code" ? "brand-gradient text-white" : "muted"}`}>E-posta kodu ile</button>
                </div>
                {forgotWay === "secret" ? <input className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder="Gizli kelimen" value={secretWord} onChange={(e) => setSecretWord(e.target.value)} /> : <input className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder="E-postana gelen 6 haneli kod" value={code} onChange={(e) => setCode(e.target.value)} />}
                {(forgotWay === "secret" || code) && <input type="password" className="input w-full rounded-2xl px-4 py-3 text-sm font-semibold" placeholder="Yeni şifre" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />}
              </div>
            )}
            {mode !== "login" && mode !== "forgot" && (
              <div>
                <label className="label">Avatar rengi</label>
                <div className="grid grid-cols-8 gap-2">{AVATAR_COLORS.map((c) => <button key={c} type="button" aria-label={c} onClick={() => setColor(c)} className="aspect-square w-full rounded-full transition hover:scale-110" style={{ background: `linear-gradient(135deg, ${c}, color-mix(in srgb, ${c} 70%, white))`, boxShadow: color === c ? `0 0 0 3px var(--surface), 0 0 0 5px ${c}` : "inset 0 -2px 4px rgba(0,0,0,0.08)" }} />)}</div>
              </div>
            )}
            {(showHint || error) && <div className="fade-in rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-bold text-rose-500">{error ?? USERNAME_HINT}</div>}
            {info && <div className="fade-in rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-bold text-emerald-600">{info}</div>}
            <label className="flex items-center gap-2 rounded-xl px-3 py-2 cursor-pointer hover:bg-[var(--surface-2)] border" style={{ borderColor: "var(--border)" }}>
              <input type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="h-4 w-4 rounded" style={{ accentColor: "var(--brand)" }} />
              <span className="text-xs font-bold">Beni hatırla</span>
              <span className="text-[10px] muted ml-auto">Tekrar geldiğinde direkt giriş — 90 gün saklanır</span>
            </label>
            <button type="submit" disabled={loading} className="btn-primary w-full rounded-2xl py-3.5 text-sm font-extrabold">{loading ? "Bağlanıyor..." : `${cta} →`}</button>
            {mode === "login" && <button type="button" onClick={() => setMode("forgot")} className="w-full text-center text-xs font-bold underline muted">Şifremi unuttum</button>}
            {mode === "forgot" && <button type="button" onClick={() => setMode("login")} className="w-full text-center text-xs font-bold underline muted">← Girişe dön</button>}
            {mode === "register" && <p className="text-center text-[11px] font-bold" style={{ color: "var(--brand)" }}>🎁 Hoş geldin bonusu: kayıt olan herkese {WELCOME_BONUS} puan!</p>}
            <p className="text-center text-[11px] leading-relaxed muted">Sohbete katılarak topluluk kurallarını kabul etmiş olursunuz: saygılı olun, spam yapmayın, keyfinize bakın.</p>
          </form>
        </section>
      </div>
      <MobileDownloadSectionWrapper />
      <BlogSection initialPosts={initialPosts} />
    </main>
  );
}

function MobileDownloadSectionWrapper() {
  const [cfg, setCfg] = useState<{ iosUrl: string; androidUrl: string; apkUrl: string; mobileDescription: string } | null>(null);
  useEffect(() => {
    fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((d) => setCfg({ iosUrl: d.iosAppStoreUrl ?? "", androidUrl: d.androidPlayStoreUrl ?? "", apkUrl: d.androidApkUrl ?? "", mobileDescription: d.mobileDescription ?? "" })).catch(() => {});
  }, []);
  return <MobileDownloadSection iosUrl={cfg?.iosUrl} androidUrl={cfg?.androidUrl} apkUrl={cfg?.apkUrl} description={cfg?.mobileDescription} />;
}
