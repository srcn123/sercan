"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Status = { installed: boolean; license: { key: string; status: string; isUsed: boolean; usedBy: string | null; expiresAt: string | null; note: string } | null; status: string; message: string };

export function LicenseBanner() {
  const [s, setS] = useState<Status | null>(null);
  useEffect(() => {
    fetch("/api/license/status", { cache: "no-store" }).then((r) => r.json()).then(setS).catch(() => {});
    const t = setInterval(() => fetch("/api/license/status", { cache: "no-store" }).then((r) => r.json()).then(setS).catch(() => {}), 60 * 1000);
    return () => clearInterval(t);
  }, []);
  if (!s || s.status === "active") return null;
  const isBad = s.status === "suspended" || s.status === "expired" || s.status === "no-license";
  return (
    <div className={`flex items-center gap-3 border-b px-4 py-2 text-xs font-bold ${isBad ? "bg-amber-100 text-amber-900 border-amber-300" : "bg-sky-50 text-sky-900 border-sky-200"}`}>
      <span>🔑 Lisans: {s.message} {s.license?.key && `· ${s.license.key}`} {s.license?.expiresAt && `· Bitiş: ${new Date(s.license.expiresAt).toLocaleDateString("tr-TR")}`}</span>
      <Link href="/admin" className="ml-auto rounded-full bg-black/10 px-2 py-1 text-[11px] font-black hover:bg-black/20">Yönetim → Lisanslar</Link>
    </div>
  );
}

export function LicenseCard({ compact }: { compact?: boolean }) {
  const [s, setS] = useState<Status | null>(null);
  useEffect(() => { fetch("/api/license/status", { cache: "no-store" }).then((r) => r.json()).then(setS).catch(() => {}); }, []);
  if (!s) return <div className="soft rounded-xl p-3 text-xs muted">Lisans durumu yükleniyor…</div>;
  const color = s.status === "active" ? "emerald" : s.status === "suspended" ? "amber" : "rose";
  return (
    <div className={`rounded-2xl border p-4 ${s.status === "active" ? "bg-emerald-50 border-emerald-200" : s.status === "suspended" ? "bg-amber-50 border-amber-300" : "bg-rose-50 border-rose-200"}`}>
      <div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${s.status === "active" ? "bg-emerald-500" : s.status === "suspended" ? "bg-amber-500" : "bg-rose-500"}`} /><span className="text-sm font-black">Lisans: {s.status === "active" ? "Aktif ✓" : s.status === "suspended" ? "Askıda" : s.status === "expired" ? "Süresi Doldu" : "Yok"}</span><span className="ml-auto text-[11px] muted">{s.license?.key ?? "—"}</span></div>
      <div className="mt-1 text-xs" style={{ color: `var(--muted)` }}>{s.message} {s.license?.note && `· ${s.license.note}`}</div>
      {!compact && s.license?.expiresAt && <div className="mt-1 text-[11px] muted">Bitiş: {new Date(s.license.expiresAt).toLocaleDateString("tr-TR")}</div>}
      <div className="mt-2 text-[11px] muted">Şeffaf doğrulama: <code>/api/license/verify</code> ve <code>/api/license/status</code> herkese açık, müşteri de görebilir. Gizli kod yok.</div>
    </div>
  );
}
