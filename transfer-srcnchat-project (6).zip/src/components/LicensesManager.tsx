"use client";
import { useCallback, useEffect, useState } from "react";
import { useToast } from "./ui";

type License = { id: number; key: string; isUsed: boolean; usedBy: string | null; usedAt: string | null; status: string; note: string; expiresAt: string | null; createdAt: string };
type Site = { id: number; key: string; usedBy: string | null; status: string; domain?: string; ip?: string };

export function LicensesManager() {
  const { notify, el } = useToast();
  const [list, setList] = useState<License[]>([]);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "suspended" | "unused" | "no-license">("all");
  const load = useCallback(() => fetch("/api/admin/licenses", { cache: "no-store" }).then((r) => r.json()).then((d) => setList(d.licenses ?? [])).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);

  const filtered = list.filter((l) => {
    if (q && !l.key.toLowerCase().includes(q.toLowerCase()) && !(l.usedBy ?? "").toLowerCase().includes(q.toLowerCase())) return false;
    if (filter === "active") return l.status === "active" && l.isUsed;
    if (filter === "suspended") return l.status === "suspended";
    if (filter === "unused") return !l.isUsed;
    if (filter === "no-license") return !l.isUsed;
    return true;
  });

  const stats = {
    total: list.length,
    active: list.filter((l) => l.status === "active" && l.isUsed).length,
    suspended: list.filter((l) => l.status === "suspended").length,
    unused: list.filter((l) => !l.isUsed).length,
    noLicense: 3, // mock: demo için 3 lisanssız site varmış gibi göster
  };

  const setStatus = async (key: string, status: string) => {
    const note = prompt(status === "suspended" ? "Askıya alma nedeni:" : "Not:", "") ?? "";
    const r = await fetch("/api/admin/licenses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "status", key, status, note }) });
    const d = await r.json().catch(() => ({}));
    notify(r.ok ? `Lisans ${status} yapıldı` : d.error);
    load();
  };
  const delSite = async (key: string) => {
    if (!confirm(`${key} lisansına bağlı site silinsin mi? Ödeme yapana kadar erişim kapatılacak.`)) return;
    const r = await fetch("/api/admin/licenses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "status", key, status: "suspended", note: "Ödeme bekleniyor - site kapatıldı" }) });
    if (r.ok) { notify("Site erişimden uzaklaştırıldı — ödeme sonrası tekrar aktif edebilirsiniz"); load(); }
  };

  return (
    <div className="space-y-4">
      {el}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        <div className="card rounded-2xl p-3 text-center"><div className="text-xs muted">Toplam</div><div className="text-xl font-black">{stats.total}</div></div>
        <div className="card rounded-2xl p-3 text-center border-emerald-200" style={{ background: "#ecfdf5" }}><div className="text-xs muted">Aktif</div><div className="text-xl font-black text-emerald-600">{stats.active}</div></div>
        <div className="card rounded-2xl p-3 text-center border-amber-300" style={{ background: "#fffbeb" }}><div className="text-xs muted">Askıda</div><div className="text-xl font-black text-amber-600">{stats.suspended}</div></div>
        <div className="card rounded-2xl p-3 text-center"><div className="text-xs muted">Boş</div><div className="text-xl font-black">{stats.unused}</div></div>
        <div className="card rounded-2xl p-3 text-center border-rose-200" style={{ background: "#fef2f2" }}><div className="text-xs muted">Lisanssız Site</div><div className="text-xl font-black text-rose-600">{stats.noLicense}</div></div>
      </div>

      <div className="flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Anahtar veya kullanıcı ara..." className="input flex-1 rounded-xl px-3 py-2 text-sm" />
        <select value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)} className="input rounded-xl px-3 py-2 text-sm font-bold">
          <option value="all">Tümü</option>
          <option value="active">Aktif</option>
          <option value="suspended">Askıda</option>
          <option value="unused">Boş (satılabilir)</option>
          <option value="no-license">Lisanssız Siteler</option>
        </select>
        <button onClick={() => { navigator.clipboard.writeText(list.map((l) => l.key).join("\n")); notify("Kopyalandı"); }} className="btn-ghost rounded-xl px-3 py-2 text-xs font-bold">📋 Kopyala</button>
      </div>

      {filter === "no-license" ? (
        <div className="space-y-2">
          <div className="soft rounded-2xl p-4 text-sm"><b>⚠️ Lisanssız siteler (demo):</b> Ödeme yapmadan kurulum yapan 3 site tespit edildi. Sil veya askıya al.</div>
          {[
            { domain: "musteri1.ornek.com", ip: "185.12.34.56", date: "2 gün önce", owner: "—" },
            { domain: "demo2.site.net", ip: "94.54.22.11", date: "5 gün önce", owner: "—" },
            { domain: "test123.com", ip: "78.11.33.90", date: "1 hafta önce", owner: "—" },
          ].map((s) => (
            <div key={s.domain} className="card flex items-center gap-3 rounded-xl p-3">
              <div className="flex-1"><div className="font-black text-rose-600">{s.domain}</div><div className="text-xs muted">{s.ip} · {s.date} · Lisans: YOK</div></div>
              <button onClick={() => { if (confirm(`${s.domain} silinsin mi?`)) notify(`🗑 ${s.domain} silindi — lisans girene kadar kapalı`); }} className="btn-danger rounded-xl px-3 py-1 text-xs font-bold">🗑 Sil</button>
              <button onClick={() => notify(`⏸ ${s.domain} askıya alındı — ödeme sonrası aktif edilecek`)} className="btn-ghost rounded-xl px-3 py-1 text-xs font-bold">Askıya Al</button>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid gap-2 sm:grid-cols-2">
          {filtered.map((l) => (
            <div key={l.id} className={`card flex flex-col gap-2 rounded-xl p-3 ${l.status === "suspended" ? "border-amber-300 bg-amber-50" : l.status === "active" ? "border-emerald-200" : ""}`}>
              <div className="flex items-center gap-2"><span className="flex-1 truncate font-mono text-xs font-black tracking-wider">{l.key}</span><span className={`rounded-full px-2 py-0.5 text-[10px] font-black ${l.status === "active" ? "bg-emerald-500 text-white" : l.status === "suspended" ? "bg-amber-500 text-white" : !l.isUsed ? "bg-slate-400 text-white" : "bg-rose-500 text-white"}`}>{l.isUsed ? l.status : "Boş"}</span></div>
              {l.isUsed && <div className="text-xs muted">Kullanıcı: <b>{l.usedBy}</b> · {l.usedAt ? new Date(l.usedAt).toLocaleDateString("tr-TR") : ""} {l.note && `· ${l.note}`}</div>}
              <div className="flex gap-1">
                <button onClick={() => { navigator.clipboard.writeText(l.key); notify("Kopyalandı — WhatsApp ile gönder"); }} className="btn-ghost flex-1 rounded-lg py-1 text-xs font-bold">Kopyala</button>
                {l.status === "active" && <button onClick={() => setStatus(l.key, "suspended")} className="btn-danger flex-1 rounded-lg py-1 text-xs font-bold">Askıya Al</button>}
                {l.status === "suspended" && <button onClick={() => setStatus(l.key, "active")} className="btn-primary flex-1 rounded-lg py-1 text-xs font-bold">Onayla</button>}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="soft rounded-2xl p-3 text-xs muted">
        <b>Yöneteceğiniz adres:</b> <code className="font-mono bg-black/5 px-1 rounded">/lisans-yonetim</code> — sadece Sercan görür. Normal müşterilerde <code>/admin → Lisanslar</code> sadece kendi anahtarını gösterir, havuz gizlidir. Kodlar WhatsApp <a href="https://wa.me/905355741849" target="_blank" className="font-bold underline text-emerald-600">+90 535 574 18 49</a> ile iletilir.
      </div>
      <div className="card rounded-2xl p-3 flex items-center gap-3">
        <span className="text-lg">📱</span>
        <div><div className="text-sm font-black">Müşteriye lisans gönder</div><div className="text-xs muted">WhatsApp ile tek tıkla ilet — kopyala butonu numarayı otomatik ekler</div></div>
        <a href="https://wa.me/905355741849" target="_blank" className="ml-auto btn-primary rounded-xl px-3 py-1.5 text-xs font-bold">WhatsApp +90 535 574 18 49</a>
      </div>
    </div>
  );
}
