"use client";
export function Logo({ size = "md", live = true, text = "SrcnChat", imageUrl = "" }: { size?: "sm" | "md"; live?: boolean; text?: string; imageUrl?: string }) {
  const box = size === "md" ? "h-14 w-14 text-base" : "h-9 w-9 text-[10px]";
  const title = size === "md" ? "text-2xl" : "text-base";
  return (
    <div className="flex items-center gap-3">
      {imageUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={imageUrl} alt={text} className={`${size === "md" ? "h-14" : "h-9"} w-auto rounded-2xl object-contain`} />
      ) : (
        <div className={`logo-badge ${box} flex items-center justify-center rounded-2xl font-black tracking-tight text-white`}>{text.slice(0, 4).toUpperCase()}</div>
      )}
      <div className="leading-tight">
        <div className={`${title} font-black tracking-tight`} style={{ color: "var(--text)" }}>{text}</div>
        {live && (
          <div className="flex items-center gap-1.5 text-xs font-semibold muted">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />
            Sohbet şu an canlı
          </div>
        )}
      </div>
    </div>
  );
}
