"use client";
import { useEffect, useState } from "react";
export function MobileChatDownload() {
  const [cfg, setCfg] = useState<{ iosAppStoreUrl: string; androidPlayStoreUrl: string; androidApkUrl: string; mobileDescription: string; mobileEnabled: string } | null>(null);
  useEffect(() => {
    fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()).then((d) => setCfg(d)).catch(() => {});
  }, []);
  if (!cfg || cfg.mobileEnabled === "0") return null;
  const hasLink = cfg.iosAppStoreUrl || cfg.androidPlayStoreUrl || cfg.androidApkUrl;
  if (!hasLink) return null;
  return (
    <div className="soft rounded-xl p-3">
      <div className="flex items-center gap-2"><span className="text-sm">📲</span><span className="text-xs font-black">Mobil Uygulama</span><span className="ml-auto rounded-full bg-emerald-500 px-1.5 py-0.5 text-[9px] font-black text-white">YENİ</span></div>
      {cfg.mobileDescription && <div className="mt-1 text-[11px] muted leading-snug line-clamp-2">{cfg.mobileDescription}</div>}
      <div className="mt-2 grid grid-cols-2 gap-1.5">
        {cfg.iosAppStoreUrl && <a href={cfg.iosAppStoreUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl bg-black px-2.5 py-2 text-white"><span className="text-sm"></span><div><div className="text-[9px] leading-none opacity-80">App Store</div><div className="text-xs font-black leading-none">iOS İndir</div></div></a>}
        {(cfg.androidPlayStoreUrl || cfg.androidApkUrl) && <a href={cfg.androidPlayStoreUrl || cfg.androidApkUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl bg-emerald-600 px-2.5 py-2 text-white"><span className="text-sm">▶</span><div><div className="text-[9px] leading-none opacity-80">Google Play</div><div className="text-xs font-black leading-none">Android İndir</div></div></a>}
      </div>
    </div>
  );
}
