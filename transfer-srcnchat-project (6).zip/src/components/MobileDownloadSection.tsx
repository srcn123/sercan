"use client";
import { useEffect, useState } from "react";

type Props = {
  iosUrl?: string;
  androidUrl?: string;
  apkUrl?: string;
  description?: string;
};

export function MobileDownloadSection({ iosUrl, androidUrl, apkUrl, description }: Props) {
  const [isStandalone, setIsStandalone] = useState(false);
  useEffect(() => {
    setIsStandalone(window.matchMedia("(display-mode: standalone)").matches);
    const h = () => setIsStandalone(window.matchMedia("(display-mode: standalone)").matches);
    window.matchMedia("(display-mode: standalone)").addEventListener("change", h);
    return () => window.matchMedia("(display-mode: standalone)").removeEventListener("change", h);
  }, []);
  if (isStandalone) return null; // zaten uygulama içindeyse gösterme

  const hasLinks = iosUrl || androidUrl || apkUrl;
  return (
    <section className="w-full max-w-5xl mt-8">
      <div className="card rounded-3xl overflow-hidden shadow-lg">
        <div className="grid md:grid-cols-[1.1fr_0.9fr] gap-0">
          <div className="p-6 md:p-8">
            <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-black text-white brand-gradient">📲 Mobil Uygulama</div>
            <h3 className="mt-3 text-2xl font-black leading-tight">Telefonuna kur — tek dokunuşla sohbet</h3>
            <p className="mt-2 text-sm muted leading-relaxed">
              {description || "iOS ve Android’de native uygulama gibi çalışır. Bildirimler, tam ekran, çevrimdışı önbellek ve otomatik güncelleme ile. Mağazaya gerek kalmadan anında yüklenir."}
            </p>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <a href={iosUrl || "#"} target="_blank" rel="noreferrer" className={`flex items-center gap-3 rounded-2xl p-3 border text-left transition hover:scale-[1.02] ${iosUrl ? "card" : "soft opacity-60"}`} style={{ borderColor: "var(--border)" }}>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-black text-white text-xl"></span>
                <div><div className="text-xs muted">App Store</div><div className="text-sm font-black">iOS için İndir</div></div>
                <span className="ml-auto">→</span>
              </a>
              <a href={androidUrl || apkUrl || "#"} target="_blank" rel="noreferrer" className={`flex items-center gap-3 rounded-2xl p-3 border text-left transition hover:scale-[1.02] ${androidUrl || apkUrl ? "card" : "soft opacity-60"}`} style={{ borderColor: "var(--border)" }}>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500 text-white text-xl">▶</span>
                <div><div className="text-xs muted">Google Play</div><div className="text-sm font-black">Android için İndir</div></div>
                <span className="ml-auto">→</span>
              </a>
            </div>
            {apkUrl && <a href={apkUrl} className="mt-3 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold soft" download>⬇ APK Doğrudan İndir (Android)</a>}
            <div className="mt-4 flex flex-wrap gap-2 text-[11px] muted">
              <span>✅ Otomatik güncellenir — site güncellendiğinde uygulama da yenilenir</span>
              <span>·</span>
              <span>🔔 Bildirimler ve tam ekran</span>
            </div>
          </div>
          <div className="bg-[var(--surface-2)] p-6 flex flex-col items-center justify-center gap-4 border-t md:border-t-0 md:border-l" style={{ borderColor: "var(--border)" }}>
            <div className="text-xs font-black tracking-widest muted">ÖNİZLEME</div>
            <div className="flex gap-4">
              {/* iOS mock */}
              <div className="flex flex-col items-center gap-2">
                <div className="relative w-[110px] h-[220px] rounded-[22px] border-[6px] border-black bg-white shadow-lg overflow-hidden flex flex-col">
                  <div className="h-4 bg-black flex items-center justify-center"><div className="h-1.5 w-10 rounded-full bg-zinc-700" /></div>
                  <div className="flex-1 p-2 flex flex-col gap-1.5">
                    <div className="h-3 w-16 rounded bg-zinc-100" />
                    <div className="h-20 rounded-xl brand-gradient" />
                    <div className="h-2 w-full rounded bg-zinc-100" /><div className="h-2 w-3/4 rounded bg-zinc-100" />
                    <div className="mt-auto flex gap-1"><div className="h-6 flex-1 rounded-full brand-gradient" /><div className="h-6 w-6 rounded-full bg-zinc-100" /></div>
                  </div>
                </div>
                <span className="text-[11px] font-bold">iPhone</span>
                <span className="text-[10px] muted">iOS 14+ • PWA</span>
              </div>
              {/* Android mock */}
              <div className="flex flex-col items-center gap-2">
                <div className="relative w-[110px] h-[220px] rounded-[18px] border-[5px] border-zinc-800 bg-white shadow-lg overflow-hidden flex flex-col">
                  <div className="h-5 bg-zinc-900 flex items-center justify-between px-2"><span className="text-[8px] text-white">9:41</span><span className="text-[8px] text-white">● ● ●</span></div>
                  <div className="flex-1 p-2 flex flex-col gap-1.5">
                    <div className="h-3 w-16 rounded bg-zinc-100" />
                    <div className="h-20 rounded-xl bg-emerald-500" />
                    <div className="h-2 w-full rounded bg-zinc-100" /><div className="h-2 w-3/4 rounded bg-zinc-100" />
                    <div className="mt-auto flex gap-1"><div className="h-6 flex-1 rounded-full bg-emerald-500" /><div className="h-6 w-6 rounded-full bg-zinc-100" /></div>
                  </div>
                </div>
                <span className="text-[11px] font-bold">Android</span>
                <span className="text-[10px] muted">Android 8+ • TWA/PWA</span>
              </div>
            </div>
            <div className="text-center text-[11px] muted leading-relaxed">Her güncellemede uygulama otomatik yenilenir — kullanıcı tekrar yüklemek zorunda kalmaz.<br/>Mağaza onayı için <b>PWABuilder</b> ile paketleyebilirsin.</div>
          </div>
        </div>
      </div>
    </section>
  );
}
