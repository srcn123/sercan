"use client";

type Tab = "odalar" | "dostlar" | "kamera";
type Props = {
  activeTab: Tab;
  onTab: (t: Tab) => void;
  onRooms: () => void;
  onFriends: () => void;
  onCamera: () => void;
  onGift: () => void;
  onYoutube: () => void;
  onSettings: () => void;
  unread: number;
  pendingFriends: number;
  broadcasters: number;
  leftOpen: boolean;
  rightOpen: boolean;
  onToggleLeft: () => void;
  onToggleRight: () => void;
  micAmHolder?: boolean;
  micBusy?: boolean;
  micPosition?: number;
  micHolderName?: string | null;
  onMicToggle?: () => void;
  onMicLeave?: () => void;
};

export function MobileBottomNav({ activeTab, onTab, onRooms, onFriends, onCamera, onGift, onYoutube, onSettings, unread, pendingFriends, broadcasters, leftOpen, rightOpen, onToggleLeft, onToggleRight, micAmHolder, micBusy, micPosition, micHolderName, onMicToggle, onMicLeave }: Props) {
  const micActive = !!micAmHolder;
  const micQueued = (micPosition ?? 0) > 0;
  return (
    <div className="fixed bottom-0 left-0 right-0 z-30 flex items-center gap-0.5 overflow-x-auto border-t bg-[var(--surface)] px-1 py-1.5 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] md:hidden" style={{ borderColor: "var(--border)", paddingBottom: "max(6px, env(safe-area-inset-bottom))" }}>
      <button onClick={() => { onTab("odalar"); onRooms(); }} className={`flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 ${activeTab === "odalar" && leftOpen ? "brand-gradient text-white" : "muted"}`}>
        <span className="text-base">💬</span>
        <span className="text-[9px] font-black">Odalar</span>
      </button>
      <button onClick={() => { onTab("dostlar"); onFriends(); }} className={`relative flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 ${activeTab === "dostlar" && leftOpen ? "brand-gradient text-white" : "muted"}`}>
        <span className="text-base">👥</span>
        <span className="text-[9px] font-black">Dostlar</span>
        {pendingFriends > 0 && <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white">{pendingFriends}</span>}
      </button>
      <button onClick={() => { onTab("kamera"); onCamera(); }} className={`relative flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 ${activeTab === "kamera" && leftOpen ? "brand-gradient text-white" : "muted"}`}>
        <span className="text-base">📹</span>
        <span className="text-[9px] font-black">Kamera</span>
        {broadcasters > 0 && <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-red-500 animate-pulse" />}
      </button>
      <button
        onClick={() => (micActive ? onMicToggle?.() : micQueued ? onMicLeave?.() : onMicToggle?.())}
        title={micActive ? "Mikrofonu bırak" : micQueued ? `Sıradasın (${micPosition}) — çıkmak için dokun` : micHolderName ? `${micHolderName} konuşuyor — sıraya gir` : "Mikrofon al ve konuş"}
        className={`relative flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-3 py-1 ${micActive ? "bg-rose-500 text-white shadow animate-pulse" : "brand-gradient text-white"}`}
      >
        <span className="text-base">🎤</span>
        <span className="text-[9px] font-black">{micActive ? "Bırak" : micQueued ? `Sıra ${micPosition}` : "Mikrofon"}</span>
        {micQueued && !micActive && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[9px] font-black text-white">{micPosition}</span>}
      </button>
      <button onClick={onGift} className="flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 muted">
        <span className="text-base">🎁</span>
        <span className="text-[9px] font-black">Hediye</span>
      </button>
      <button onClick={onYoutube} className="flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 muted">
        <span className="text-base">▶️</span>
        <span className="text-[9px] font-black">YouTube</span>
      </button>
      <button onClick={onSettings} className="flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 muted">
        <span className="text-base">⚙️</span>
        <span className="text-[9px] font-black">Ayarlar</span>
      </button>
      <button onClick={onToggleRight} className={`relative flex shrink-0 flex-col items-center gap-0.5 rounded-xl px-2 py-1 ${rightOpen ? "brand-gradient text-white" : "muted"}`}>
        <span className="text-base">👥</span>
        <span className="text-[9px] font-black">Üyeler</span>
        {unread > 0 && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-black text-white">{unread > 9 ? "9+" : unread}</span>}
      </button>
    </div>
  );
}
