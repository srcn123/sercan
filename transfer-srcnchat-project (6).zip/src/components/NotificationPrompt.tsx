"use client";
import { useEffect, useState } from "react";

const STORAGE_KEY = "srcn_notif_asked";
const STORAGE_DECISION = "srcn_notif_decision";

export function useNotificationOnce() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">("default");

  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) {
      setPermission("unsupported");
      return;
    }
    setPermission(Notification.permission);

    // Sadece ilk girişte 1 defa sor — çerezler silinince localStorage de silinir, tekrar sorulur
    const asked = localStorage.getItem(STORAGE_KEY);
    if (!asked && Notification.permission === "default") {
      // 2 saniye sonra nazikçe sor, hemen değil
      const t = setTimeout(() => setShowPrompt(true), 2000);
      return () => clearTimeout(t);
    }
  }, []);

  const request = async () => {
    if (!("Notification" in window)) return;
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      localStorage.setItem(STORAGE_KEY, "1");
      localStorage.setItem(STORAGE_DECISION, result);
      setShowPrompt(false);
      return result;
    } catch {
      localStorage.setItem(STORAGE_KEY, "1");
      localStorage.setItem(STORAGE_DECISION, "denied");
      setShowPrompt(false);
    }
  };

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    localStorage.setItem(STORAGE_DECISION, "dismissed");
    setShowPrompt(false);
  };

  const reset = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STORAGE_DECISION);
    setShowPrompt(true);
  };

  return { showPrompt, permission, request, dismiss, reset };
}

export function NotificationBanner({ onEnable, onDismiss }: { onEnable: () => void; onDismiss: () => void }) {
  return (
    <div className="fixed bottom-4 left-4 right-4 z-[100] md:left-auto md:right-4 md:max-w-sm">
      <div className="card rounded-2xl p-4 shadow-2xl border-2" style={{ borderColor: "var(--brand)" }}>
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full brand-gradient text-white text-lg">🔔</div>
          <div className="flex-1">
            <div className="text-sm font-black">Bildirimleri aç?</div>
            <div className="text-xs muted mt-1">Özel mesaj, bahsedilme ve aramaları kaçırmamak için bildirimlere izin ver. Sadece ilk girişte bir kez sorulur.</div>
            <div className="mt-3 flex gap-2">
              <button onClick={onEnable} className="btn-primary flex-1 rounded-xl py-2 text-xs font-black">Evet, aç</button>
              <button onClick={onDismiss} className="btn-ghost flex-1 rounded-xl py-2 text-xs font-bold">Şimdi değil</button>
            </div>
            <div className="mt-2 text-[10px] muted text-center">Çerezler silinince tekrar sorulur. Ayarlar → Sesler’den değiştirebilirsin.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
