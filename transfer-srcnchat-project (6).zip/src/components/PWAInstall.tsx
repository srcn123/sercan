"use client";
import { useEffect, useState } from "react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function PWAInstallBanner() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [show, setShow] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    // Sadece ilk girişte 1 kez sor — localStorage ile hatırla, çerez silinince tekrar
    const asked = localStorage.getItem("srcn_pwa_asked");
    const isStandalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone;
    if (asked || isStandalone) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
      // 1.5sn sonra sor
      setTimeout(() => setShow(true), 1500);
    };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", () => {
      setInstalled(true);
      setShow(false);
      localStorage.setItem("srcn_pwa_installed", "1");
    });

    // iOS için beforeinstallprompt yok — manuel talimat göster (sadece mobil Safari)
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as unknown as { MSStream?: unknown }).MSStream;
    const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    if (isIOS && isSafari && !asked) {
      setTimeout(() => setShow(true), 2000);
    }

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (deferred) {
      deferred.prompt();
      const choice = await deferred.userChoice;
      localStorage.setItem("srcn_pwa_asked", "1");
      localStorage.setItem("srcn_pwa_choice", choice.outcome);
      setShow(false);
      setDeferred(null);
    } else {
      // iOS manuel
      localStorage.setItem("srcn_pwa_asked", "1");
      setShow(false);
      // iOS talimatını göster, 5 sn sonra otomatik kapanır
      const el = document.getElementById("pwa-ios-help");
      if (el) el.classList.remove("hidden");
      setTimeout(() => el?.classList.add("hidden"), 8000);
    }
  };

  const dismiss = () => {
    localStorage.setItem("srcn_pwa_asked", "1");
    localStorage.setItem("srcn_pwa_choice", "dismissed");
    setShow(false);
  };

  if (!show || installed) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 md:bottom-6 md:left-auto md:right-6 md:max-w-sm">
      <div className="card rounded-2xl p-4 shadow-2xl border-2" style={{ borderColor: "var(--brand)" }}>
        <div className="flex items-start gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl brand-gradient text-white text-xl">📲</div>
          <div className="flex-1">
            <div className="text-sm font-black">Sohbet Programı Yüklensin mi?</div>
            <div className="text-xs muted mt-1">Telefonuna tek dokunuşla kur — bildirimler, tam ekran, otomatik güncelleme. Mağazaya gerek yok, anında yüklenir.</div>
            <div className="mt-3 flex gap-2">
              <button onClick={handleInstall} className="btn-primary flex-1 rounded-xl py-2.5 text-sm font-black">📲 Yükle</button>
              <button onClick={dismiss} className="btn-ghost flex-1 rounded-xl py-2 text-sm font-bold">Şimdi değil</button>
            </div>
            <div className="mt-2 text-center text-[10px] muted">İlk girişte bir kez sorulur. Ayarlar → Uygulama’dan tekrar yükleyebilirsin.</div>
          </div>
        </div>
      </div>
      {/* iOS manuel talimat */}
      <div id="pwa-ios-help" className="hidden mt-3 card rounded-2xl p-3 text-xs">
        <div className="font-black">iPhone için:</div>
        <div className="muted mt-1">Safari’de paylaş <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-slate-100">⎙</span> → <b>Ana Ekrana Ekle</b> → Ekle. Uygulama gibi çalışır.</div>
      </div>
    </div>
  );
}

export function PWAServiceWorker() {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").then((reg) => {
        // Site güncellendiğinde otomatik güncelle — kullanıcı bir sonraki yenilemede yeni sürümü görür
        reg.addEventListener("updatefound", () => {
          const nw = reg.installing;
          if (nw) nw.addEventListener("statechange", () => {
            if (nw.state === "installed" && navigator.serviceWorker.controller) {
              // Yeni sürüm hazır — nazikçe yenile
              if (confirm("Yeni sürüm hazır — yenilensin mi?")) {
                nw.postMessage("SKIP_WAITING");
                window.location.reload();
              }
            }
          });
        });
      }).catch(() => {});
      let refreshing = false;
      navigator.serviceWorker.addEventListener("controllerchange", () => {
        if (!refreshing) { refreshing = true; window.location.reload(); }
      });
    }
  }, []);
  return null;
}
