"use client";
import { useEffect } from "react";

export function RankPackProvider() {
  useEffect(() => {
    fetch("/api/ranks/pack", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.pack) document.documentElement.dataset.rankPack = d.pack;
      })
      .catch(() => {});
    const t = setInterval(() => {
      fetch("/api/ranks/pack", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => {
          if (d.pack) document.documentElement.dataset.rankPack = d.pack;
        })
        .catch(() => {});
    }, 15000);
    return () => clearInterval(t);
  }, []);
  return null;
}
