"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "./Logo";
import { THEMES } from "@/lib/constants";
export function SetupWizard({ defaults }: { defaults: Record<string, string> }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [f, setF] = useState({ siteName: defaults.siteName || "SrcnChat", domain: defaults.domain || "", logoText: defaults.logoText || "SrcnChat", defaultTheme: defaults.defaultTheme || "mor", seoTitle: defaults.seoTitle || "", seoDescription: defaults.seoDescription || "", seoKeywords: defaults.seoKeywords || "", username: "Sercan", password: "Sercan123", email: "", secretWord: "srcn", licenseKey: "" });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  async function finish() {
    setBusy(true); setErr(null);
    const r = await fetch("/api/auth/setup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) { setErr(d.error); return; }
    router.push("/chat"); router.refresh();
  }
  const steps = ["Site", "SEO", "Lisans", "Kurucu"];
  return (
    <main className="grid-bg flex min-h-screen items-center justify-center p-4">
      <div className="card w-full max-w-xl rounded-3xl p-8 shadow-2xl">
        <Logo text={f.logoText} />
        <h1 className="mt-6 text-2xl font-black">Kurulum Sihirbazı</h1>
        <p className="text-sm muted">Siteni 3 adımda hazırla. Bu ekran yalnızca ilk kurulumda görünür.</p>
        <div className="mt-5 flex gap-2">{steps.map((s, i) => <div key={s} className={`flex-1 rounded-xl py-2 text-center text-xs font-extrabold ${i === step ? "brand-gradient text-white" : i < step ? "soft" : "soft muted"}`}>{i + 1}. {s}</div>)}</div>
        <div className="mt-6 space-y-4">
          {step === 0 && (<>
            <div><label className="label">Site adı</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.siteName} onChange={(e) => set("siteName", e.target.value)} /></div>
            <div><label className="label">Alan adı</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" placeholder="srcnchat.com" value={f.domain} onChange={(e) => set("domain", e.target.value)} /></div>
            <div><label className="label">Logo yazısı (maks 15 harf)</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" maxLength={15} value={f.logoText} onChange={(e) => set("logoText", e.target.value)} /></div>
            <div><label className="label">Ana tema</label><div className="grid grid-cols-5 gap-2">{THEMES.map((t) => <button key={t.key} type="button" onClick={() => set("defaultTheme", t.key)} className="flex flex-col items-center gap-1 rounded-xl border p-2 text-[10px] font-extrabold" style={{ borderColor: f.defaultTheme === t.key ? "var(--brand)" : "var(--border)" }}><span className="flex h-6 w-6 overflow-hidden rounded-full border"><span className="w-1/2" style={{ background: t.swatch[0] }} /><span className="w-1/2" style={{ background: t.swatch[1] }} /></span>{t.label}</button>)}</div></div>
          </>)}
          {step === 1 && (<>
            <div><label className="label">SEO başlığı</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.seoTitle} onChange={(e) => set("seoTitle", e.target.value)} /></div>
            <div><label className="label">SEO açıklaması</label><textarea className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" rows={3} value={f.seoDescription} onChange={(e) => set("seoDescription", e.target.value)} /></div>
            <div><label className="label">Anahtar kelimeler (virgülle)</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.seoKeywords} onChange={(e) => set("seoKeywords", e.target.value)} /></div>
          </>)}
          {step === 2 && (<>
            <div><label className="label">Lisans Anahtarı 🔑 <span className="text-rose-500">* zorunlu — benden almadan kurulum ilerlemez</span></label><input className="input w-full rounded-xl px-4 py-3 text-sm font-mono font-bold tracking-wider" placeholder="Örn: SRCN-AB12-CD34-EF56-GH78" value={f.licenseKey} onChange={(e) => set("licenseKey", e.target.value.toUpperCase())} />
            <div className="mt-1 text-[11px] muted">Lisans anahtarı <b>her zaman boş</b> gelir — örnek gösterilmez, sadece <b>WhatsApp <a href="https://wa.me/905355741849" target="_blank" className="underline" style={{ color: "#10b981" }}>+90 535 574 18 49</a></b> ile benden aldığın <b>aktif</b> anahtar ile ilerleyebilirsin. Bir anahtar bir sitede kullanılınca <b>kullanılmış sayılır ve başka yerde tekrar kullanılamaz</b>.</div></div>
            <div className="soft rounded-2xl p-3 text-xs border-amber-200" style={{ background: "#fffbeb" }}><b>⚠️ Lisanssız kurulum yok:</b> Aktif anahtarların olmadan kurulum asla ilerlemez. Anahtarlar sadece <b>Master Sercan</b> tarafından WhatsApp ile verilir.</div>
          </>)}
          {step === 3 && (<>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label">Kurucu kullanıcı adı</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.username} onChange={(e) => set("username", e.target.value)} /></div>
              <div><label className="label">Şifre</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.password} onChange={(e) => set("password", e.target.value)} /></div>
              <div><label className="label">E-posta</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.email} onChange={(e) => set("email", e.target.value)} /></div>
              <div><label className="label">Gizli kelime</label><input className="input w-full rounded-xl px-4 py-3 text-sm font-semibold" value={f.secretWord} onChange={(e) => set("secretWord", e.target.value)} /></div>
            </div>
            <div className="rounded-2xl px-4 py-3 text-xs font-bold" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>Kurulum bitince Kurucu olarak otomatik giriş yapılır. Yönetim paneli: <b>/admin</b> · Lisansın <code>licenses.json</code>’de saklanır.</div>
          </>)}
          {err && <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-bold text-rose-500">{err}</div>}
          <div className="flex gap-2">
            {step > 0 && <button onClick={() => setStep(step - 1)} className="btn-ghost rounded-xl px-4 py-3 text-sm font-extrabold">← Geri</button>}
            {step < 3 ? <button onClick={() => setStep(step + 1)} className="btn-primary ml-auto rounded-xl px-6 py-3 text-sm font-extrabold">İleri →</button> : <button disabled={busy} onClick={finish} className="btn-primary ml-auto rounded-xl px-6 py-3 text-sm font-extrabold">{busy ? "Kuruluyor..." : "Kurulumu Tamamla ✓"}</button>}
          </div>
        </div>
      </div>
    </main>
  );
}
