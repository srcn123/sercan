"use client";
import { useCallback, useEffect, useState } from "react";
import { Logo } from "../Logo";
import { Avatar, RankBadge, fileToDataUrl, useToast } from "../ui";
import type { PublicUser } from "@/lib/auth";
import { COUNTRIES, RADIO_STATIONS, RANKS, RANK_ORDER, THEMES, rankLevel } from "@/lib/constants";
import { RankManager } from "./RankManager";

type Tab = "genel" | "kullanicilar" | "botlar" | "radyo" | "odalar" | "guvenlik" | "hareketler" | "mod" | "blog" | "lisans" | "mobil" | "rutbe" | "hesabim";
type U = { id: number; username: string; email: string | null; rank: string; isGuest: boolean; isDj: boolean; points: number; level: number; isBanned: boolean; mutedUntil: string | null; lastIp: string | null; lastSeen: string; createdAt: string; totalMessages: number; color: string; avatarUrl: string | null; isVerified: boolean };
type Bot = { id: number; username: string; botKind: string; botEnabled: boolean; botRoomMode: string; botRoomId: number | null; color: string; avatarUrl: string | null; bannerUrl: string | null; about: string };
type Room = { id: number; name: string; description: string; icon: string; imageUrl: string | null; bgUrl: string | null; kind: string; ownerId: number | null; ownerName: string | null; isDefault: boolean; online: number };
type Act = { id: number; userId: number | null; username: string; ip: string; city: string; country: string; action: string; createdAt: string; isBanned: boolean | null; rank: string | null };

const post = (url: string, body: Record<string, unknown>) => fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async (r) => ({ ok: r.ok, d: await r.json().catch(() => ({})) }));

export function AdminPanel({ me }: { me: PublicUser }) {
  const founder = me.rank === "kurucu";
  const isSercan = me.username.toLowerCase() === "sercan";
  const [tab, setTab] = useState<Tab>(isSercan ? "genel" : founder ? "lisans" : "kullanicilar");
  const { notify, el } = useToast();
  const isAdmin = rankLevel(me.rank) >= 4;
  // Müşteri (kurucu ama Sercan değil) sadece lisans bilgilerini görsün — istek üzerine
  const tabs: [Tab, string][] = isSercan
    ? [["genel", "📊 Genel Bakış"], ["kullanicilar", "👥 Kullanıcılar"], ["botlar", "🤖 Botlar"], ["radyo", "📻 Radyo"], ["odalar", "🚪 Odalar"], ["guvenlik", "🛡 Güvenlik"], ["hareketler", "📍 Hareketler"], ["mod", "🛠 Mod Panel"], ["blog", "📝 Blog"], ["lisans", "🔑 Lisanslar"], ["mobil", "📱 Mobil"], ["rutbe", "🏅 Rütbeler"], ["hesabim", "🔑 Hesabım"]]
    : founder // kurucu ama Sercan değil = müşteri
      ? [["lisans", "🔑 Lisans Bilgilerim"], ["hesabim", "🔑 Hesabım"]]
      : isAdmin
        ? [["kullanicilar", "👥 Kullanıcılar"], ["mod", "🛠 Mod Panel (Yasak/Susturma)"], ["blog", "📝 Blog"], ["hesabim", "🔑 Hesabım"]]
        : [["kullanicilar", "👥 Kullanıcılar"], ["hesabim", "🔑 Hesabım"]];
  useEffect(() => { document.documentElement.dataset.theme = me.theme; }, [me.theme]);
  return (
    <div className="grid-bg min-h-screen">
      <header className="card flex items-center gap-3 border-b px-4 py-2"><Logo size="sm" live={false} /><span className="rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-widest" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>Yönetim Paneli</span><div className="ml-auto flex items-center gap-2 text-xs font-bold"><Avatar name={me.username} color={me.color} url={me.avatarUrl} size={24} />{me.username}<RankBadge rank={me.rank} compact /><a href="/chat" className="btn-ghost rounded-xl px-3 py-1.5">← Sohbete dön</a></div></header>
      <div className="mx-auto grid max-w-7xl gap-4 p-4 md:grid-cols-[220px_1fr]">
        <nav className="card h-fit rounded-2xl p-2">{tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`block w-full rounded-xl px-3 py-2 text-left text-sm font-extrabold ${tab === k ? "brand-gradient text-white" : "hover:bg-[var(--surface-2)]"}`}>{l}</button>)}</nav>
        <section className="card min-h-[70vh] rounded-2xl p-4 md:p-6">
          {tab === "genel" && <Overview notify={notify} />}
          {tab === "kullanicilar" && <Users me={me} notify={notify} />}
          {tab === "botlar" && <Bots notify={notify} />}
          {tab === "radyo" && <Radio notify={notify} />}
          {tab === "odalar" && <Rooms notify={notify} />}
          {tab === "guvenlik" && <Security notify={notify} />}
          {tab === "hareketler" && <Activity notify={notify} />}
          {tab === "mod" && <ModPanel notify={notify} />}
          {tab === "blog" && <BlogAdmin notify={notify} />}
          {tab === "lisans" && <LicensesAdmin me={me} notify={notify} />}
          {tab === "mobil" && <MobileAdmin notify={notify} />}
          {tab === "rutbe" && <RankManager />}
          {tab === "hesabim" && <Account notify={notify} />}
        </section>
      </div>
      {el}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) { return <div><label className="label">{label}</label>{children}</div>; }

function Overview({ notify }: { notify: (m: string) => void }) {
  const [d, setD] = useState<{ stats: Record<string, number>; settings: Record<string, string> } | null>(null);
  const [s, setS] = useState<Record<string, string>>({});
  const load = useCallback(() => fetch("/api/admin/stats", { cache: "no-store" }).then((r) => r.json()).then((x) => { setD(x); setS(x.settings); }), []);
  useEffect(() => { load(); }, [load]);
  if (!d) return <div className="text-sm muted">Yükleniyor…</div>;
  const save = async () => {
    const r = await post("/api/admin/settings", s);
    if (r.ok) {
      notify("Ayarlar kaydedildi ✓ Tema tüm siteye uygulandı");
      // Ana tema değiştiğinde anında önizle — hem admin paneli hem de site genelinde
      document.documentElement.dataset.theme = s.defaultTheme || "mor";
      // Kendi kişisel temanı da senkronize et ki hemen göresin (istersen sonra tekrar değiştirirsin)
      await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ theme: s.defaultTheme }) }).catch(()=>{});
    } else notify(r.d.error);
  };
  const set = (k: string, v: string) => setS((p) => ({ ...p, [k]: v }));
  const cards: [string, number, string][] = [["Toplam kullanıcı", d.stats.usersTotal, "👤"], ["Üye", d.stats.members, "✅"], ["Misafir", d.stats.guests, "○"], ["Şu an çevrimiçi", d.stats.online, "🟢"], ["Oda mesajı", d.stats.msgs, "💬"], ["Özel mesaj", d.stats.dms, "✉️"], ["Oda", d.stats.roomCount, "🚪"], ["Hediye", d.stats.gifts, "🎁"], ["Bugünkü giriş", d.stats.today, "📍"], ["Yasaklı", d.stats.bannedCount, "🚫"]];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><h2 className="text-xl font-black">Genel Bakış</h2><button onClick={async () => { if (confirm("İstatistikler sıfırlansın mı?")) { await fetch("/api/admin/stats", { method: "POST" }); notify("Sıfırlandı"); load(); } }} className="btn-danger rounded-xl px-3 py-1.5 text-xs font-extrabold">İstatistikleri sıfırla</button></div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">{cards.map(([l, v, i]) => <div key={l} className="soft rounded-2xl p-3"><div className="text-[10px] font-extrabold uppercase tracking-wider muted">{i} {l}</div><div className="text-2xl font-black">{v}</div></div>)}</div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-3"><h3 className="font-black">Site ayarları</h3>
          <Field label="Site adı"><input className="input w-full rounded-xl px-3 py-2 text-sm" value={s.siteName ?? ""} onChange={(e) => set("siteName", e.target.value)} /></Field>
          <Field label="Alan adı"><input className="input w-full rounded-xl px-3 py-2 text-sm" value={s.domain ?? ""} onChange={(e) => set("domain", e.target.value)} /></Field>
          <Field label="Duyuru bandı"><input className="input w-full rounded-xl px-3 py-2 text-sm" value={s.announcement ?? ""} onChange={(e) => set("announcement", e.target.value)} /></Field>
          <Field label="Ana tema (tüm ziyaretçiler için varsayılan)"><select className="input w-full rounded-xl px-3 py-2 text-sm" value={s.defaultTheme ?? "mor"} onChange={(e) => set("defaultTheme", e.target.value)}>{THEMES.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}</select></Field>
        </div>
        <div className="space-y-3"><h3 className="font-black">Logo & SEO</h3>
          <Field label="Logo yazısı (maks 15 harf)"><input maxLength={15} className="input w-full rounded-xl px-3 py-2 text-sm" value={s.logoText ?? ""} onChange={(e) => set("logoText", e.target.value)} /></Field>
          <Field label="Logo görseli"><div className="flex items-center gap-2">{s.logoUrl && <img src={s.logoUrl} alt="" className="h-10 rounded-lg" />}<label className="btn-ghost cursor-pointer rounded-xl px-3 py-2 text-xs font-extrabold">Yükle<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) set("logoUrl", await fileToDataUrl(f, 300)); }} /></label>{s.logoUrl && <button onClick={() => set("logoUrl", "")} className="btn-danger rounded-xl px-3 py-2 text-xs font-extrabold">Kaldır</button>}</div></Field>
          <Field label="SEO başlığı"><input className="input w-full rounded-xl px-3 py-2 text-sm" value={s.seoTitle ?? ""} onChange={(e) => set("seoTitle", e.target.value)} /></Field>
          <Field label="SEO açıklaması"><textarea rows={2} className="input w-full rounded-xl px-3 py-2 text-sm" value={s.seoDescription ?? ""} onChange={(e) => set("seoDescription", e.target.value)} /></Field>
          <Field label="Anahtar kelimeler"><input className="input w-full rounded-xl px-3 py-2 text-sm" value={s.seoKeywords ?? ""} onChange={(e) => set("seoKeywords", e.target.value)} /></Field>
        </div>
      </div>
      <button onClick={save} className="btn-primary rounded-2xl px-6 py-3 text-sm font-extrabold">Kaydet</button>
      <div className="soft rounded-2xl p-3 text-xs muted">🌐 Yönetim linki: <b>/admin</b> · Kurulum: <b>/kurulum</b> (yalnızca ilk kurulumda) · Site haritası: <b>/sitemap.xml</b> · robots: <b>/robots.txt</b></div>
    </div>
  );
}

function Users({ me, notify }: { me: PublicUser; notify: (m: string) => void }) {
  const [d, setD] = useState<{ users: U[]; total: number; page: number; pages: number } | null>(null);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [edit, setEdit] = useState<U | null>(null);
  const [ef, setEf] = useState<Record<string,string>>({});
  const load = useCallback(() => fetch(`/api/admin/users?page=${page}&q=${encodeURIComponent(q)}`, { cache: "no-store" }).then((r) => r.json()).then(setD), [page, q]);
  useEffect(() => { load(); }, [load]);
  const act = async (id: number, action: string, extra: Record<string, unknown> = {}) => { const r = await post("/api/admin/users", { id, action, ...extra }); notify(r.ok ? "✓" : r.d.error); load(); };
  const openEdit = (u: U) => { setEdit(u); setEf({ username: u.username, email: u.email ?? "", color: u.color, status: "", about: "", points: String(u.points), rank: u.rank, gender: "", country: "", city: "" }); fetch(`/api/profile/${u.id}`, { cache: "no-store" }).then((r) => r.json()).then((x) => setEf((p) => ({ ...p, status: x.user.status ?? "", about: x.user.about ?? "", color: x.user.color ?? p.color, gender: x.user.gender ?? "", country: x.user.country ?? "", city: x.user.city ?? "" }))); };
  const saveEdit = async () => {
    if (!edit) return;
    const ops: Promise<{ok:boolean; d:Record<string,unknown>}>[] = [];
    if (ef.username !== edit.username) ops.push(post("/api/admin/users", { id: edit.id, action: "update", username: ef.username }));
    if (ef.email !== (edit.email ?? "")) ops.push(post("/api/admin/users", { id: edit.id, action: "update", email: ef.email }));
    if (ef.color !== edit.color) ops.push(post("/api/admin/users", { id: edit.id, action: "update", color: ef.color }));
    if (ef.rank !== edit.rank) ops.push(post("/api/admin/users", { id: edit.id, action: "rank", rank: ef.rank }));
    if (String(ef.points) !== String(edit.points)) ops.push(post("/api/admin/users", { id: edit.id, action: "points", value: Number(ef.points) }));
    const profilePatch: Record<string,string> = {};
    if (ef.gender !== undefined) profilePatch.gender = ef.gender;
    if (ef.country !== undefined) profilePatch.country = ef.country;
    if (ef.city !== undefined) profilePatch.city = ef.city;
    if (ef.status) profilePatch.status = ef.status;
    if (ef.about) profilePatch.about = ef.about;
    if (Object.keys(profilePatch).length) await fetch("/api/admin/users", { method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify({ id: edit.id, action: "profile", ...profilePatch }) });
    for (const o of ops) { const r = await o; if (!r.ok) notify(String(r.d.error)); }
    notify("Kaydedildi ✓"); setEdit(null); load();
  };
  const myLevel = rankLevel(me.rank);
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2"><h2 className="text-xl font-black">Kullanıcılar {d && <span className="text-sm muted">({d.total})</span>}</h2><input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Ara… (kullanıcı adı / e-posta)" className="input ml-auto rounded-xl px-3 py-2 text-sm" /></div>
      <div className="scroll-thin mt-4 overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead><tr className="muted"><th className="p-2">Kullanıcı</th><th className="p-2">Rütbe</th><th className="p-2">Puan</th><th className="p-2">Lv</th><th className="p-2">Durum</th><th className="p-2">IP</th><th className="p-2">Son görülme</th><th className="p-2">İşlemler</th></tr></thead>
          <tbody>{d?.users.map((u) => { const can = rankLevel(u.rank) < myLevel || u.id === me.id; return (
            <tr key={u.id} className="border-t hover:bg-[var(--surface-2)]" style={{ borderColor: "var(--border)" }}>
              <td className="p-2"><div className="flex items-center gap-2"><Avatar name={u.username} color={u.color} url={u.avatarUrl} size={26} verified={u.isVerified} /><div><div className="font-extrabold flex items-center gap-1" style={{ color: u.color }}>{u.username} {u.isDj && "🎧"} {u.isBanned && <span className="text-rose-500">(yasaklı)</span>}</div><div className="muted truncate max-w-[160px]">{u.email ?? (u.isGuest ? "misafir" : "")}</div></div></div></td>
              <td className="p-2">{can && !u.isGuest ? <select value={u.rank} onChange={(e) => act(u.id, "rank", { rank: e.target.value })} className="input rounded-lg px-2 py-1">{RANK_ORDER.filter((r) => RANKS[r].level < myLevel).map((r) => <option key={r} value={r}>{RANKS[r].label}</option>)}</select> : <RankBadge rank={u.rank} compact />}</td>
              <td className="p-2">{me.rank === "kurucu" ? <input type="number" defaultValue={u.points} onBlur={(e) => Number(e.target.value) !== u.points && act(u.id, "points", { value: Number(e.target.value) })} className="input w-20 rounded-lg px-2 py-1" /> : u.points}</td>
              <td className="p-2">{u.level}</td>
              <td className="p-2 truncate max-w-[120px] muted">{(u as unknown as { status?: string }).status ?? "—"}</td>
              <td className="p-2 font-mono">{u.lastIp ?? "—"}</td>
              <td className="p-2 muted whitespace-nowrap">{new Date(u.lastSeen).toLocaleString("tr-TR")}</td>
              <td className="p-2"><div className="flex flex-wrap gap-1">
                <button onClick={() => openEdit(u)} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">✏️ Düzenle</button>
                {can && me.rank === "kurucu" && !u.isGuest && <button onClick={() => act(u.id, "dj", { value: !u.isDj })} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">{u.isDj ? "DJ al" : "DJ yap"}</button>}
                {can && !u.isGuest && <button onClick={() => { const p = prompt("Yeni şifre:", "1234"); if (p) act(u.id, "password", { value: p }); }} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Şifre</button>}
                {can && <button onClick={() => act(u.id, "kick")} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Siteden at</button>}
                {can && (u.isBanned ? <button onClick={() => act(u.id, "unban")} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Yasağı kaldır</button> : <button onClick={() => act(u.id, "ban", { withIp: true })} className="btn-danger rounded-lg px-2 py-1 font-extrabold">Yasakla</button>)}
                {u.mutedUntil && new Date(u.mutedUntil).getTime() > Date.now() && <button onClick={() => act(u.id, "unmute")} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">🔊</button>}
                {can && me.rank === "kurucu" && <button onClick={() => confirm(`${u.username} silinsin mi?`) && act(u.id, "delete")} className="btn-danger rounded-lg px-2 py-1 font-extrabold">Sil</button>}
              </div></td>
            </tr>); })}</tbody>
        </table>
      </div>
      {d && d.pages > 1 && <div className="mt-3 flex justify-center gap-1">{Array.from({ length: d.pages }).map((_, i) => <button key={i} onClick={() => setPage(i + 1)} className={`rounded-lg px-3 py-1 text-xs font-extrabold ${page === i + 1 ? "brand-gradient text-white" : "btn-ghost"}`}>{i + 1}</button>)}</div>}
      {edit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setEdit(null)}>
          <div className="card w-full max-w-lg rounded-3xl p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-lg font-black">✏️ {edit.username} — Tüm Bilgileri Düzenle</div>
            <p className="text-[11px] muted">Yönetim yetkisiyle hesabın her alanını değiştirebilirsin. Değişiklikler anında uygulanır.</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="label">Kullanıcı adı<input value={ef.username} onChange={(e) => setEf({ ...ef, username: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
              <label className="label">E-posta<input value={ef.email} onChange={(e) => setEf({ ...ef, email: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
              <label className="label">Renk<input type="color" value={ef.color} onChange={(e) => setEf({ ...ef, color: e.target.value })} className="h-9 w-full rounded-lg" /></label>
              <label className="label">Rütbe<select value={ef.rank} onChange={(e) => setEf({ ...ef, rank: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm">{RANK_ORDER.filter((r) => RANKS[r].level < myLevel).map((r) => <option key={r} value={r}>{RANKS[r].label}</option>)}</select></label>
              <label className="label">Cinsiyet<select value={ef.gender} onChange={(e) => setEf({ ...ef, gender: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm"><option value="">Belirtme</option><option value="kadin">♀ Kadın</option><option value="erkek">♂ Erkek</option><option value="diger">⚧ Diğer</option></select></label>
              <label className="label">Ülke<select value={ef.country} onChange={(e) => setEf({ ...ef, country: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm"><option value="">Seç</option>{COUNTRIES.map((c) => <option key={c.code||c.name} value={c.name}>{c.flag} {c.name}</option>)}</select></label>
              <label className="label">Şehir<input value={ef.city} onChange={(e) => setEf({ ...ef, city: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
              <label className="label">Puan<input type="number" value={ef.points} onChange={(e) => setEf({ ...ef, points: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
              <label className="label">Durum<input value={ef.status} onChange={(e) => setEf({ ...ef, status: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
              <label className="label col-span-2">Hakkımda<textarea value={ef.about} onChange={(e) => setEf({ ...ef, about: e.target.value })} rows={3} className="input w-full rounded-xl px-3 py-2 text-sm" /></label>
            </div>
            <div className="mt-4 flex gap-2"><button onClick={saveEdit} className="btn-primary flex-1 rounded-xl py-2.5 text-sm font-extrabold">Kaydet</button><button onClick={() => setEdit(null)} className="btn-ghost flex-1 rounded-xl py-2.5 text-sm font-extrabold">İptal</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

function Bots({ notify }: { notify: (m: string) => void }) {
  const [bots, setBots] = useState<Bot[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [nb, setNb] = useState({ username: "", botKind: "security" });
  const [say, setSay] = useState<Record<number, { roomId: number; text: string }>>({});
  const load = useCallback(() => { fetch("/api/admin/bots", { cache: "no-store" }).then((r) => r.json()).then((d) => setBots(d.bots ?? [])); fetch("/api/rooms", { cache: "no-store" }).then((r) => r.json()).then((d) => setRooms(d.rooms)); }, []);
  useEffect(() => { load(); }, [load]);
  const act = async (body: Record<string, unknown>) => { const r = await post("/api/admin/bots", body); notify(r.ok ? "✓" : r.d.error); load(); };
  const kindLabel = (k: string) => ({ nova: "🤖 Yapay zekâ (Nova)", dj: "🎧 DJ botu", security: "🛡 Güvenlik botu", user: "👤 Kullanıcı botu" })[k] ?? k;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2"><h2 className="text-xl font-black">Botlar</h2><div className="ml-auto flex gap-2"><button onClick={() => act({ action: "toggleAll", value: true })} className="btn-ghost rounded-xl px-3 py-1.5 text-xs font-extrabold">Tümünü aç</button><button onClick={() => act({ action: "toggleAll", value: false })} className="btn-danger rounded-xl px-3 py-1.5 text-xs font-extrabold">Tümünü kapat</button></div></div>
      <div className="soft flex flex-wrap items-end gap-2 rounded-2xl p-3"><Field label="Yeni bot adı"><input value={nb.username} onChange={(e) => setNb({ ...nb, username: e.target.value })} className="input rounded-xl px-3 py-2 text-sm" /></Field><Field label="Tür"><select value={nb.botKind} onChange={(e) => setNb({ ...nb, botKind: e.target.value })} className="input rounded-xl px-3 py-2 text-sm"><option value="security">Güvenlik</option><option value="nova">Yapay zekâ</option><option value="dj">DJ</option><option value="user">Kullanıcı (sohbet eder)</option></select></Field><button onClick={() => { act({ action: "create", ...nb }); setNb({ username: "", botKind: "security" }); }} className="btn-primary rounded-xl px-4 py-2 text-sm font-extrabold">+ Bot ekle</button><span className="text-[11px] muted">Sınırsız bot — kullanıcı botları odalarda doğal sohbet eder.</span></div>
      <div className="grid gap-3 md:grid-cols-2">{bots.map((b) => (
        <div key={b.id} className="card rounded-2xl p-3">
          <div className="flex items-center gap-3"><Avatar name={b.username} color={b.color} url={b.avatarUrl} size={40} /><div className="min-w-0 flex-1"><input defaultValue={b.username} onBlur={(e) => e.target.value !== b.username && act({ action: "update", id: b.id, username: e.target.value })} className="input w-full rounded-lg px-2 py-1 text-sm font-extrabold" title="İsmi değiştir (çalışmaya devam eder)" /><div className="text-[11px] muted">{kindLabel(b.botKind)}</div></div><button onClick={() => act({ action: "update", id: b.id, botEnabled: !b.botEnabled })} className={`rounded-xl px-3 py-1.5 text-xs font-extrabold ${b.botEnabled ? "brand-gradient text-white" : "btn-ghost"}`}>{b.botEnabled ? "Açık" : "Kapalı"}</button></div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Field label="Oda ataması"><select value={b.botRoomMode} onChange={(e) => act({ action: "update", id: b.id, botRoomMode: e.target.value })} className="input w-full rounded-lg px-2 py-1 text-xs"><option value="roam">Serbest gezer</option><option value="all">Tüm odalarda</option><option value="fixed">Belirli oda</option></select></Field>
            <Field label="Oda"><select value={b.botRoomId ?? ""} onChange={(e) => act({ action: "update", id: b.id, botRoomId: e.target.value ? Number(e.target.value) : null })} className="input w-full rounded-lg px-2 py-1 text-xs" disabled={b.botRoomMode !== "fixed"}><option value="">—</option>{rooms.map((r) => <option key={r.id} value={r.id}>{r.icon} {r.name}</option>)}</select></Field>
          </div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs">
            <label className="btn-ghost cursor-pointer rounded-lg px-2 py-1 font-extrabold">🖼 Foto<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) act({ action: "update", id: b.id, avatarUrl: await fileToDataUrl(f, 256) }); }} /></label>
            <label className="btn-ghost cursor-pointer rounded-lg px-2 py-1 font-extrabold">🏞 Arka plan<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) act({ action: "update", id: b.id, bannerUrl: await fileToDataUrl(f, 800) }); }} /></label>
            <input type="color" value={b.color} onChange={(e) => act({ action: "update", id: b.id, color: e.target.value })} className="h-7 w-9 rounded-lg" />
            <button onClick={() => confirm("Bot silinsin mi?") && act({ action: "delete", id: b.id })} className="btn-danger ml-auto rounded-lg px-2 py-1 font-extrabold">Sil</button>
          </div>
          <div className="mt-2 flex gap-1"><select value={say[b.id]?.roomId ?? rooms[0]?.id ?? 0} onChange={(e) => setSay({ ...say, [b.id]: { roomId: Number(e.target.value), text: say[b.id]?.text ?? "" } })} className="input rounded-lg px-2 py-1 text-xs">{rooms.map((r) => <option key={r.id} value={r.id}>{r.icon} {r.name}</option>)}</select><input value={say[b.id]?.text ?? ""} onChange={(e) => setSay({ ...say, [b.id]: { roomId: say[b.id]?.roomId ?? rooms[0]?.id ?? 0, text: e.target.value } })} placeholder="Botu konuştur…" className="input flex-1 rounded-lg px-2 py-1 text-xs" /><button onClick={() => { const s = say[b.id]; if (s?.text) { act({ action: "say", id: b.id, roomId: s.roomId || rooms[0]?.id, text: s.text }); setSay({ ...say, [b.id]: { ...s, text: "" } }); } }} className="btn-primary rounded-lg px-3 text-xs font-extrabold">Söylet</button></div>
        </div>))}</div>
      <div className="soft rounded-2xl p-3 text-xs muted">💡 Nova: sunucuda <b>OPENAI_API_KEY</b> varsa gerçek modelle, yoksa hazır kurallarla cevap verir. DJ botu Müzik odasında yazılan şarkı adını iTunes kataloğundan bulur. Güvenlik botları kelime kurallarını uygular.</div>
    </div>
  );
}

function Radio({ notify }: { notify: (m: string) => void }) {
  const [s, setS] = useState<Record<string, string>>({});
  useEffect(() => { fetch("/api/admin/stats", { cache: "no-store" }).then((r) => r.json()).then((d) => setS(d.settings)); }, []);
  const save = async () => { const r = await post("/api/admin/settings", { radioEnabled: s.radioEnabled, radioStation: s.radioStation, customRadioUrl: s.customRadioUrl }); notify(r.ok ? "Kaydedildi ✓" : r.d.error); };
  return (
    <div className="max-w-lg space-y-4"><h2 className="text-xl font-black">Radyo</h2>
      <div className="soft flex items-center justify-between rounded-2xl p-3"><span className="text-sm font-extrabold">Radyo oynatıcı</span><button onClick={() => setS({ ...s, radioEnabled: s.radioEnabled === "1" ? "0" : "1" })} className={`rounded-xl px-3 py-1.5 text-xs font-extrabold ${s.radioEnabled === "1" ? "brand-gradient text-white" : "btn-ghost"}`}>{s.radioEnabled === "1" ? "Açık" : "Kapalı"}</button></div>
      <Field label="Varsayılan istasyon"><select value={s.radioStation ?? ""} onChange={(e) => setS({ ...s, radioStation: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm">{RADIO_STATIONS.map((r) => <option key={r.id} value={r.id}>{r.name} — {r.genre}</option>)}</select></Field>
      <Field label="Özel yayın adresi (opsiyonel)"><input value={s.customRadioUrl ?? ""} onChange={(e) => setS({ ...s, customRadioUrl: e.target.value })} placeholder="https://…/stream" className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
      <button onClick={save} className="btn-primary rounded-2xl px-6 py-3 text-sm font-extrabold">Kaydet</button>
      <div className="soft rounded-2xl p-3 text-xs muted">Çalan parça 30 saniyede bir Radyo odasına yazılır. DJ yetkisini Kullanıcılar sekmesinden verebilirsin.</div>
    </div>
  );
}

function Rooms({ notify }: { notify: (m: string) => void }) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [users, setUsers] = useState<U[]>([]);
  const [nr, setNr] = useState({ name: "", icon: "💬", description: "", kind: "chat" });
  const load = useCallback(() => { fetch("/api/rooms", { cache: "no-store" }).then((r) => r.json()).then((d) => setRooms(d.rooms)); fetch("/api/admin/users?page=1", { cache: "no-store" }).then((r) => r.json()).then((d) => setUsers(d.users ?? [])); }, []);
  useEffect(() => { load(); }, [load]);
  const upd = async (id: number, body: Record<string, unknown>) => { const r = await post("/api/admin/rooms", { id, ...body }); notify(r.ok ? "✓" : r.d.error); load(); };
  const create = async () => { const r = await post("/api/rooms", nr); notify(r.ok ? "Oda açıldı ✓" : r.d.error); setNr({ name: "", icon: "💬", description: "", kind: "chat" }); load(); };
  return (
    <div className="space-y-4"><h2 className="text-xl font-black">Odalar</h2>
      <div className="soft flex flex-wrap items-end gap-2 rounded-2xl p-3"><Field label="Simge"><input value={nr.icon} onChange={(e) => setNr({ ...nr, icon: e.target.value })} className="input w-14 rounded-xl px-2 py-2 text-center text-sm" /></Field><Field label="Oda adı"><input value={nr.name} onChange={(e) => setNr({ ...nr, name: e.target.value })} className="input rounded-xl px-3 py-2 text-sm" /></Field><Field label="Açıklama"><input value={nr.description} onChange={(e) => setNr({ ...nr, description: e.target.value })} className="input rounded-xl px-3 py-2 text-sm" /></Field><Field label="Tür"><select value={nr.kind} onChange={(e) => setNr({ ...nr, kind: e.target.value })} className="input rounded-xl px-3 py-2 text-sm"><option value="chat">Sohbet</option><option value="music">Müzik (DJ)</option><option value="ai">Yapay zekâ</option><option value="radio">Radyo</option><option value="okey">Okey</option></select></Field><button onClick={create} className="btn-primary rounded-xl px-4 py-2 text-sm font-extrabold">+ Oda aç</button></div>
      <div className="grid gap-3 md:grid-cols-2">{rooms.map((r) => (
        <div key={r.id} className="card rounded-2xl p-3">
          <div className="flex items-center gap-2"><input defaultValue={r.icon} onBlur={(e) => e.target.value !== r.icon && upd(r.id, { icon: e.target.value })} className="input w-12 rounded-lg px-1 py-1 text-center text-lg" />{r.imageUrl && <img src={r.imageUrl} alt="" className="h-9 w-9 rounded-lg object-cover" />}<input defaultValue={r.name} onBlur={(e) => e.target.value !== r.name && upd(r.id, { name: e.target.value })} className="input flex-1 rounded-lg px-2 py-1 text-sm font-extrabold" title="Oda adını değiştir" /><span className="text-[10px] muted">{r.online} kişi</span></div>
          <input defaultValue={r.description} onBlur={(e) => e.target.value !== r.description && upd(r.id, { description: e.target.value })} placeholder="Açıklama" className="input mt-2 w-full rounded-lg px-2 py-1 text-xs" />
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Field label="Tür"><select value={r.kind} onChange={(e) => upd(r.id, { kind: e.target.value })} className="input w-full rounded-lg px-2 py-1 text-xs"><option value="chat">Sohbet</option><option value="music">Müzik</option><option value="ai">Yapay zekâ</option><option value="radio">Radyo</option><option value="okey">Okey</option></select></Field>
            <Field label="Oda sahibi"><select value={r.ownerId ?? ""} onChange={(e) => upd(r.id, { ownerId: e.target.value ? Number(e.target.value) : null })} className="input w-full rounded-lg px-2 py-1 text-xs"><option value="">— yok —</option>{users.filter((u) => !u.isGuest).map((u) => <option key={u.id} value={u.id}>{u.username}</option>)}</select></Field>
          </div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs">
            <label className="btn-ghost cursor-pointer rounded-lg px-2 py-1 font-extrabold">🖼 Oda resmi<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) upd(r.id, { imageUrl: await fileToDataUrl(f, 256) }); }} /></label>
            <label className="btn-ghost cursor-pointer rounded-lg px-2 py-1 font-extrabold">🏞 Arka plan<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) upd(r.id, { bgUrl: await fileToDataUrl(f, 1200) }); }} /></label>
            {r.bgUrl && <button onClick={() => upd(r.id, { bgUrl: "" })} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Arka planı kaldır</button>}
            {!r.isDefault && <button onClick={() => confirm(`${r.name} silinsin mi?`) && upd(r.id, { action: "delete" })} className="btn-danger ml-auto rounded-lg px-2 py-1 font-extrabold">Sil</button>}
          </div>
        </div>))}</div>
    </div>
  );
}

function Security({ notify }: { notify: (m: string) => void }) {
  const [rules, setRules] = useState<{ id: number; word: string; replacement: string }[]>([]);
  const [bans, setBans] = useState<{ id: number; username: string; ip: string | null; reason: string; byUsername: string; active: boolean; createdAt: string }[]>([]);
  const [s, setS] = useState<Record<string, string>>({});
  const [nr, setNr] = useState({ word: "", replacement: "" });
  const load = useCallback(() => { fetch("/api/admin/security", { cache: "no-store" }).then((r) => r.json()).then((d) => { setRules(d.rules); setBans(d.bans); }); fetch("/api/admin/stats", { cache: "no-store" }).then((r) => r.json()).then((d) => setS(d.settings)); }, []);
  useEffect(() => { load(); }, [load]);
  const act = async (b: Record<string, unknown>) => { const r = await post("/api/admin/security", b); notify(r.ok ? "✓" : r.d.error); load(); };
  return (
    <div className="space-y-5"><h2 className="text-xl font-black">Güvenlik</h2>
      <div className="grid gap-4 md:grid-cols-2">
        <div><h3 className="font-black">Kelime kuralları</h3><p className="text-[11px] muted">Yasaklı kelime → yerine geçecek kelime. İhlalde güvenlik botu susturur.</p>
          <div className="mt-2 flex gap-1"><input value={nr.word} onChange={(e) => setNr({ ...nr, word: e.target.value })} placeholder="yasaklı" className="input flex-1 rounded-lg px-2 py-1.5 text-xs" /><input value={nr.replacement} onChange={(e) => setNr({ ...nr, replacement: e.target.value })} placeholder="yerine" className="input flex-1 rounded-lg px-2 py-1.5 text-xs" /><button onClick={() => { if (nr.word) { act({ action: "addRule", ...nr }); setNr({ word: "", replacement: "" }); } }} className="btn-primary rounded-lg px-3 text-xs font-extrabold">Ekle</button></div>
          <div className="mt-2 space-y-1">{rules.map((r) => <div key={r.id} className="soft flex items-center gap-2 rounded-lg px-2 py-1 text-xs"><b>{r.word}</b> → {r.replacement}<button onClick={() => act({ action: "deleteRule", id: r.id })} className="ml-auto text-rose-500">✕</button></div>)}</div>
        </div>
        <div><h3 className="font-black">Ceza ayarları</h3>
          <Field label="İhlalde susturma (dakika)"><input type="number" value={s.securityMuteMinutes ?? ""} onChange={(e) => setS({ ...s, securityMuteMinutes: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Kaç ihlalde yasak"><input type="number" value={s.securityBanAfter ?? ""} onChange={(e) => setS({ ...s, securityBanAfter: e.target.value })} className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <button onClick={async () => { const r = await post("/api/admin/settings", { securityMuteMinutes: s.securityMuteMinutes, securityBanAfter: s.securityBanAfter }); notify(r.ok ? "Kaydedildi ✓" : r.d.error); }} className="btn-primary mt-3 rounded-xl px-4 py-2 text-sm font-extrabold">Kaydet</button>
          <div className="soft mt-3 rounded-2xl p-3 text-[11px] muted">🧠 Akıllı moderatör: telefon numaraları ve rakip site linkleri otomatik gizlenir, küfürler maskelenir, 5 sn'de 5+ mesaj flood sayılır. Güvenlik botlarını Botlar sekmesinden ekleyebilirsin.</div>
        </div>
      </div>
      <div><h3 className="font-black">Yasaklar</h3><div className="mt-2 space-y-1">{bans.map((b) => <div key={b.id} className="soft flex flex-wrap items-center gap-2 rounded-lg px-2 py-1 text-xs"><b>{b.username}</b><span className="font-mono muted">{b.ip ?? "—"}</span><span className="muted">{b.reason}</span><span className="muted">· {b.byUsername}</span><span className={`ml-auto rounded-full px-2 ${b.active ? "bg-rose-100 text-rose-600" : "bg-emerald-100 text-emerald-600"}`}>{b.active ? "aktif" : "kaldırıldı"}</span>{b.active && <button onClick={() => act({ action: "liftBan", id: b.id })} className="btn-ghost rounded-lg px-2 py-0.5 font-extrabold">Kaldır</button>}</div>)}{bans.length === 0 && <div className="text-xs muted">Yasak yok.</div>}</div></div>
    </div>
  );
}

function Activity({ notify }: { notify: (m: string) => void }) {
  const [rows, setRows] = useState<Act[]>([]);
  const load = useCallback(() => fetch("/api/admin/activity", { cache: "no-store" }).then((r) => r.json()).then((d) => setRows(d.activity ?? [])), []);
  useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, [load]);
  const act = async (id: number, action: string) => { const r = await post("/api/admin/users", { id, action, withIp: true }); notify(r.ok ? "✓" : r.d.error); load(); };
  const label = (a: string) => ({ login: "🔑 Giriş", register: "✨ Kayıt", guest: "○ Misafir", logout: "🚪 Çıkış", kick: "👢 Atıldı", ban: "🚫 Yasak" })[a] ?? a;
  return (
    <div><h2 className="text-xl font-black">Hareketler</h2><p className="text-[11px] muted">Giriş/çıkışlar IP ve şehir bilgisiyle. Buradan anında at, yasakla veya yasağı kaldır.</p>
      <div className="scroll-thin mt-3 overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="muted"><th className="p-2">Zaman</th><th className="p-2">Kullanıcı</th><th className="p-2">İşlem</th><th className="p-2">IP</th><th className="p-2">Konum</th><th className="p-2">Butonlar</th></tr></thead>
        <tbody>{rows.map((r) => <tr key={r.id} className="border-t" style={{ borderColor: "var(--border)" }}><td className="p-2 muted">{new Date(r.createdAt).toLocaleString("tr-TR")}</td><td className="p-2 font-extrabold">{r.username} {r.rank && <RankBadge rank={r.rank} compact />}</td><td className="p-2">{label(r.action)}</td><td className="p-2 font-mono">{r.ip}</td><td className="p-2">{[r.city, r.country].filter(Boolean).join(", ") || "—"}</td><td className="p-2">{r.userId && <div className="flex gap-1"><button onClick={() => act(r.userId!, "kick")} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Siteden at</button>{r.isBanned ? <button onClick={() => act(r.userId!, "unban")} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">Yasağı kaldır</button> : <button onClick={() => act(r.userId!, "ban")} className="btn-danger rounded-lg px-2 py-1 font-extrabold">Yasakla</button>}</div>}</td></tr>)}</tbody></table></div>
    </div>
  );
}

function ModPanel({ notify }: { notify: (m: string) => void }) {
  const [muted, setMuted] = useState<{ id: number; username: string; color: string; avatarUrl: string | null; rank: string; mutedUntil: string }[]>([]);
  const [banned, setBanned] = useState<{ id: number; userId: number | null; username: string; ip: string | null; reason: string; active: boolean }[]>([]);
  const load = useCallback(() => {
    fetch("/api/admin/mod", { cache: "no-store" }).then((r) => r.json()).then((d) => { setMuted(d.muted ?? []); setBanned(d.banned ?? []); });
  }, []);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);
  const act = async (body: Record<string, unknown>) => {
    const r = await fetch("/api/admin/mod", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    notify(r.ok ? "✓ İşlem tamam" : d.error); load();
  };
  return (
    <div className="space-y-6">
      <div><h2 className="text-xl font-black">🛠 Mod Panel — Sadece Yasak/Susturma Kaldırma</h2><p className="text-xs muted">Admin yetkisiyle sadece <b>yasak kaldırma</b> ve <b>susturma açma</b> yapabilirsin. Diğer yönetim işlemleri Kurucu içindir.</p></div>
      <div className="grid gap-4 md:grid-cols-2">
        <div><h3 className="font-black">🔇 Susturulanlar ({muted.length})</h3>
          <div className="mt-2 space-y-1">{muted.map((u) => <div key={u.id} className="soft flex items-center gap-2 rounded-xl px-3 py-2"><Avatar name={u.username} color={u.color} url={u.avatarUrl} size={28} /><div className="min-w-0 flex-1"><div className="text-sm font-extrabold" style={{ color: u.color }}>{u.username} <RankBadge rank={u.rank} compact /></div><div className="text-[11px] muted">Kalan: {Math.ceil((new Date(u.mutedUntil).getTime() - Date.now()) / 60000)} dk</div></div><button onClick={() => act({ action: "unmute", id: u.id })} className="btn-primary rounded-lg px-3 py-1 text-xs font-extrabold">🔊 Aç</button></div>)}{muted.length === 0 && <div className="soft rounded-xl p-4 text-center text-xs muted">Şu an susturulan yok — tertemiz!</div>}</div>
        </div>
        <div><h3 className="font-black">🚫 Yasaklılar ({banned.length})</h3>
          <div className="mt-2 space-y-1">{banned.map((b) => <div key={b.id} className="soft flex items-center gap-2 rounded-xl px-3 py-2"><div className="min-w-0 flex-1"><div className="text-sm font-extrabold">{b.username}</div><div className="text-[11px] muted">{b.reason} · {b.ip ?? "IP yok"}</div></div><button onClick={() => act({ action: "unban", id: b.id, userId: b.userId })} className="btn-primary rounded-lg px-3 py-1 text-xs font-extrabold">Yasağı Kaldır</button></div>)}{banned.length === 0 && <div className="soft rounded-xl p-4 text-center text-xs muted">Yasaklı yok.</div>}</div>
        </div>
      </div>
      <div className="soft rounded-2xl p-3 text-xs muted">💡 Kurucu değilsen sadece bu paneldeki butonlar aktif — diğer sekmeler gizlidir. Susturma/ban açma anında tüm odalara yansır.</div>
    </div>
  );
}

function BlogAdmin({ notify }: { notify: (m: string) => void }) {
  const [posts, setPosts] = useState<{ id: number; slug: string; title: string; excerpt: string; imageUrl: string | null; content: string; authorName: string; views: number; createdAt: string }[]>([]);
  const [form, setForm] = useState({ title: "", excerpt: "", content: "", imageUrl: "" });
  const [editing, setEditing] = useState<number | null>(null);
  const [comments, setComments] = useState<Record<number, { id: number; username: string; content: string }[]>>({});
  const load = useCallback(() => fetch("/api/blog", { cache: "no-store" }).then((r) => r.json()).then((d) => setPosts(d.posts ?? [])), []);
  useEffect(() => { load(); }, [load]);
  const loadComments = async (id: number) => { const r = await fetch(`/api/blog/${id}`, { cache: "no-store" }); if (r.ok) { const d = await r.json(); setComments((p) => ({ ...p, [id]: d.comments ?? [] })); } };
  const submit = async () => {
    const url = editing ? `/api/blog/${editing}` : "/api/blog";
    const method = editing ? "PATCH" : "POST";
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) notify(d.error ?? "Hata"); else { notify(editing ? "Güncellendi ✓" : "Oluşturuldu ✓"); setForm({ title: "", excerpt: "", content: "", imageUrl: "" }); setEditing(null); load(); }
  };
  const delPost = async (id: number) => { if (!confirm("Silinsin mi?")) return; await fetch(`/api/blog/${id}`, { method: "DELETE" }); load(); };
  const delComment = async (cid: number, pid: number) => { await fetch(`/api/blog/comments/${cid}`, { method: "DELETE" }); loadComments(pid); };
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-black">📝 Blog Yönetimi</h2>
      <div className="card rounded-2xl p-4">
        <div className="text-sm font-black">{editing ? "Yazıyı düzenle" : "Yeni yazı"}</div>
        <div className="mt-2 grid gap-3">
          <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Başlık (konu)" className="input rounded-xl px-3 py-2 text-sm font-bold" />
          <input value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} placeholder="Özet (200 karakter)" className="input rounded-xl px-3 py-2 text-sm" />
          <div className="flex gap-2"><input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="Görsel URL https://..." className="input flex-1 rounded-xl px-3 py-2 text-sm" /><label className="btn-ghost cursor-pointer rounded-xl px-3 py-2 text-xs font-bold">Yükle<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) { const { fileToDataUrl } = await import("@/components/ui"); setForm({ ...form, imageUrl: await fileToDataUrl(f, 800) }); } }} /></label></div>
          {form.imageUrl && <img src={form.imageUrl} alt="" className="h-32 w-full rounded-xl object-cover" />}
          <textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} placeholder="İçerik (uzun yazı)" rows={6} className="input rounded-xl px-3 py-2 text-sm" />
          <div className="flex gap-2"><button onClick={submit} className="btn-primary rounded-xl px-4 py-2 text-sm font-extrabold">{editing ? "Güncelle" : "Yayınla"}</button>{editing && <button onClick={() => { setEditing(null); setForm({ title: "", excerpt: "", content: "", imageUrl: "" }); }} className="btn-ghost rounded-xl px-4 py-2 text-sm font-bold">İptal</button>}</div>
        </div>
      </div>
      <div className="space-y-3">
        {posts.map((p) => (
          <div key={p.id} className="card rounded-2xl p-3">
            <div className="flex gap-3"><div className="min-w-0 flex-1"><div className="font-black">{p.title}</div><div className="text-xs muted line-clamp-1">{p.excerpt}</div><div className="text-[11px] muted">👁 {p.views} · {new Date(p.createdAt).toLocaleDateString("tr-TR")}</div></div>{p.imageUrl && <img src={p.imageUrl} alt="" className="h-16 w-16 rounded-xl object-cover" />}</div>
            <div className="mt-2 flex gap-1"><button onClick={() => { setEditing(p.id); setForm({ title: p.title, excerpt: p.excerpt, content: p.content, imageUrl: p.imageUrl ?? "" }); }} className="btn-ghost rounded-lg px-2 py-1 text-xs font-bold">Düzenle</button><button onClick={() => delPost(p.id)} className="btn-danger rounded-lg px-2 py-1 text-xs font-bold">Sil</button><button onClick={() => loadComments(p.id)} className="btn-ghost rounded-lg px-2 py-1 text-xs font-bold">Yorumlar ({comments[p.id]?.length ?? "…"})</button></div>
            {comments[p.id] && <div className="mt-2 space-y-1">{comments[p.id].map((c) => <div key={c.id} className="soft flex items-center gap-2 rounded-lg px-2 py-1 text-xs"><b>{c.username}:</b><span className="flex-1 truncate">{c.content}</span><button onClick={() => delComment(c.id, p.id)} className="text-rose-500">Sil</button></div>)}{comments[p.id].length===0 && <div className="text-xs muted">Yorum yok.</div>}</div>}
          </div>
        ))}
        {posts.length===0 && <div className="py-6 text-center text-sm muted">Henüz yazı yok.</div>}
      </div>
    </div>
  );
}

function LicensesAdmin({ me, notify }: { me: PublicUser; notify: (m: string) => void }) {
  const isSercan = me.username.toLowerCase() === "sercan";
  const [list, setList] = useState<{ id: number; key: string; isUsed: boolean; usedBy: string | null; usedAt: string | null; status: string; note: string; expiresAt: string | null }[]>([]);
  const load = useCallback(() => {
    if (!isSercan) return;
    fetch("/api/admin/licenses", { cache: "no-store" }).then((r) => r.json()).then((d) => setList(d.licenses ?? [])).catch(()=>{});
  }, [isSercan]);
  useEffect(() => { load(); }, [load]);
  const [activateKey, setActivateKey] = useState("");
  const [status, setStatusState] = useState<{ license: { key: string; status: string } | null; status: string; message: string } | null>(null);
  useEffect(() => { fetch("/api/license/status", { cache: "no-store" }).then((r) => r.json()).then(setStatusState).catch(()=>{}); }, []);
  const copyAll = () => { navigator.clipboard.writeText(list.map((l) => l.key).join("\n")); notify("Tüm anahtarlar kopyalandı"); };
  const setStatus = async (key: string, status: string) => {
    const note = prompt(`Not (opsiyonel):`, "") ?? "";
    const expiresAt = status === "suspended" ? null : undefined;
    const r = await fetch("/api/admin/licenses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "status", key, status, note, expiresAt }) });
    const d = await r.json().catch(()=>({}));
    notify(r.ok ? `Lisans ${status} yapıldı — müşteri anında görecek` : d.error);
    load();
  };
  const activate = async () => {
    const r = await fetch("/api/license/activate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ licenseKey: activateKey }) });
    const d = await r.json().catch(()=>({}));
    notify(r.ok ? `Lisans aktif edildi ✓ ${d.key} — artık başka aktivasyon alamazsınız` : d.error);
    if (r.ok) { setActivateKey(""); load(); fetch("/api/license/status", { cache: "no-store" }).then((r2)=>r2.json()).then(setStatusState); }
  };
  return (
    <div className="space-y-4">
      <div className="card rounded-2xl p-4 border-2" style={{ borderColor: status?.status === "active" ? "#10b981" : status?.status === "suspended" ? "#f59e0b" : "#e5e7eb", background: status?.status === "active" ? "#ecfdf5" : status?.status === "suspended" ? "#fffbeb" : status?.status === "no-license" ? "#fef2f2" : "#f9fafb" }}>
        <div className="flex items-center gap-2"><span className="text-lg">{status?.status === "active" ? "✅" : status?.status === "suspended" ? "⏸" : status?.status === "no-license" ? "⚠️" : "🔑"}</span><div><div className="text-sm font-black">Bu Sitenin Lisansı: {status?.license?.key ?? "— yok —"} · {status?.message ?? "Yükleniyor..."}</div><div className="text-xs muted">Durum: <b>{status?.status ?? "..."}</b> {status?.license?.key && `· ${status.license.key}`}</div></div></div>
        <div className="mt-3 flex gap-2"><input disabled={status?.status === "active"} value={activateKey} onChange={(e)=>setActivateKey(e.target.value.toUpperCase())} placeholder={status?.status === "active" ? `Zaten aktif: ${status.license?.key} — aktif edildi ✓` : "SRCN-XXXX-XXXX-XXXX-XXXX — satın aldığın anahtarı gir"} className="input flex-1 rounded-xl px-3 py-2 text-sm font-mono font-bold disabled:opacity-60" /><button disabled={status?.status === "active"} onClick={activate} className="btn-primary rounded-xl px-4 py-2 text-sm font-extrabold disabled:opacity-40 disabled:cursor-not-allowed">{status?.status === "active" ? "Aktif ✓" : "Aktif Et"}</button></div>
        {status?.status === "active" && <div className="mt-2 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-2 text-xs font-bold text-emerald-700">✅ Aktif edildi — {status.license?.key} ile lisanslandı. Artık başka aktivasyon alamazsınız.</div>}
        {status?.status !== "active" && <div className="mt-1 text-[11px] muted">Kurulumda boş bıraktıysan buradan sonra lisans girip aktif edebilirsin. Geçerli anahtar tek kullanımlıktır, girince “Aktif edildi” yazar ve tekrar kullanılamaz. Lisans için WhatsApp: <a href="https://wa.me/905355741849" target="_blank" className="font-bold underline" style={{ color: "#10b981" }}>+90 535 574 18 49</a></div>}
      </div>
      {!isSercan ? (
        <div className="soft rounded-2xl p-6 text-center"><div className="text-2xl">🔒</div><div className="mt-2 text-sm font-black">Lisans kodları sadece en yüksek yetkili Sercan’da</div><div className="text-xs muted">Bu havuzu sadece <b>Sercan</b> görür. Sistemi satın alanlar kodları WhatsApp <a href="https://wa.me/905355741849" target="_blank" className="font-bold underline text-emerald-600">+90 535 574 18 49</a> / telefon ile Sercan’dan alır, sonra yukarıdaki “Bu Sitenin Lisansı” kutusuna girip aktif eder.</div></div>
      ) : (
        <>
      <div className="flex items-center justify-between"><h2 className="text-xl font-black">🔑 Lisans Havuzu — 100 adet (Sadece Sercan)</h2><div className="flex gap-2"><button onClick={copyAll} className="btn-ghost rounded-xl px-3 py-1.5 text-xs font-bold">📋 Tümünü kopyala</button><button onClick={async () => { const r = await fetch("/api/admin/licenses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "generate", count: 10 }) }); const d = await r.json(); if (r.ok) { notify(`${d.keys.length} yeni anahtar üretildi`); load(); } else notify(d.error); }} className="btn-primary rounded-xl px-3 py-1.5 text-xs font-bold">+ 10 üret</button></div></div>
      <div className="soft rounded-2xl p-3 text-xs leading-relaxed"><b>Şeffaf sistem:</b> Her müşteriye bir anahtar ver, kurulumda girer veya sonra buradan aktif eder. Ödemeyen müşteriyi <b>Askıya al</b> → müşterinin sitesinde üstte sarı banner çıkar. Kod gizli değil, <code>/api/license/status</code> herkese açık.<br/><span className="muted">Yöneteceğiniz adres: <code className="font-mono bg-black/5 px-1 rounded">/admin → 🔑 Lisanslar</code> — sadece Sercan (en yüksek yetkili) görür. Diğerleri sadece üstteki “Bu Sitenin Lisansı” kutusunu görür.</span></div>
      <div className="grid gap-1.5 sm:grid-cols-2">
        {list.map((l) => (
          <div key={l.id} className={`flex flex-col gap-1 rounded-xl px-3 py-2 text-xs ${l.status === "suspended" ? "bg-amber-50 border border-amber-300" : l.status === "expired" ? "bg-rose-50 border border-rose-200" : l.isUsed ? "soft border border-emerald-200" : "soft"}`}>
            <div className="flex items-center gap-2"><span className="flex-1 truncate font-mono font-bold tracking-wider">{l.key}</span><span className={`rounded-full px-1.5 py-0.5 text-[10px] font-black ${l.status === "active" && !l.isUsed ? "bg-emerald-500 text-white" : l.status === "active" ? "bg-sky-500 text-white" : l.status === "suspended" ? "bg-amber-500 text-white" : "bg-rose-500 text-white"}`}>{l.isUsed ? l.status : "Boş"}</span></div>
            {l.isUsed && <div className="text-[11px] muted">Kullanım: {l.usedBy} · {l.usedAt ? new Date(l.usedAt).toLocaleDateString("tr-TR") : ""} {l.note && `· ${l.note}`}</div>}
            <div className="flex gap-1"><button onClick={() => { navigator.clipboard.writeText(l.key); notify("Kopyalandı"); }} className="btn-ghost flex-1 rounded-lg px-2 py-0.5 text-xs">Kopyala</button>{l.isUsed && l.status === "active" && <button onClick={() => setStatus(l.key, "suspended")} className="btn-danger flex-1 rounded-lg px-2 py-0.5 text-xs font-bold">Askıya Al</button>}{l.status === "suspended" && <button onClick={() => setStatus(l.key, "active")} className="btn-primary flex-1 rounded-lg px-2 py-0.5 text-xs font-bold">Aktif Et</button>}</div>
          </div>
        ))}
      </div>
      <div className="flex gap-2"><a href="/licenses.txt" download className="btn-ghost rounded-xl px-4 py-2 text-xs font-bold">⬇ licenses.txt indir</a><a href="/api/license/verify" target="_blank" className="btn-ghost rounded-xl px-4 py-2 text-xs font-bold">🔍 Doğrulama API → /api/license/verify</a></div>
        </>
      )}
    </div>
  );
}

function MobileAdmin({ notify }: { notify: (m: string) => void }) {
  const [cfg, setCfg] = useState<Record<string,string>>({});
  const load = () => fetch("/api/admin/stats", { cache: "no-store" }).then((r) => r.json()).then((d) => setCfg(d.settings ?? {}));
  useEffect(() => { load(); }, []);
  const save = async () => {
    const r = await fetch("/api/admin/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(cfg) });
    const d = await r.json().catch(()=>({}));
    if (r.ok) { notify("Mobil ayarları kaydedildi ✓"); document.documentElement.dataset.theme = cfg.defaultTheme || "mor"; }
    else notify(d.error);
  };
  const set = (k: string, v: string) => setCfg((p) => ({ ...p, [k]: v }));
  return (
    <div className="space-y-5">
      <div><h2 className="text-xl font-black flex items-center gap-2">📱 Mobil Uygulama Yönetimi</h2><p className="text-xs muted">Anasayfa ve sohbetteki mobil indirme kartlarını buradan yönet. iOS App Store, Android Play Store linklerini gir, ikonları yükle, açıklama yaz. Şık tasarım ve telefon önizlemesi otomatik güncellenir.</p></div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-3">
          <Field label="📱 Uygulama Adı (PWA)"><input value={cfg.mobileAppName ?? ""} onChange={(e) => set("mobileAppName", e.target.value)} placeholder="SrcnChat" className="input w-full rounded-xl px-3 py-2 text-sm font-bold" /></Field>
          <Field label="Kısa Ad (12 karakter)"><input value={cfg.mobileAppShortName ?? ""} onChange={(e) => set("mobileAppShortName", e.target.value)} maxLength={12} placeholder="SrcnChat" className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Marka Adı"><input value={cfg.mobileAppBrand ?? ""} onChange={(e) => set("mobileAppBrand", e.target.value)} placeholder="SrcnChat" className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Uygulama Açıklaması"><textarea value={cfg.mobileAppDescription ?? ""} onChange={(e) => set("mobileAppDescription", e.target.value)} rows={2} placeholder="Sohbetin yeni adresi..." className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Uygulama İkonu (Chat ikonu - 512x512)"><div className="flex items-center gap-2">{cfg.mobileAppIcon ? <img src={cfg.mobileAppIcon} alt="" className="h-10 w-10 rounded-xl object-cover border shadow" /> : <img src="/icon-512.png" alt="" className="h-10 w-10 rounded-xl object-cover border opacity-60" />}<label className="btn-ghost cursor-pointer rounded-xl px-3 py-2 text-xs font-bold">Yükle / Değiştir<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f=e.target.files?.[0]; if(f) set("mobileAppIcon", await fileToDataUrl(f,512)); }} /></label>{cfg.mobileAppIcon && <button onClick={()=>set("mobileAppIcon","")} className="btn-danger rounded-xl px-2 py-2 text-xs">Varsayılan</button>}</div></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Tema Rengi"><input type="color" value={cfg.mobileAppThemeColor || "#6d3bff"} onChange={(e) => set("mobileAppThemeColor", e.target.value)} className="h-9 w-full rounded-lg" /></Field>
            <Field label="Arka Plan Rengi"><input type="color" value={cfg.mobileAppBackgroundColor || "#0b1020"} onChange={(e) => set("mobileAppBackgroundColor", e.target.value)} className="h-9 w-full rounded-lg" /></Field>
          </div>
        </div>
        <div className="space-y-3">
          <Field label="iOS App Store Linki"><input value={cfg.iosAppStoreUrl ?? ""} onChange={(e) => set("iosAppStoreUrl", e.target.value)} placeholder="https://apps.apple.com/app/..." className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Android Play Store Linki"><input value={cfg.androidPlayStoreUrl ?? ""} onChange={(e) => set("androidPlayStoreUrl", e.target.value)} placeholder="https://play.google.com/store/apps/..." className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="APK Doğrudan Linki"><input value={cfg.androidApkUrl ?? ""} onChange={(e) => set("androidApkUrl", e.target.value)} placeholder="https://.../app.apk" className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <Field label="Kart Açıklaması"><textarea value={cfg.mobileDescription ?? ""} onChange={(e) => set("mobileDescription", e.target.value)} rows={2} placeholder="Uygulama hakkında kısa açıklama..." className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
          <label className="flex items-center gap-2 text-xs font-bold"><input type="checkbox" checked={cfg.mobileEnabled !== "0"} onChange={(e) => set("mobileEnabled", e.target.checked ? "1" : "0")} className="rounded" style={{ accentColor: "var(--brand)" }} /> Mobil kartları göster</label>
          <div className="soft rounded-2xl p-3 text-xs">
            <div className="font-black">📱 Canlı Önizleme</div>
            <div className="mt-2 flex justify-center gap-3">
              <div className="flex flex-col items-center gap-1"><div className="relative w-[90px] h-[180px] rounded-[18px] border-[5px] border-black bg-white overflow-hidden flex flex-col shadow"><div className="h-3 bg-black flex items-center justify-center"><div className="h-1 w-8 rounded-full bg-zinc-700" /></div><div className="flex-1 p-2 flex flex-col gap-1"><div className="h-2 w-12 rounded bg-zinc-100" /><div className="h-14 rounded-xl brand-gradient flex items-center justify-center text-white text-lg">💬</div><div className="h-1.5 w-full rounded bg-zinc-100" /></div></div><span className="text-[10px] font-bold">iPhone</span><span className="text-[9px] muted">{cfg.mobileAppShortName || cfg.mobileAppName || "SrcnChat"}</span></div>
              <div className="flex flex-col items-center gap-1"><div className="relative w-[90px] h-[180px] rounded-[16px] border-[4px] border-zinc-800 bg-white overflow-hidden flex flex-col shadow"><div className="h-4 bg-zinc-900 flex items-center justify-between px-2"><span className="text-[7px] text-white">9:41</span><span className="text-[7px] text-white">●●●</span></div><div className="flex-1 p-2 flex flex-col gap-1"><div className="h-2 w-12 rounded bg-zinc-100" /><div className="h-14 rounded-xl bg-emerald-500 flex items-center justify-center text-white">💬</div><div className="h-1.5 w-full rounded bg-zinc-100" /></div></div><span className="text-[10px] font-bold">Android</span><span className="text-[9px] muted">{cfg.mobileAppShortName || "SrcnChat"}</span></div>
            </div>
            {cfg.mobileAppIcon && <div className="mt-2 flex justify-center"><img src={cfg.mobileAppIcon} alt="" className="h-12 w-12 rounded-xl shadow" /><span className="ml-2 text-xs font-bold self-center">Yeni ikon önizleme</span></div>}
            <div className="mt-2 text-center text-[11px] muted">İsim, ikon ve renk değişince manifest anında güncellenir.</div>
          </div>
        </div>
      </div>

      <div className="soft rounded-2xl p-3 text-xs leading-relaxed">
        <b>📲 Mağazalara yükleme:</b> PWA olarak <a href="https://www.pwabuilder.com" target="_blank" className="underline font-bold" style={{ color: "var(--brand)" }}>PWABuilder.com</a>’a site URL’ini gir → <b>Package for Stores</b> → iOS için Xcode, Android için Android Studio paketi indir → mağazalara yükle.<br/>
        <b>Anadizin programı:</b> Proje kökünde <code>public/sw.js</code> + <code>manifest.webmanifest</code> + ikonlar hazır. Telefonuna yüklemek için anasayfadaki <b>“Sohbet Programı Yüklensin mi?”</b> kartındaki <b>Yükle</b>’ye bas — ana ekrana eklenir, mağaza gerekmez.<br/>
        <b>Otomatik güncelleme:</b> <code>public/sw.js</code> her yayında cache’i yeniler, kullanıcı bir sonraki açılışta yeni sürümü görür.
      </div>

      <button onClick={save} className="btn-primary rounded-2xl px-6 py-3 text-sm font-extrabold">Kaydet — Anında yayınla</button>
    </div>
  );
}

function Account({ notify }: { notify: (m: string) => void }) {
  const [cur, setCur] = useState(""); const [nw, setNw] = useState("");
  return (
    <div className="max-w-sm space-y-3"><h2 className="text-xl font-black">Hesabım</h2>
      <Field label="Mevcut şifre"><input type="password" value={cur} onChange={(e) => setCur(e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
      <Field label="Yeni şifre"><input type="password" value={nw} onChange={(e) => setNw(e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" /></Field>
      <button onClick={async () => { const r = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPassword: cur, newPassword: nw }) }); const d = await r.json(); notify(r.ok ? "Şifre güncellendi ✓" : d.error); if (r.ok) { setCur(""); setNw(""); } }} className="btn-primary rounded-2xl px-6 py-3 text-sm font-extrabold">Şifreyi değiştir</button>
    </div>
  );
}
