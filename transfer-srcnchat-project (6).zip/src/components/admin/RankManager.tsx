"use client";
import { useEffect, useState } from "react";

type Rank = { key: string; label: string; level: number; color: string; icon: string; sprite: number; perms: Record<string, boolean>; isSystem?: boolean };

const PERM_OPTIONS = [
  { key: "mute", label: "Sustur", desc: "Kullanıcıyı susturur" },
  { key: "kick", label: "At", desc: "Odadan atar" },
  { key: "ban", label: "Yasakla", desc: "Siteden yasaklar" },
  { key: "deleteMsg", label: "Mesaj Sil", desc: "Mesaj siler" },
  { key: "clearRoom", label: "Oda Temizle", desc: "Oda geçmişini temizler" },
  { key: "createRoom", label: "Oda Aç", desc: "Yeni oda açar" },
  { key: "adminPanel", label: "Yönetim Paneli", desc: "Admin paneline girer" },
];

export function RankManager() {
  const [ranks, setRanks] = useState<Rank[]>([]);
  const [pack, setPack] = useState<string>("pack1");
  const [editing, setEditing] = useState<Rank | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newRank, setNewRank] = useState<Partial<Rank>>({ key: "", label: "", level: 10, color: "#94a3b8", icon: "●", perms: {} });

  const load = () => fetch("/api/ranks", { cache: "no-store" }).then((r) => r.json()).then((d) => { setRanks(d.ranks ?? []); if (d.pack) setPack(d.pack); }).catch(()=>{});
  useEffect(() => { load(); const t = setInterval(load, 10000); return () => clearInterval(t); }, []);
  const changePack = async (p: string) => {
    const r = await fetch("/api/ranks/pack", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pack: p }) });
    if (r.ok) { setPack(p); document.documentElement.dataset.rankPack = p; load(); }
  };
  const uploadIcon = async (rankKey: string, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("rank", rankKey);
    const r = await fetch("/api/ranks/upload", { method: "POST", body: fd });
    if (r.ok) load();
  };

  const saveEdit = async () => {
    if (!editing) return;
    const r = await fetch(`/api/ranks/${editing.key}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editing) });
    if (r.ok) { setEditing(null); load(); }
  };
  const create = async () => {
    const r = await fetch("/api/ranks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(newRank) });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) alert(d.error ?? "Hata"); else { setShowNew(false); setNewRank({ key: "", label: "", level: 10, color: "#94a3b8", icon: "●", perms: {} }); load(); }
  };
  const del = async (k: string) => {
    if (!confirm(`${k} silinsin mi?`)) return;
    const r = await fetch(`/api/ranks/${k}`, { method: "DELETE" });
    if (r.ok) load(); else alert("Silinemedi - sistem rütbesi olabilir");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black">🏅 Rütbe Kontrol Paneli</h2>
        <button onClick={() => setShowNew(!showNew)} className="btn-primary rounded-xl px-4 py-2 text-sm font-bold">+ Yeni Rütbe</button>
      </div>
      <div className="card rounded-2xl p-4">
        <h3 className="font-black">🎨 Rütbe Resim Paketi — 5 Seçenek</h3>
        <p className="text-xs muted mt-1">Tüm rütbe ikonlarını tek tıkla değiştir — tüm sitede anında güncellenir, künyede HD görünür. Yeni paket site boyutlarıyla uyumlu.</p>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-3">
          {[
            { id: "pack1", name: "Klasik HD", desc: "Orijinal, transparan", img: "/images/ranks.png" },
            { id: "pack2", name: "Neon Cyber", desc: "Parlayan neon", img: "/images/ranks-pack2.png" },
            { id: "pack3", name: "Kraliyet", desc: "Altın, lacivert", img: "/images/ranks-pack3.png" },
            { id: "pack4", name: "Minimal", desc: "Sade, pastel", img: "/images/ranks-pack4.png" },
            { id: "pack5", name: "Espor Gold", desc: "Taç + kalkan HD", img: "/images/ranks-pack5.png" },
          ].map((p) => (
            <button key={p.id} onClick={() => changePack(p.id)} className={`rounded-2xl border-2 p-2 text-left ${pack === p.id ? "border-[var(--brand)] bg-[var(--brand-soft)]" : "border-transparent soft"}`}>
              <img src={p.img} alt={p.name} className="h-10 w-full object-contain rounded-lg bg-white p-1" />
              <div className="text-xs font-black mt-1">{p.name}</div>
              <div className="text-[10px] muted">{p.desc}</div>
              {pack === p.id && <div className="text-[10px] font-bold" style={{ color: "var(--brand)" }}>✓ Aktif</div>}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs muted">Rütbe ikonları transparan ve HD — künyede ve üye listesinde estetik görünür. Değişiklikler anında tüm sitede güncellenir (10sn içinde).</p>

      {showNew && (
        <div className="card rounded-2xl p-4 space-y-3">
          <h3 className="font-black">Yeni Rütbe Ekle</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <label className="label">Anahtar (benzersiz, küçük harf)<input value={newRank.key ?? ""} onChange={(e) => setNewRank({ ...newRank, key: e.target.value.toLowerCase() })} placeholder="ornek: moderator2" className="input rounded-lg px-2 py-1 text-sm" /></label>
            <label className="label">Etiket<input value={newRank.label ?? ""} onChange={(e) => setNewRank({ ...newRank, label: e.target.value })} placeholder="Moderatör 2" className="input rounded-lg px-2 py-1 text-sm" /></label>
            <label className="label">Seviye (0-100)<input type="number" value={newRank.level ?? 10} onChange={(e) => setNewRank({ ...newRank, level: Number(e.target.value) })} className="input rounded-lg px-2 py-1 text-sm" /></label>
            <label className="label">Renk<input type="color" value={newRank.color ?? "#94a3b8"} onChange={(e) => setNewRank({ ...newRank, color: e.target.value })} className="h-8 w-full rounded" /></label>
            <label className="label">İkon<input value={newRank.icon ?? ""} onChange={(e) => setNewRank({ ...newRank, icon: e.target.value })} placeholder="★" className="input rounded-lg px-2 py-1 text-sm" /></label>
            <div className="label">İzinler<div className="grid grid-cols-2 gap-1 mt-1">{PERM_OPTIONS.map((p) => <label key={p.key} className="flex items-center gap-1 text-[11px]"><input type="checkbox" checked={!!newRank.perms?.[p.key]} onChange={(e) => setNewRank({ ...newRank, perms: { ...newRank.perms, [p.key]: e.target.checked } })} />{p.label}</label>)}</div></div>
          </div>
          <div className="flex gap-2"><button onClick={create} className="btn-primary rounded-xl px-4 py-2 text-sm">Oluştur</button><button onClick={() => setShowNew(false)} className="btn-ghost rounded-xl px-4 py-2 text-sm">İptal</button></div>
        </div>
      )}

      <div className="grid gap-3">
        {ranks.map((r) => (
          <div key={r.key} className="card rounded-2xl p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div className="flex items-center gap-3">
              <div className="relative">
                {/* @ts-ignore custom iconUrl */}
                {(r as unknown as { iconUrl?: string }).iconUrl ? <img src={(r as unknown as { iconUrl: string }).iconUrl} alt={r.label} className="h-10 w-10 rounded-xl object-cover border shadow" /> : <span className="rank-sprite" style={{ width: 36, height: 36, backgroundPosition: `${(r.sprite / 6) * 100}% 0`, imageRendering: "auto" as const }} />}
                <span className="absolute -bottom-1 -right-1 text-[10px] bg-white rounded-full px-1 shadow">{r.icon}</span>
              </div>
              <div>
                <div className="font-black flex items-center gap-1" style={{ color: r.color }}>{r.icon} {r.label} <span className="text-xs muted">({r.key})</span></div>
                <div className="text-xs muted">Seviye {r.level} {r.isSystem ? "· sistem" : "· özel"} · künyede HD</div>
              </div>
            </div>
            <div className="flex-1 flex flex-wrap gap-1">
              {Object.entries(r.perms).filter(([,v])=>v).map(([k])=> <span key={k} className="soft px-2 py-0.5 rounded-full text-[10px] font-bold">{k}</span>)}
              {Object.keys(r.perms).length===0 && <span className="text-xs muted">İzin yok</span>}
            </div>
            <div className="flex flex-col gap-1 ml-auto">
              <div className="flex gap-2">
                <button onClick={() => setEditing(r)} className="btn-ghost rounded-lg px-3 py-1 text-xs">Düzenle</button>
                {!r.isSystem && <button onClick={() => del(r.key)} className="btn-danger rounded-lg px-3 py-1 text-xs">Sil</button>}
              </div>
              <label className="btn-ghost rounded-lg px-2 py-1 text-[10px] cursor-pointer text-center">🖼 Resim Yükle<input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadIcon(r.key, f); }} /></label>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setEditing(null)}>
          <div className="card rounded-2xl p-6 w-full max-w-lg" onClick={(e)=>e.stopPropagation()}>
            <h3 className="font-black text-lg">Rütbe Düzenle — {editing.key}</h3>
            <div className="grid sm:grid-cols-2 gap-3 mt-4">
              <label className="label">Etiket<input value={editing.label} onChange={(e)=>setEditing({...editing, label: e.target.value})} className="input rounded-lg px-2 py-1" /></label>
              <label className="label">Seviye<input type="number" value={editing.level} onChange={(e)=>setEditing({...editing, level: Number(e.target.value)})} className="input rounded-lg px-2 py-1" /></label>
              <label className="label">Renk<input type="color" value={editing.color} onChange={(e)=>setEditing({...editing, color: e.target.value})} className="h-8 w-full rounded" /></label>
              <label className="label">İkon<input value={editing.icon} onChange={(e)=>setEditing({...editing, icon: e.target.value})} className="input rounded-lg px-2 py-1" /></label>
            </div>
            <div className="mt-4">
              <div className="label">İzinler</div>
              <div className="grid grid-cols-2 gap-2 mt-1">
                {PERM_OPTIONS.map((p)=> <label key={p.key} className="flex items-start gap-2 soft p-2 rounded-xl text-xs"><input type="checkbox" checked={!!editing.perms?.[p.key]} onChange={(e)=>setEditing({...editing, perms: {...editing.perms, [p.key]: e.target.checked}})} /><div><div className="font-bold">{p.label}</div><div className="muted text-[10px]">{p.desc}</div></div></label>)}
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button onClick={saveEdit} className="btn-primary flex-1 rounded-xl py-2">Kaydet — Anında Güncelle</button>
              <button onClick={()=>setEditing(null)} className="btn-ghost flex-1 rounded-xl py-2">İptal</button>
            </div>
            <p className="text-[11px] muted mt-2 text-center">Kaydedince tüm sitede 10sn içinde güncellenir. Künyede daha estetik görünür.</p>
          </div>
        </div>
      )}
    </div>
  );
}
