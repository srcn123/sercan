"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Avatar } from "../ui";
import { adaptQuality, makePeer, onSignal, sendSignal, type Signal } from "./webrtc";

type Broadcaster = { id: number; username: string; color: string; avatarUrl: string | null; rank: string; viewers: string[] };
const FILTERS = [
  { key: "none", label: "Yok", css: "none", vip: false },
  { key: "warm", label: "Sıcak", css: "sepia(.35) saturate(1.3)", vip: false },
  { key: "cool", label: "Soğuk", css: "hue-rotate(180deg) saturate(1.2)", vip: false },
  { key: "noir", label: "Noir", css: "grayscale(1) contrast(1.2)", vip: true },
  { key: "dream", label: "Rüya", css: "blur(1px) brightness(1.1) saturate(1.4)", vip: true },
  { key: "neon", label: "Neon", css: "contrast(1.4) saturate(2) hue-rotate(290deg)", vip: true },
];

export function useCamera(myId: number, isVip: boolean) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const peers = useRef(new Map<number, RTCPeerConnection>());
  const [filter, setFilter] = useState("none");
  const [quality, setQuality] = useState({ rtt: 0, bitrate: 0 });
  const [faceOk, setFaceOk] = useState<boolean | null>(null);

  const stop = useCallback(async () => {
    stream?.getTracks().forEach((t) => t.stop());
    setStream(null);
    peers.current.forEach((pc, id) => { pc.close(); sendSignal(id, "cam", "bye"); });
    peers.current.clear();
    await fetch("/api/cam/status", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: false }) });
    localStorage.removeItem("srcn_cam_auto");
  }, [stream]);

  const start = useCallback(async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24 } }, audio: true });
      setStream(s);
      await fetch("/api/cam/status", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ on: true }) });
      localStorage.setItem("srcn_cam_auto", "1");
      // liveness heuristic: check that frames change over time (not a frozen image)
      const v = document.createElement("video"); v.srcObject = s; v.muted = true; await v.play().catch(() => {});
      const c = document.createElement("canvas"); c.width = 32; c.height = 32; const ctx = c.getContext("2d")!;
      const samples: number[] = [];
      const iv = setInterval(() => {
        ctx.drawImage(v, 0, 0, 32, 32);
        const d = ctx.getImageData(0, 0, 32, 32).data;
        let sum = 0; for (let i = 0; i < d.length; i += 16) sum += d[i];
        samples.push(sum);
        if (samples.length >= 6) { clearInterval(iv); const varc = Math.max(...samples) - Math.min(...samples); setFaceOk(varc > 20); }
      }, 500);
      return true;
    } catch { return false; }
  }, []);

  // answer offers from viewers
  useEffect(() => {
    if (!stream) return;
    const off = onSignal(async (sig: Signal) => {
      if (sig.channel !== "cam") return;
      if (sig.type === "offer") {
        const pc = makePeer(sig.fromUserId, "cam", () => {}, () => { peers.current.get(sig.fromUserId)?.close(); peers.current.delete(sig.fromUserId); });
        stream.getTracks().forEach((t) => pc.addTrack(t, stream));
        peers.current.set(sig.fromUserId, pc);
        await pc.setRemoteDescription(sig.payload as unknown as RTCSessionDescriptionInit);
        const ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        await sendSignal(sig.fromUserId, "cam", "answer", ans as unknown as Record<string, unknown>);
      } else if (sig.type === "ice") {
        await peers.current.get(sig.fromUserId)?.addIceCandidate(sig.payload as unknown as RTCIceCandidateInit).catch(() => {});
      } else if (sig.type === "bye") {
        peers.current.get(sig.fromUserId)?.close(); peers.current.delete(sig.fromUserId);
      }
    });
    const q = setInterval(async () => {
      const first = peers.current.values().next().value as RTCPeerConnection | undefined;
      if (first) { const r = await adaptQuality(first, myId); setQuality(r); fetch("/api/signals", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ quality: { latency: r.rtt, bitrate: r.bitrate } }) }); }
    }, 5000);
    return () => { off(); clearInterval(q); };
  }, [stream, myId]);

  const filterCss = FILTERS.find((f) => f.key === filter && (!f.vip || isVip))?.css ?? "none";
  return { stream, start, stop, filter, setFilter, filterCss, quality, faceOk, FILTERS };
}

export function CamViewer({ broadcasterId, label, onClose, shield }: { broadcasterId: number; label: string; onClose?: () => void; shield: boolean }) {
  const ref = useRef<HTMLVideoElement | null>(null);
  const [state, setState] = useState<"connecting" | "live" | "ended">("connecting");
  const [revealed, setRevealed] = useState(!shield);
  const [reports, setReports] = useState(0);
  useEffect(() => {
    let pc: RTCPeerConnection | null = null;
    let alive = true;
    const off = onSignal(async (sig) => {
      if (sig.channel !== "cam" || sig.fromUserId !== broadcasterId || !pc) return;
      if (sig.type === "answer") { await pc.setRemoteDescription(sig.payload as unknown as RTCSessionDescriptionInit).catch(() => {}); }
      else if (sig.type === "ice") await pc.addIceCandidate(sig.payload as unknown as RTCIceCandidateInit).catch(() => {});
      else if (sig.type === "bye") setState("ended");
    });
    (async () => {
      pc = makePeer(broadcasterId, "cam", (s) => { if (ref.current) { ref.current.srcObject = s; setState("live"); } }, () => alive && setState("ended"));
      pc.addTransceiver("video", { direction: "recvonly" });
      pc.addTransceiver("audio", { direction: "recvonly" });
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await sendSignal(broadcasterId, "cam", "offer", offer as unknown as Record<string, unknown>);
    })();
    const hb = setInterval(() => fetch("/api/cam/viewers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ broadcasterId }) }), 8000);
    fetch("/api/cam/viewers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ broadcasterId }) });
    return () => { alive = false; off(); clearInterval(hb); pc?.close(); sendSignal(broadcasterId, "cam", "bye"); fetch("/api/cam/viewers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ broadcasterId, leave: true }) }); };
  }, [broadcasterId]);
  return (
    <div className="relative overflow-hidden rounded-2xl bg-black" style={{ aspectRatio: "4/3" }}>
      <video ref={ref} autoPlay playsInline className="h-full w-full object-cover transition" style={{ filter: revealed ? "none" : "blur(28px)" }} />
      {!revealed && state === "live" && <button onClick={() => setRevealed(true)} className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/30 text-white"><span className="text-2xl">🛡</span><span className="text-xs font-extrabold">AI güvenlik kalkanı aktif — görmek için dokun</span></button>}
      {state !== "live" && <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white/80">{state === "connecting" ? "Bağlanıyor…" : "Yayın sona erdi"}</div>}
      <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/50 px-2 py-0.5 text-[11px] font-extrabold text-white"><span className="h-2 w-2 rounded-full bg-rose-500" /> {label}</div>
      <div className="absolute right-2 top-2 flex gap-1">
        <button onClick={() => { setReports((r) => r + 1); if (reports + 1 >= 3) { setRevealed(false); setState("ended"); } }} className="rounded-full bg-black/50 px-2 py-0.5 text-[11px] font-extrabold text-white" title="Uygunsuz içerik bildir">⚑</button>
        {onClose && <button onClick={onClose} className="rounded-full bg-black/50 px-2 py-0.5 text-[11px] font-extrabold text-white">✕</button>}
      </div>
    </div>
  );
}

export function CameraPanel({ cam, myId, onOpenStage }: { cam: ReturnType<typeof useCamera>; myId: number; onOpenStage: () => void }) {
  const [list, setList] = useState<Broadcaster[]>([]);
  const [watching, setWatching] = useState<number[]>([]);
  const myVideo = useRef<HTMLVideoElement | null>(null);
  useEffect(() => { if (myVideo.current && cam.stream) myVideo.current.srcObject = cam.stream; }, [cam.stream]);
  useEffect(() => {
    const load = async () => { const r = await fetch("/api/cam/status", { cache: "no-store" }); if (r.ok) setList((await r.json()).broadcasters); };
    load(); const t = setInterval(load, 5000); return () => clearInterval(t);
  }, []);
  return (
    <div className="space-y-3">
      <div className="card rounded-2xl p-3">
        <div className="flex items-center justify-between"><span className="label mb-0 mt-0">📹 Kameram</span>
          {cam.stream ? <button onClick={cam.stop} className="btn-danger rounded-lg px-2.5 py-1 text-xs font-extrabold">Yayını kapat</button> : <button onClick={cam.start} className="btn-primary rounded-lg px-2.5 py-1 text-xs font-extrabold">Yayına gir</button>}
        </div>
        {cam.stream && (
          <>
            <video ref={myVideo} autoPlay muted playsInline className="mt-2 w-full rounded-xl bg-black" style={{ aspectRatio: "4/3", filter: cam.filterCss, transform: "scaleX(-1)" }} />
            <div className="mt-2 flex flex-wrap gap-1">{cam.FILTERS.map((f) => <button key={f.key} onClick={() => cam.setFilter(f.key)} className={`rounded-lg px-2 py-1 text-[10px] font-extrabold ${cam.filter === f.key ? "brand-gradient text-white" : "soft"}`} title={f.vip ? "VIP filtre" : ""}>{f.vip ? "✦ " : ""}{f.label}</button>)}</div>
            <div className="mt-2 flex items-center justify-between text-[10px] font-bold muted">
              <span>{cam.faceOk === null ? "🔎 Canlılık kontrolü…" : cam.faceOk ? "✅ Canlı yayın doğrulandı" : "⚠️ Hareket algılanmadı (video döngüsü?)"}</span>
              <span>{cam.quality.rtt ? `${Math.round(cam.quality.rtt)} ms` : "— ms"}</span>
            </div>
          </>
        )}
      </div>
      <div className="flex items-center justify-between"><span className="label mb-0 mt-0">Yayındakiler · {list.length}</span>{list.length > 0 && <button onClick={onOpenStage} className="text-[11px] font-extrabold" style={{ color: "var(--brand)" }}>🎬 Video Sahnesi</button>}</div>
      {list.length === 0 && <div className="soft rounded-2xl p-4 text-center text-xs font-bold muted">Şu an kimse yayında değil.</div>}
      {list.map((b) => (
        <div key={b.id} className="card rounded-2xl p-2">
          <div className="flex items-center gap-2">
            <Avatar name={b.username} color={b.color} url={b.avatarUrl} size={28} />
            <div className="min-w-0 flex-1"><div className="truncate text-sm font-extrabold" style={{ color: b.color }}>{b.username}{b.id === myId && " (sen)"}</div><div className="truncate text-[10px] muted" title={b.viewers.join(", ")}>👁 {b.viewers.length} izleyici {b.viewers.length ? `· ${b.viewers.slice(0, 3).join(", ")}` : ""}</div></div>
            {b.id !== myId && (watching.includes(b.id) ? <button onClick={() => setWatching((w) => w.filter((x) => x !== b.id))} className="btn-ghost rounded-lg px-2 py-1 text-[11px] font-extrabold">Kapat</button> : <button onClick={() => setWatching((w) => [...w, b.id])} className="btn-primary rounded-lg px-2 py-1 text-[11px] font-extrabold">İzle</button>)}
          </div>
          {watching.includes(b.id) && <div className="mt-2"><CamViewer broadcasterId={b.id} label={b.username} shield onClose={() => setWatching((w) => w.filter((x) => x !== b.id))} /></div>}
        </div>
      ))}
    </div>
  );
}

export function VideoStage({ onClose }: { onClose: () => void }) {
  const [list, setList] = useState<Broadcaster[]>([]);
  useEffect(() => { const load = async () => { const r = await fetch("/api/cam/status", { cache: "no-store" }); if (r.ok) setList((await r.json()).broadcasters); }; load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, []);
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/95 p-4">
      <div className="flex items-center justify-between text-white"><div className="text-lg font-black">🎬 Video Sahnesi · {list.length} yayın</div><button onClick={onClose} className="rounded-xl bg-white/10 px-3 py-1.5 text-sm font-extrabold">✕ Kapat</button></div>
      <div className="scroll-thin mt-4 grid flex-1 grid-cols-1 gap-3 overflow-y-auto sm:grid-cols-2 lg:grid-cols-3">
        {list.map((b) => <CamViewer key={b.id} broadcasterId={b.id} label={b.username} shield={false} />)}
        {list.length === 0 && <div className="col-span-full flex items-center justify-center text-sm font-bold text-white/60">Yayın yok</div>}
      </div>
    </div>
  );
}
