"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "../Logo";
import { Avatar, RankBadge, dayOf, timeOf, useToast, GiftIcon, LevelRing, fileToDataUrl } from "../ui";
import type { PublicUser } from "@/lib/auth";
import { ACHIEVEMENTS, AVATAR_FRAMES, NICK_EFFECTS, PERM, RADIO_STATIONS, RANKS, RANK_ORDER, REACTION_EMOJIS, THEMES, getLevelStyle, rankLevel, type AchievementKey, levelFromXp, xpForLevel } from "@/lib/constants";
import { ChallengesModal, DjPanel, EmojiPicker, LeaderboardModal, ProfileCard, RadioPlayer, SettingsModal, WheelModal } from "./Panels";
import { GiftQuickModal, PointsHUD } from "./GiftPoints";
import { DmWindow, VideoCall, type DmPeer } from "./DmWindows";
import { CameraPanel, VideoStage, useCamera, CamViewer } from "./Camera";
import { OkeyRoom } from "./Okey";
import { LicenseBanner } from "../LicenseStatus";
import { MobileBottomNav } from "../MobileNav";
import { MobileChatDownload } from "../MobileChatDownload";
import { MicButton, VoiceBar, useVoiceMic } from "./VoiceChat";
import { onSignal } from "./webrtc";

type RoomT = { id: number; name: string; slug: string; description: string; icon: string; imageUrl: string | null; bgUrl: string | null; kind: string; ownerId: number | null; ownerName: string | null; isDefault: boolean; online: number };
type MsgT = { id: number; roomId: number; userId: number | null; username: string; color: string; rank: string; avatarUrl: string | null; textStyle: { color?: string; bold?: boolean; italic?: boolean; neon?: boolean; gradient?: string; animation?: string; nickEffect?: string; avatarFrame?: string }; content: string; kind: string; meta: Record<string, unknown>; whisperTo: number | null; deleted: boolean; createdAt: string; reactions: Record<string, number[]> };
type OnlineUser = { id: number; username: string; color: string; nickColor: string | null; rank: string; isGuest: boolean; isBot: boolean; isDj: boolean; isVerified: boolean; status: string; presence: string; mood: string; avatarUrl: string | null; avatarFrame: string; nickEffect: string; textStyle: { color?: string; bold?: boolean; italic?: boolean; neon?: boolean }; currentRoomId: number | null; cameraOn: boolean; level: number; country: string; mutedUntil: string | null };

import { playSound } from "@/lib/sounds";

function extractYoutubeId(url: string): string | null {
  const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([\w-]{11})/);
  return m?.[1] ?? null;
}

export function ChatApp({ initialUser, site }: { initialUser: PublicUser; site: { siteName: string; logoText: string; logoUrl: string; defaultTheme: string } }) {
  const router = useRouter();
  const { notify, el: toastEl } = useToast();
  const [me, setMe] = useState<PublicUser>(initialUser);
  const [rooms, setRooms] = useState<RoomT[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<number | null>(null);
  const [messages, setMessages] = useState<MsgT[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [online, setOnline] = useState<OnlineUser[]>([]);
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [pendingFriends, setPendingFriends] = useState(0);
  const [announcement, setAnnouncement] = useState("");
  const [radio, setRadio] = useState({ enabled: true, station: "paradise", customUrl: "" });
  const [nowPlaying, setNowPlaying] = useState<{ title: string; artist: string; youtubeId?: string; previewUrl?: string; artwork?: string; djName?: string; duration?: string } | null>(null);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [leftTab, setLeftTab] = useState<"odalar" | "dostlar" | "kamera">("odalar");
  const [friends, setFriends] = useState<{ id: number; status: string; incoming: boolean; user: { id: number; username: string; color: string; rank: string; avatarUrl: string | null; level: number; online: boolean; presence: string } }[]>([]);
  // correct typing
  const [modalState, setModalState] = useState<null | "settings" | "wheel" | "leader" | "challenges" | "dj" | "youtube" | "owner" | "roomEdit" | "gift" | "points">(null);
  const [roomEdit, setRoomEdit] = useState<{ name: string; description: string; icon: string; imageUrl: string; bgUrl: string } | null>(null);
  const [profileId, setProfileId] = useState<number | null>(null);
  const [dmWindows, setDmWindows] = useState<(DmPeer & { min: boolean })[]>([]);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [stage, setStage] = useState(false);
  const [call, setCall] = useState<{ peerId: number; peerName: string; incoming: boolean; offer?: RTCSessionDescriptionInit } | null>(null);
  const [ringing, setRinging] = useState<{ from: number; name: string; offer: RTCSessionDescriptionInit } | null>(null);
  const [atBottom, setAtBottom] = useState(true);
  const [bonus, setBonus] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const [ytPlaying, setYtPlaying] = useState<string | null>(null);
  const [tabUnread, setTabUnread] = useState(0);
  const [camPreviewId, setCamPreviewId] = useState<number | null>(null);
  const [msgError, setMsgError] = useState<string | null>(null);
  const [ytUrl, setYtUrl] = useState("");
  const [ownerSearch, setOwnerSearch] = useState("");
  const [ownerResults, setOwnerResults] = useState<{ id: number; username: string; color: string }[]>([]);
  const [themeOpen, setThemeOpen] = useState(false);
  const [nowTick, setNowTick] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNowTick(Date.now()), 30000); return () => clearInterval(t); }, []);

  const listRef = useRef<HTMLDivElement | null>(null);
  const lastMsgId = useRef(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const typingSent = useRef(0);
  const cam = useCamera(me.id, rankLevel(me.rank) >= 2);

  const activeRoom = rooms.find((r) => r.id === activeRoomId) ?? null;
  const totalUnread = useMemo(() => Object.values(unread).reduce((a, b) => a + b, 0), [unread]);
  const myLevel = rankLevel(me.rank);
  const broadcasters = online.filter((u) => u.cameraOn);
  const { voice, busy: voiceBusy, take: voiceTake, release: voiceRelease, leaveQueue: voiceLeave, live: voiceLive, remoteAudio: voiceAudioRef } = useVoiceMic(activeRoomId, me.id, notify);
  const voiceHolderId = voice.holder?.userId ?? null;

  useEffect(() => { document.documentElement.dataset.theme = me.theme; }, [me.theme]);
  const [showNotifPrompt, setShowNotifPrompt] = useState(false);
  useEffect(() => {
    const b = sessionStorage.getItem("srcn_bonus"); if (b) { setBonus(b); sessionStorage.removeItem("srcn_bonus"); setTimeout(() => setBonus(null), 5000); }
    const mq = window.matchMedia("(max-width: 900px)");
    const apply = () => { setMobile(mq.matches); if (mq.matches) { setLeftOpen(false); setRightOpen(false); } else { setLeftOpen(true); setRightOpen(true); } };
    apply(); mq.addEventListener("change", apply);
    // Bildirimler: sadece ilk girişte 1 defa sor, çerez silinince tekrar
    const asked = typeof window !== "undefined" ? localStorage.getItem("srcn_notif_asked") : "1";
    if (!asked && typeof window !== "undefined" && "Notification" in window && Notification.permission === "default") {
      const t = setTimeout(() => setShowNotifPrompt(true), 1500);
      // cleanup timeout on unmount
      const cleanup = () => clearTimeout(t);
      // store cleanup for return
      (window as unknown as { __notifCleanup?: () => void }).__notifCleanup = cleanup;
    }
    if (localStorage.getItem("srcn_cam_auto") === "1") cam.start();
    const onCallEv = (e: Event) => startCall((e as CustomEvent).detail);
    window.addEventListener("srcn:call", onCallEv);
    return () => { mq.removeEventListener("change", apply); window.removeEventListener("srcn:call", onCallEv); const c = (window as unknown as { __notifCleanup?: () => void }).__notifCleanup; if (c) c(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => { document.title = tabUnread > 0 ? `(${tabUnread}) ${site.siteName || "SrcnChat"}` : site.siteName || "SrcnChat"; }, [tabUnread, site.siteName]);
  useEffect(() => { const onVis = () => { if (document.visibilityState === "visible") setTabUnread(0); }; document.addEventListener("visibilitychange", onVis); return () => document.removeEventListener("visibilitychange", onVis); }, []);
  useEffect(() => onSignal((s) => { if (s.channel === "call" && s.type === "offer" && !call) { const name = online.find((u) => u.id === s.fromUserId)?.username ?? `Kullanıcı #${s.fromUserId}`; setRinging({ from: s.fromUserId, name, offer: s.payload as unknown as RTCSessionDescriptionInit }); playSound("cagri"); } }), [online, call]);

  const refreshMe = useCallback(async () => { const r = await fetch("/api/auth/me", { cache: "no-store" }); if (r.ok) setMe((await r.json()).user); }, []);
  const loadRooms = useCallback(async () => { const r = await fetch("/api/rooms", { cache: "no-store" }); if (!r.ok) return; const d = await r.json(); setRooms(d.rooms); setActiveRoomId((cur) => cur ?? (d.rooms.find((x: RoomT) => x.isDefault)?.id ?? d.rooms[0]?.id ?? null)); }, []);
  const loadFriends = useCallback(async () => { const r = await fetch("/api/friends", { cache: "no-store" }); if (r.ok) setFriends((await r.json()).friends); }, []);
  useEffect(() => { loadRooms(); const t = setInterval(loadRooms, 8000); return () => clearInterval(t); }, [loadRooms]);
  useEffect(() => { if (leftTab === "dostlar") loadFriends(); }, [leftTab, loadFriends]);

  // level reset her ay sonu — tetikle
  useEffect(() => { fetch("/api/levels", { cache: "no-store" }).catch(() => {}); }, []);
  // keep stable refs to avoid re-trigger loops
  const meRef = useRef(me);
  useEffect(() => { meRef.current = me; }, [me]);
  const prevRoomRef = useRef<number | null>(null);

  useEffect(() => {
    let alive = true; let prevUnread = 0;
    const load = async () => {
      const r = await fetch("/api/online", { cache: "no-store" });
      if (r.status === 401) { router.push("/"); return; }
      if (!r.ok || !alive) return;
      const d = await r.json();
      setOnline(d.users); setUnread(d.unread ?? {}); setPendingFriends(d.pendingFriends ?? 0);
      // announcement: 1 kez kapatılan yeni duyuru gelene kadar gizli
      const dismissed = typeof window !== "undefined" ? localStorage.getItem("srcn_announcement_dismissed") : null;
      if (d.announcement && d.announcement !== dismissed) setAnnouncement(d.announcement); else if (!d.announcement) setAnnouncement("");
      setRadio(d.radio); setNowPlaying(d.nowPlaying);
      const tu = Object.values(d.unread as Record<string, number>).reduce((a, b) => a + b, 0);
      if (tu > prevUnread) { playSound("ozel"); const wantNotif = (meRef.current as unknown as { prefNotif?: string }).prefNotif !== "nobody"; if (wantNotif && document.visibilityState !== "visible" && "Notification" in window && Notification.permission === "granted") new Notification("Yeni özel mesaj", { body: `${tu} okunmamış mesajın var` }); }
      prevUnread = tu;
      if (d.me) {
        // only update if something meaningful changed to avoid thrash
        setMe((m) => {
          if (m.points === d.me.points && m.xp === d.me.xp && m.rank === d.me.rank && m.isDj === d.me.isDj && m.mutedUntil === d.me.mutedUntil && m.piggyBank === d.me.piggyBank) return m;
          return { ...m, points: d.me.points, xp: d.me.xp, level: d.me.level, piggyBank: d.me.piggyBank, rank: d.me.rank, isDj: d.me.isDj, mutedUntil: d.me.mutedUntil };
        });
        if (d.me.isBanned) router.push("/");
        if (d.me.kicked) notify("Odadan atıldın. 10 dakika bekle.");
      }
    };
    load(); const t = setInterval(load, 4000);
    return () => { alive = false; clearInterval(t); };
  }, [router, notify]);

  useEffect(() => {
    if (!activeRoomId) return;
    const isNewRoom = prevRoomRef.current !== activeRoomId;
    if (isNewRoom) { prevRoomRef.current = activeRoomId; lastMsgId.current = 0; setMessages([]); setMsgError(null); }
    let alive = true;
    const load = async () => {
      const after = lastMsgId.current;
      try {
        const r = await fetch(`/api/rooms/${activeRoomId}/messages${after ? `?after=${after}` : ""}`, { cache: "no-store" });
        if (!alive) return;
        if (r.status === 403) { const d = await r.json().catch(() => ({})); if (d.error === "kicked") notify("Bu odadan atıldın, 10 dk sonra girebilirsin."); return; }
        if (!r.ok) { setMsgError("Mesajlar yüklenemedi"); return; }
        const d = await r.json();
        setTypingUsers(d.typing ?? []);
        const inc: MsgT[] = d.messages;
        if (d.updates?.length) setMessages((p) => p.map((m) => (d.updates as MsgT[]).find((u) => u.id === m.id) ?? m));
        if (!inc.length) { setMsgError(null); return; }
        lastMsgId.current = inc[inc.length - 1].id;
        setMessages((p) => {
          if (!after) return inc;
          const ids = new Set(p.map((x) => x.id));
          const fresh = inc.filter((x) => !ids.has(x.id));
          if (!fresh.length) return p;
          return [...p, ...fresh].slice(-500);
        });
        setMsgError(null);
        if (after) {
          const cur = meRef.current;
          const others = inc.filter((m) => m.userId !== cur.id);
          if (others.length) {
            if (document.visibilityState !== "visible") setTabUnread((n) => n + others.length);
            if (others.some((m) => (m.meta.mentions as string[] | undefined)?.some((x) => x.toLowerCase() === cur.username.toLowerCase()))) playSound("username"); else if (others.length) playSound("sohbet");
          }
        }
      } catch { setMsgError("Bağlantı hatası"); }
    };
    load(); const t = setInterval(load, 2200);
    return () => { alive = false; clearInterval(t); };
  }, [activeRoomId, notify]);

  // scroll anchor: only auto-scroll if user was at bottom, and keep scroll stable
  useEffect(() => {
    const el = listRef.current;
    if (!el || !atBottom) return;
    // use rAF to avoid layout thrash
    requestAnimationFrame(() => { el.scrollTop = el.scrollHeight; });
  }, [messages, atBottom]);
  function onScroll() { const el = listRef.current; if (el) setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 80); }
  function onType(v: string) { setDraft(v); if (activeRoomId && Date.now() - typingSent.current > 2500) { typingSent.current = Date.now(); fetch("/api/typing", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target: `room:${activeRoomId}` }) }).catch(() => {}); } }

  async function send(e?: React.FormEvent) {
    e?.preventDefault();
    const content = draft.trim();
    if (!content || sending || !activeRoomId) return;
    if (content.startsWith("/tema ")) { const key = content.slice(6).trim(); if (await updateProfile({ theme: key })) { setDraft(""); notify("Tema değişti ✓"); } return; }
    if (content === "/temizle") { setMessages([]); setDraft(""); return; }
    setSending(true); setMsgError(null);
    try {
      const r = await fetch(`/api/rooms/${activeRoomId}/messages`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content }) });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) { notify(d.error ?? `Gönderilemedi (${r.status})`); setMsgError(d.error ?? "Gönderilemedi"); return; }
      setDraft(""); setAtBottom(true); setEmojiOpen(false);
      if (d.local) { setMessages((p) => [...p, { id: -Date.now(), roomId: activeRoomId, userId: null, username: "Sistem", color: "#64748b", rank: "admin", avatarUrl: null, textStyle: {}, content: d.local, kind: "system", meta: {}, whisperTo: null, deleted: false, createdAt: new Date().toISOString(), reactions: {} }]); return; }
      if (d.message) { setMessages((p) => (p.some((m) => m.id === d.message.id) ? p : [...p, d.message])); lastMsgId.current = Math.max(lastMsgId.current, d.message.id); }
      if (d.achievements?.length) d.achievements.forEach((k: AchievementKey) => notify(`🏅 ${ACHIEVEMENTS[k]?.name}`));
      if (d.punished) notify(d.punished === "banned" ? "Yasaklandın." : "Güvenlik botu seni susturdu.");
    } catch (err) { notify("Sunucuya ulaşılamadı"); setMsgError("Sunucu hatası"); console.error(err); } finally { setSending(false); setTimeout(() => inputRef.current?.focus(), 50); }
  }
  async function updateProfile(patch: Record<string, unknown>) {
    const r = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { notify(d.error ?? "Güncellenemedi"); return false; }
    if (d.user) setMe(d.user);
    return true;
  }
  async function logout() { try { if (activeRoomId) await fetch(`/api/rooms/${activeRoomId}/voice`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "release" }) }); } catch {} await cam.stop().catch(() => {}); await fetch("/api/auth/logout", { method: "POST" }); router.push("/"); router.refresh(); }
  function openDm(u: DmPeer) { if (u.id === me.id) return; setDmWindows((w) => (w.some((x) => x.id === u.id) ? w.map((x) => (x.id === u.id ? { ...x, min: false } : x)) : [...w.slice(-2), { ...u, min: false }])); setProfileId(null); }
  function openRoom(id: number) { if (voice.amHolder && activeRoomId && activeRoomId !== id) { fetch(`/api/rooms/${activeRoomId}/voice`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "release" }) }).catch(() => {}); } setActiveRoomId(id); setAtBottom(true); setYtPlaying(null); if (mobile) setLeftOpen(false); }
  async function react(id: number, emoji: string) { await fetch(`/api/messages/${id}/react`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ emoji }) }); setMessages((p) => p.map((m) => { if (m.id !== id) return m; const rx = { ...m.reactions }; const arr = rx[emoji] ?? []; rx[emoji] = arr.includes(me.id) ? arr.filter((x) => x !== me.id) : [...arr, me.id]; return { ...m, reactions: rx }; })); }
  async function del(id: number) { const r = await fetch(`/api/messages/${id}/delete`, { method: "POST" }); if (r.ok) setMessages((p) => p.map((m) => (m.id === id ? { ...m, deleted: true, content: "" } : m))); else notify("Silinemedi"); }
  async function clearRoom() { if (!activeRoomId || !confirm("Oda geçmişi temizlensin mi?")) return; await fetch(`/api/rooms/${activeRoomId}/clear`, { method: "POST" }); setMessages([]); lastMsgId.current = 0; }
  function startCall(peerId: number) { const name = online.find((u) => u.id === peerId)?.username ?? "Kullanıcı"; setCall({ peerId, peerName: name, incoming: false }); setProfileId(null); }
  async function searchOwner(q: string) {
    setOwnerSearch(q);
    if (q.trim().length < 2) { setOwnerResults([]); return; }
    const r = await fetch(`/api/admin/users?q=${encodeURIComponent(q)}&page=1`, { cache: "no-store" });
    if (r.ok) { const d = await r.json(); setOwnerResults(d.users.map((u: { id: number; username: string; color: string }) => ({ id: u.id, username: u.username, color: u.color }))); }
  }
  async function setOwner(userId: number | null) {
    if (!activeRoomId) return;
    // try owner-manage endpoint first (allows owner + Kurucu/Admin), fallback to admin
    let r = await fetch(`/api/rooms/${activeRoomId}/manage`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ownerId: userId }) });
    if (!r.ok) r = await fetch("/api/admin/rooms", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: activeRoomId, ownerId: userId }) });
    const d = await r.json().catch(() => ({}));
    if (r.ok) { notify(userId ? "Oda sahibi güncellendi ✓" : "Oda sahibi kaldırıldı"); setModalState(null); loadRooms(); } else notify(d.error ?? "Yetkin yok");
  }
  async function closeSong() {
    const r = await fetch("/api/dj/play", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "stop" }) });
    if (r.ok) { setNowPlaying(null); notify("Şarkı kapatıldı"); } else notify("Kapatılamadı");
  }

  const roomOnline = online.filter((u) => u.currentRoomId === activeRoomId && !u.isBot);
  const renderContent = (m: MsgT) => {
    const parts = m.content.split(/(@[\wÇĞİÖŞÜçğıöşü.-]{2,18}|https?:\/\/\S+)/g);
    return parts.map((p, i) => {
      if (p.startsWith("@")) { const mine = p.slice(1).toLowerCase() === me.username.toLowerCase(); return <span key={i} className="rounded px-1 font-extrabold" style={{ background: mine ? "var(--brand)" : "var(--brand-soft)", color: mine ? "#fff" : "var(--brand)" }}>{p}</span>; }
      if (p.startsWith("http")) return <a key={i} href={p} target="_blank" rel="noreferrer" className="underline break-all" style={{ color: "var(--brand)" }}>{p.length > 60 ? p.slice(0, 60) + "…" : p}</a>;
      return p;
    });
  };

  const headerBtns: [string, string, string][] = [
    ["🎡", "Şans Çarkı", "wheel"],
    ["🏆", "Liderlik", "leader"],
    ["🏁", "Meydan Oku", "challenges"],
    ["🎧", "DJ İstek", "dj"],
  ];

  return (
    <div className="grid-bg flex h-screen flex-col overflow-hidden">
      {bonus && <div className="pop-in fixed left-1/2 top-16 z-[70] -translate-x-1/2 rounded-3xl px-6 py-4 text-center text-white shadow-2xl brand-gradient"><div className="text-3xl">🎁</div><div className="font-black">Hoş geldin bonusu: +{bonus} puan!</div></div>}
      {stage && <VideoStage onClose={() => setStage(false)} />}
      {call && <VideoCall peerId={call.peerId} peerName={call.peerName} incoming={call.incoming} offer={call.offer} onEnd={() => setCall(null)} />}
      {ringing && !call && <div className="pop-in fixed bottom-6 right-6 z-[56] card flex items-center gap-3 rounded-3xl p-4 shadow-2xl"><span className="text-2xl">📹</span><div><div className="text-sm font-black">{ringing.name} arıyor</div><div className="text-[11px] muted">Görüntülü arama</div></div><button onClick={() => { setCall({ peerId: ringing.from, peerName: ringing.name, incoming: true, offer: ringing.offer }); setRinging(null); }} className="btn-primary rounded-xl px-3 py-2 text-xs font-extrabold">Kabul</button><button onClick={() => setRinging(null)} className="btn-danger rounded-xl px-3 py-2 text-xs font-extrabold">Reddet</button></div>}
      {camPreviewId && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" onClick={() => setCamPreviewId(null)}><div onClick={(e) => e.stopPropagation()} className="w-full max-w-xl"><CamViewer broadcasterId={camPreviewId} label={online.find((u) => u.id === camPreviewId)?.username ?? ""} shield={false} onClose={() => setCamPreviewId(null)} /></div></div>}

      {/* Youtube modal */}
      {modalState === "youtube" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setModalState(null)}>
          <div className="card w-full max-w-lg rounded-3xl p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-lg font-black">▶ YouTube Paylaş</div>
            <p className="text-xs muted">YouTube linkini yapıştır — mesaj olarak gönderilir ve herkes küçük oynatıcıda izleyebilir.</p>
            <input value={ytUrl} onChange={(e) => setYtUrl(e.target.value)} placeholder="https://youtu.be/... veya https://youtube.com/watch?v=..." className="input mt-3 w-full rounded-xl px-3 py-2 text-sm" autoFocus />
            {extractYoutubeId(ytUrl) && <img src={`https://img.youtube.com/vi/${extractYoutubeId(ytUrl)}/mqdefault.jpg`} alt="" className="mt-2 h-24 w-40 rounded-xl object-cover" />}
            <div className="mt-3 flex gap-2 justify-end">
              <button onClick={() => setModalState(null)} className="btn-ghost rounded-xl px-4 py-2 text-sm font-bold">İptal</button>
              <button onClick={() => { const id = extractYoutubeId(ytUrl); if (!id) { notify("Geçerli YouTube linki gir"); return; } setDraft((d) => d + (d ? " " : "") + `https://youtu.be/${id}`); setModalState(null); setYtUrl(""); notify("Link eklendi — Gönder'e bas"); }} className="btn-primary rounded-xl px-4 py-2 text-sm font-extrabold">Ekle</button>
            </div>
          </div>
        </div>
      )}
      {/* Owner modal */}
      {modalState === "owner" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setModalState(null)}>
          <div className="card w-full max-w-md rounded-3xl p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-lg font-black">👑 Oda Sahibi Ata</div>
            <p className="text-xs muted">Kurucu olarak bu odanın sahibini belirleyebilirsin. Sahip, kendi odasında korumaya sahiptir — yalnızca Admin/Kurucu onu atabilir.</p>
            <div className="mt-3 flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>Mevcut: {activeRoom?.ownerName ?? "— yok —"}</div>
            <input value={ownerSearch} onChange={(e) => searchOwner(e.target.value)} placeholder="Kullanıcı adıyla ara (en az 2 harf)" className="input mt-3 w-full rounded-xl px-3 py-2 text-sm" />
            <div className="mt-2 max-h-48 space-y-1 overflow-y-auto">
              {ownerResults.map((u) => <button key={u.id} onClick={() => setOwner(u.id)} className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left hover:bg-[var(--surface-2)]"><span className="h-6 w-6 rounded-full" style={{ background: u.color }} /><span className="text-sm font-extrabold" style={{ color: u.color }}>{u.username}</span><span className="ml-auto text-xs muted">Sahip yap</span></button>)}
            </div>
            <div className="mt-3 flex gap-2">
              <button onClick={() => setOwner(null)} className="btn-ghost flex-1 rounded-xl py-2 text-xs font-extrabold">Sahibi kaldır</button>
              <button onClick={() => setModalState(null)} className="btn-ghost flex-1 rounded-xl py-2 text-xs font-extrabold">Kapat</button>
            </div>
          </div>
        </div>
      )}
      {/* Room Edit — oda sahibi paneli */}
      {modalState === "roomEdit" && roomEdit && activeRoom && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setModalState(null)}>
          <div className="card w-full max-w-lg rounded-3xl p-6" onClick={(e) => e.stopPropagation()}>
            <div className="text-lg font-black">⚙️ Odayı Düzenle — {activeRoom.name}</div>
            <p className="text-xs muted">Oda sahibi olarak bu odanın adını, açıklamasını, ikonunu ve görsellerini düzenleyebilirsin. Değişiklikler anında herkese yansır.</p>
            <div className="mt-3 space-y-3">
              <div><label className="label">Oda adı</label><input value={roomEdit.name} onChange={(e) => setRoomEdit({ ...roomEdit, name: e.target.value })} maxLength={40} className="input w-full rounded-xl px-3 py-2 text-sm" /></div>
              <div><label className="label">Açıklama</label><input value={roomEdit.description} onChange={(e) => setRoomEdit({ ...roomEdit, description: e.target.value })} maxLength={160} className="input w-full rounded-xl px-3 py-2 text-sm" /></div>
              <div className="grid grid-cols-3 gap-2"><label className="label">İkon<select value={roomEdit.icon} onChange={(e) => setRoomEdit({ ...roomEdit, icon: e.target.value })} className="input w-full rounded-xl px-2 py-1 text-sm"><option>💬</option><option>🏠</option><option>🎧</option><option>🎮</option><option>🎲</option><option>🤖</option><option>📻</option><option>🀄</option><option>❤️</option><option>🔥</option></select></label><label className="label col-span-2">Oda resmi URL<input value={roomEdit.imageUrl} onChange={(e) => setRoomEdit({ ...roomEdit, imageUrl: e.target.value })} placeholder="https://...png" className="input w-full rounded-xl px-3 py-2 text-sm" /></label></div>
              <div><label className="label">Arka plan görseli URL<input value={roomEdit.bgUrl} onChange={(e) => setRoomEdit({ ...roomEdit, bgUrl: e.target.value })} placeholder="https://...jpg" className="input w-full rounded-xl px-3 py-2 text-sm" /></label></div>
              <div className="flex gap-2">
                <label className="btn-ghost cursor-pointer rounded-xl px-3 py-2 text-xs font-extrabold">🖼 Resim yükle<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setRoomEdit({ ...roomEdit, imageUrl: await fileToDataUrl(f, 400) }); }} /></label>
                <label className="btn-ghost cursor-pointer rounded-xl px-3 py-2 text-xs font-extrabold">🏞 Arka plan yükle<input type="file" accept="image/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) setRoomEdit({ ...roomEdit, bgUrl: await fileToDataUrl(f, 1200) }); }} /></label>
              </div>
            </div>
            <div className="mt-4 flex gap-2"><button onClick={async () => { const r = await fetch(`/api/rooms/${activeRoom.id}/manage`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(roomEdit) }); const d = await r.json().catch(()=>({})); if (r.ok) { notify("Oda güncellendi ✓"); setModalState(null); loadRooms(); } else notify(d.error ?? "Güncellenemedi"); }} className="btn-primary flex-1 rounded-xl py-2.5 text-sm font-extrabold">Kaydet</button><button onClick={() => setModalState(null)} className="btn-ghost flex-1 rounded-xl py-2.5 text-sm font-extrabold">İptal</button></div>
          </div>
        </div>
      )}
      {/* Theme picker */}
      {themeOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 p-4 pt-16" onClick={() => setThemeOpen(false)}>
          <div className="card w-full max-w-2xl rounded-3xl p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between"><div className="text-lg font-black">🎨 Tema Seç</div><button onClick={() => setThemeOpen(false)} className="rounded-full px-2 py-1 text-sm">✕</button></div>
            <p className="text-xs muted">Gerçekçi 10 tema — anında uygulanır ve hesabına kaydedilir.</p>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-5">
              {THEMES.map((t) => (
                <button key={t.key} onClick={async () => { await updateProfile({ theme: t.key }); setThemeOpen(false); }} className="theme-card flex flex-col gap-1 rounded-2xl border p-2 text-left transition hover:scale-[1.02]" style={{ borderColor: me.theme === t.key ? "var(--brand)" : "var(--border)", background: me.theme === t.key ? "var(--brand-soft)" : "var(--surface-2)" }}>
                  <div className="h-10 w-full rounded-xl" style={{ background: t.bg }} />
                  <div className="text-xs font-extrabold">{t.label}</div>
                  <div className="text-[10px] muted line-clamp-1">{t.desc}</div>
                  {me.theme === t.key && <span className="self-start rounded-full bg-[var(--brand)] px-1.5 py-0.5 text-[9px] font-black text-white">✓ Aktif</span>}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* HEADER — labeled buttons */}
      <header className="card z-20 flex items-center gap-1 border-b px-2 py-2 md:px-3">
        <button className="btn-ghost shrink-0 rounded-xl px-2 py-1.5 text-lg" onClick={() => setLeftOpen((o) => !o)}>☰</button>
        <Logo size="sm" live={false} text={site.logoText || site.siteName} imageUrl={site.logoUrl} />
        <div className="hidden items-center gap-2 text-xs font-bold muted xl:flex"><span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />{online.filter((u) => !u.isBot).length} çevrimiçi • Lv ort {Math.round(online.filter(u=>!u.isBot).reduce((a,b)=>a+(b.level||1),0)/Math.max(1,online.filter(u=>!u.isBot).length))} {broadcasters.length > 0 && <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-black text-white">🔴 {broadcasters.length} yayında</span>}</div>
        <button onClick={async () => { if (cam.stream) await cam.stop(); else { const ok = await cam.start(); if (!ok) notify("Kamera izni gerekiyor"); } }} className={`hidden items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs font-extrabold sm:flex ${cam.stream ? "bg-rose-500 text-white" : "btn-ghost"}`}><span>📹</span><span className="hidden lg:inline">{cam.stream ? "Yayında" : "Kamera Aç"}</span></button>
        {/* labeled top buttons — always with text on desktop */}
        <div className="ml-auto hidden items-center gap-1 lg:flex">
          {headerBtns.map(([icon, label, key]) => (
            <button key={key} onClick={() => setModalState(key as typeof modalState)} className="btn-ghost flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-extrabold" title={label}>
              <span>{icon}</span><span>{label}</span>
            </button>
          ))}
          <button onClick={() => setThemeOpen(true)} className="btn-ghost flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-extrabold"><span>🎨</span><span>Temalar</span></button>
          {myLevel >= PERM.adminPanel && <a href="/admin" className="btn-ghost flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-extrabold"><span>⚙️</span><span>Yönetim</span></a>}
        </div>
        {/* compact icon bar for tablet/mobile */}
        <div className="flex items-center gap-1 lg:hidden">
          {headerBtns.map(([icon, , key]) => <button key={key} onClick={() => setModalState(key as typeof modalState)} className="btn-ghost rounded-xl px-2 py-1.5 text-sm">{icon}</button>)}
          <button onClick={() => setThemeOpen(true)} className="btn-ghost rounded-xl px-2 py-1.5 text-sm">🎨</button>
          {myLevel >= PERM.adminPanel && <a href="/admin" className="btn-ghost rounded-xl px-2 py-1.5 text-sm">⚙️</a>}
        </div>
        <div className="flex items-center gap-1">
          <RadioPlayer radio={radio} nowPlaying={nowPlaying} onStopDj={closeSong} />
          <button onClick={() => setModalState("settings")} className="soft flex items-center gap-1.5 rounded-xl px-2 py-1 text-xs font-extrabold">
            <Avatar name={me.username} color={me.color} url={me.avatarUrl} size={22} presence={me.presence} verified={me.isVerified} frame={me.avatarFrame} />
            <span className="hidden max-w-[90px] truncate md:inline"><span className={me.nickEffect === "neon" ? "nick-neon" : me.nickEffect === "glow-pulse" ? "nick-glow-pulse" : me.nickEffect === "rainbow-anim" ? "nick-rainbow" : me.nickEffect === "fire-text" ? "nick-fire" : me.nickEffect === "ice" ? "nick-ice" : me.nickEffect === "gold-shine" ? "nick-gold" : ""} style={{ color: me.nickColor || me.color }}>{me.username}</span></span>
            {(() => { const ls = getLevelStyle(me.level); return <span className="hidden rounded-full px-1.5 py-0.5 text-[10px] font-black text-white lvl-badge md:inline" style={{ background: ls.bg, boxShadow: ls.glow }}>{ls.label} {me.level}</span>; })()}
          </button>
          <button className="btn-ghost relative rounded-xl px-2 py-1.5 text-sm" onClick={() => setRightOpen((o) => !o)}>👥{totalUnread > 0 && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-black text-white">{totalUnread}</span>}</button>
        </div>
      </header>
      {announcement && !((typeof window !== "undefined" && localStorage.getItem("srcn_announcement_dismissed") === announcement)) && (
        <div className="flex items-center justify-center gap-3 border-b px-4 py-2.5 text-sm font-bold shadow-sm" style={{ background: "linear-gradient(135deg, var(--brand-soft), var(--surface))", color: "var(--brand)", borderColor: "var(--border)" }}>
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full brand-gradient text-white text-xs">📢</span>
          <span className="flex-1 text-center leading-snug">{announcement}</span>
          <button onClick={() => { localStorage.setItem("srcn_announcement_dismissed", announcement); setAnnouncement(""); }} className="shrink-0 rounded-full bg-[var(--surface)] border px-2.5 py-1 text-xs font-black shadow hover:brightness-95" style={{ borderColor: "var(--border)", color: "var(--text)" }} title="Kapat">✕ Kapat</button>
        </div>
      )}
      {/* Now playing bar with close */}
      {nowPlaying && (
        <div className="flex items-center gap-2 border-b px-3 py-2 text-xs" style={{ background: "color-mix(in srgb, var(--brand-soft) 70%, var(--surface))", borderColor: "var(--border)" }}>
          <span className="font-black">🎧 Çalan: {nowPlaying.title} — {nowPlaying.artist} {nowPlaying.djName && `· DJ ${nowPlaying.djName}`}</span>
          {nowPlaying.youtubeId && <a href={`https://youtu.be/${nowPlaying.youtubeId}`} target="_blank" rel="noreferrer" className="rounded-lg bg-red-500 px-2 py-0.5 text-[10px] font-black text-white">▶ YouTube'da aç</a>}
          <button onClick={closeSong} className="btn-danger ml-auto rounded-lg px-2 py-1 text-xs font-extrabold">✕ Kapat</button>
        </div>
      )}
      <LicenseBanner />

      <div className="relative flex min-h-0 flex-1">
        <aside className={`card absolute inset-y-0 left-0 z-20 flex w-[85vw] max-w-72 flex-col border-r p-3 shadow-xl transition-all duration-300 md:static md:shadow-none ${leftOpen ? "translate-x-0 pointer-events-auto md:w-72 md:opacity-100" : "-translate-x-full pointer-events-none md:-translate-x-full md:w-0 md:opacity-0 md:p-0 md:border-0 md:overflow-hidden"}`}>
          <div className="soft mb-2 flex rounded-xl p-0.5 text-[11px] font-extrabold">
            {([["odalar", `💬 Odalar · ${rooms.length}`], ["dostlar", `👥 Dostlar${pendingFriends ? ` (${pendingFriends})` : ""}`], ["kamera", `📹 Kamera${broadcasters.length ? ` · ${broadcasters.length}` : ""}`]] as const).map(([k, l]) => <button key={k} onClick={() => setLeftTab(k as typeof leftTab)} className={`flex-1 rounded-lg py-1.5 ${leftTab === k ? "brand-gradient text-white" : "muted"} ${k === "kamera" && broadcasters.length ? "ring-2 ring-rose-400" : ""}`}>{l}</button>)}
          </div>
          <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
            {leftTab === "odalar" && <div className="space-y-1">
              {rooms.map((r) => { const active = r.id === activeRoomId; return (
                <button key={r.id} onClick={() => openRoom(r.id)} className={`flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left ${active ? "brand-gradient text-white shadow-md" : "hover:bg-[var(--surface-2)]"}`}>
                  {r.imageUrl ? <img src={r.imageUrl} alt="" className="h-9 w-9 rounded-xl object-cover" /> : <span className="flex h-9 w-9 items-center justify-center rounded-xl text-lg" style={{ background: active ? "rgba(255,255,255,.2)" : "var(--surface-2)" }}>{r.icon}</span>}
                  <span className="min-w-0 flex-1"><span className="block truncate text-sm font-extrabold">{r.name}{r.ownerName ? <span className="ml-1 text-[9px] opacity-70">👑 {r.ownerName}</span> : ""}</span><span className={`block truncate text-[11px] ${active ? "text-white/80" : "muted"}`}>{r.description || "—"}</span></span>
                  <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-black ${active ? "bg-white/20" : ""}`} style={active ? undefined : { background: "var(--brand-soft)", color: "var(--brand)" }}>{r.online}</span>
                </button>); })}
              {me.rank === "kurucu" && <div className="mt-2 rounded-xl border border-dashed p-2 text-center" style={{ borderColor: "var(--border)" }}><div className="text-[11px] font-bold muted">Oda sahibi atamak için odaya gir → üstteki 👑</div></div>}
            </div>}
            {leftTab === "dostlar" && <div className="space-y-1">
              {friends.filter((f) => f.status === "pending").map((f) => <div key={f.id} className="soft rounded-xl p-2 text-xs"><div className="flex items-center gap-2"><Avatar name={f.user.username} color={f.user.color} url={f.user.avatarUrl} size={24} /><span className="flex-1 truncate font-extrabold">{f.user.username}</span></div><div className="mt-1 flex gap-1">{f.incoming ? <><button onClick={async () => { await fetch("/api/friends", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "accept", id: f.id }) }); loadFriends(); }} className="btn-primary flex-1 rounded-lg py-1 font-extrabold">Kabul</button><button onClick={async () => { await fetch("/api/friends", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "reject", id: f.id }) }); loadFriends();}} className="btn-danger flex-1 rounded-lg py-1 font-extrabold">Reddet</button></> : <span className="muted">İstek gönderildi…</span>}</div></div>)}
              {friends.filter((f) => f.status === "accepted").sort((a, b) => Number(b.user.online) - Number(a.user.online)).map((f) => <button key={f.id} onClick={() => setProfileId(f.user.id)} className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left hover:bg-[var(--surface-2)]"><Avatar name={f.user.username} color={f.user.color} url={f.user.avatarUrl} size={28} presence={f.user.online ? f.user.presence : undefined} /><span className="min-w-0 flex-1"><span className="block truncate text-sm font-extrabold" style={{ color: f.user.color }}>{f.user.username}</span><span className="block text-[10px] muted">{f.user.online ? "çevrimiçi" : "çevrimdışı"} · Lv {f.user.level}</span></span><span onClick={(e) => { e.stopPropagation(); openDm(f.user); }} className="rounded-lg px-1.5 text-xs">✉️</span></button>)}
              {friends.length === 0 && <div className="py-6 text-center text-xs muted">Henüz arkadaşın yok.</div>}
            </div>}
            {leftTab === "kamera" && <CameraPanel cam={cam} myId={me.id} onOpenStage={() => setStage(true)} />}
          </div>
          {/* Alt sol — Radyo & DJ belirgin */}
          <div className="mt-2 border-t pt-2 space-y-2" style={{ borderColor: "var(--border)" }}>
            <LeftRadioDJ radio={radio} nowPlaying={nowPlaying} onStopDj={closeSong} />
            <MobileChatDownload />
          </div>
        </aside>

        <main className="flex min-w-0 flex-1 flex-col" style={activeRoom?.bgUrl ? { background: `url(${activeRoom.bgUrl}) center/cover` } : undefined}>
          {broadcasters.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto border-b px-2 py-2" style={{ background: "color-mix(in srgb, var(--brand-soft) 60%, var(--surface))", borderColor: "var(--border)" }}>
              <span className="shrink-0 rounded-full bg-rose-500 px-2 py-1 text-[10px] font-black text-white">🔴 CANLI · {broadcasters.length}</span>
              {broadcasters.map((b) => (
                <button key={b.id} onClick={() => setCamPreviewId(b.id)} className="flex shrink-0 items-center gap-1.5 rounded-full border bg-[var(--surface)] px-2 py-1 text-xs font-extrabold shadow-sm" style={{ borderColor: "var(--border)" }}>
                  <Avatar name={b.username} color={b.color} url={b.avatarUrl} size={22} />
                  <span style={{ color: b.color }}>{b.username}</span>
                  <span className="rounded-full bg-rose-500 px-1 text-[9px] font-black text-white">İZLE</span>
                </button>
              ))}
              <button onClick={() => setStage(true)} className="shrink-0 rounded-full px-2 py-1 text-xs font-extrabold" style={{ background: "var(--surface-2)", color: "var(--brand)" }}>🎬 Sahne</button>
            </div>
          )}
          {cam.stream && <OwnPip cam={cam} />}
          <div className="card flex items-center gap-2 border-b px-3 py-2">
            {activeRoom?.imageUrl ? <img src={activeRoom.imageUrl} alt="" className="h-8 w-8 rounded-xl object-cover" /> : <span className="text-xl">{activeRoom?.icon ?? "💬"}</span>}
            <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2 text-sm font-extrabold">{activeRoom?.name ?? "Yükleniyor..."}{activeRoom?.ownerName && <span className="rounded-full px-1.5 py-0.5 text-[10px]" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>👑 {activeRoom.ownerName}</span>}</div><div className="truncate text-[11px] muted">{activeRoom?.description} · {roomOnline.length} kişi · {broadcasters.filter((b) => b.currentRoomId === activeRoomId).length > 0 && `📹 ${broadcasters.filter((b) => b.currentRoomId === activeRoomId).length} yayında · `}{activeRoom?.kind === "music" && "DJ modu"}</div></div>
            {(activeRoom && (activeRoom.ownerId === me.id || myLevel >= PERM.createRoom)) && <button onClick={() => setModalState("owner")} className="btn-ghost rounded-lg px-2 py-1 text-xs font-extrabold" title="Oda sahibini değiştir">👑</button>}
            {activeRoom && (activeRoom.ownerId === me.id || myLevel >= PERM.clearRoom) && <button onClick={() => { setRoomEdit({ name: activeRoom.name, description: activeRoom.description, icon: activeRoom.icon, imageUrl: activeRoom.imageUrl ?? "", bgUrl: activeRoom.bgUrl ?? "" }); setModalState("roomEdit"); }} className="btn-ghost rounded-lg px-2 py-1 text-xs font-extrabold" title="Odayı düzenle (sahip paneli)">⚙️</button>}
            {activeRoom?.kind === "music" && <button onClick={() => setModalState("dj")} className="btn-ghost rounded-lg px-2 py-1 text-xs font-extrabold">🎧 İstek</button>}
            {myLevel >= PERM.clearRoom && activeRoom?.kind !== "okey" && <button onClick={clearRoom} className="btn-ghost rounded-lg px-2 py-1 text-xs font-extrabold">🧹</button>}
          </div>
          <VoiceBar holderName={voice.holder?.username ?? null} isMe={voice.amHolder} queue={voice.queue} myPosition={voice.myPosition} live={voiceLive} />
          <audio ref={voiceAudioRef} autoPlay playsInline className="hidden" />

          {activeRoom?.kind === "okey" ? (
            <div className="scroll-thin min-h-0 flex-1 overflow-y-auto"><OkeyRoom me={me} notify={notify} /></div>
          ) : (
            <>
              <div ref={listRef} onScroll={onScroll} className="scroll-thin chat-stream min-h-0 flex-1 overflow-y-auto px-3 py-3 md:px-6 lg:px-8">
                {msgError && <div className="mb-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700">{msgError} · <button onClick={() => { setMsgError(null); setMessages([]); lastMsgId.current = 0; }} className="underline">yenile</button></div>}
                {messages.length === 0 && !msgError && <div className="flex h-full flex-col items-center justify-center gap-3 text-center"><div className="brand-gradient flex h-16 w-16 items-center justify-center rounded-3xl text-3xl text-white shadow-lg">{activeRoom?.icon ?? "💬"}</div><p className="max-w-md text-sm font-bold muted">{activeRoom?.kind === "ai" ? "Nova'ya bir şey sor!" : activeRoom?.kind === "music" ? "Bir şarkı adı yaz, DJ botu çalsın — veya YouTube butonuyla paylaş." : "Bu odada henüz mesaj yok. Sohbeti sen başlat!"}</p></div>}
                <div className="w-full">
                  {messages.filter((m) => !(m.kind === "gift" && nowTick - new Date(m.createdAt).getTime() > 5 * 60 * 1000)).map((m, i, arr) => {
                    const prev = arr[i - 1];
                    const newDay = !prev || dayOf(prev.createdAt) !== dayOf(m.createdAt);
                    const grouped = !newDay && prev && prev.username === m.username && prev.kind === m.kind && m.kind === "text" && new Date(m.createdAt).getTime() - new Date(prev.createdAt).getTime() < 120000;
                    const mine = m.userId === me.id;
                    const ou = online.find((u) => u.id === m.userId);
                    const ts = m.textStyle ?? {};
                    const canDel = mine || myLevel >= PERM.deleteMsg;
                    const isNowPlaying = m.kind === "nowplaying";
                    return (
                      <div key={m.id}>
                        {newDay && <div className="my-3 flex items-center gap-3 text-[10px] font-extrabold uppercase tracking-widest muted"><span className="h-px flex-1" style={{ background: "var(--border)" }} />{dayOf(m.createdAt)}<span className="h-px flex-1" style={{ background: "var(--border)" }} /></div>}
                        {m.deleted ? <div className="px-12 py-0.5 text-[11px] italic muted">🗑 mesaj silindi</div>
                        : m.kind === "system" ? <div className="fade-in my-1 text-center text-[11px] font-bold muted">{m.content}</div>
                        : m.kind === "action" ? <div className="fade-in py-0.5 text-center text-xs italic muted"><button onClick={() => m.userId && setProfileId(m.userId)} className="font-extrabold not-italic" style={{ color: m.color }}>* {m.username}</button> {m.content}</div>
                        : isNowPlaying ? (
                          <div className="fade-in my-3 flex justify-center">
                            <div className="flex w-full max-w-none items-center gap-3 rounded-2xl border px-4 py-3 shadow-md" style={{ background: "var(--surface)", borderColor: "var(--brand)", borderLeftWidth: 4 }}>
                              <div className={`flex h-12 w-12 items-center justify-center rounded-xl text-xl ${nowPlaying?.youtubeId ? "bg-red-500" : "brand-gradient"} text-white`}>{nowPlaying?.youtubeId ? "▶" : "🎧"}</div>
                              <div className="min-w-0 flex-1">
                                <div className="truncate text-sm font-black">{String(m.meta.title ?? nowPlaying?.title ?? "")} — {String(m.meta.artist ?? nowPlaying?.artist ?? "")}</div>
                                <div className="text-[11px] muted">DJ {String(m.meta.djName ?? nowPlaying?.djName ?? m.username)} çalıyor</div>
                                {typeof m.meta.previewUrl === "string" && !nowPlaying?.youtubeId && <audio controls src={m.meta.previewUrl} className="mt-1 h-7 w-full" />}
                                {typeof m.meta.youtubeId === "string" && <button onClick={() => setYtPlaying(String(m.meta.youtubeId))} className="btn-primary mt-1 rounded-lg px-2 py-1 text-[11px] font-extrabold">▶ Oynat</button>}
                              </div>
                              {(myLevel >= PERM.ban || m.userId === me.id || nowPlaying?.djName === me.username) && <button onClick={closeSong} className="btn-danger rounded-xl px-2 py-1 text-xs font-extrabold">✕ Kapat</button>}
                            </div>
                          </div>
                        )
                        : m.kind === "gift" ? (() => { const age = nowTick - new Date(m.createdAt).getTime(); const left = Math.max(0, 5*60*1000 - age); const mm = Math.floor(left/60000), ss = String(Math.floor((left%60000)/1000)).padStart(2,"0"); return <div className="fade-in my-2 flex justify-center"><div className="gift-burst card flex items-center gap-3 rounded-2xl px-4 py-2 shadow-lg" style={{ borderColor: "var(--brand)" }}><GiftIcon giftKey={String(m.meta.gift)} size={44} /><div className="text-sm"><b style={{ color: m.color }}>{m.username}</b> → <b>{String(m.meta.to)}</b><div className="text-[11px] muted">{m.content.replace(/^.*?gönderdi!?/, "").trim() || "hediye gönderdi"}</div><div className="text-[10px] font-bold" style={{ color: left < 60000 ? "#ef4444" : "var(--muted)" }}>⏱ {mm}:{ss} sonra kaybolacak</div></div></div></div>; })()
                        : (
                          <div className={`group fade-in relative flex w-full gap-2.5 rounded-xl px-2 py-1 hover:bg-[var(--surface-2)] ${grouped ? "mt-0.5" : "mt-2.5"}`} style={m.kind === "whisper" ? { background: "color-mix(in srgb, var(--brand) 8%, transparent)" } : undefined}>
                            <div className="w-9 shrink-0 pt-0.5">{!grouped && <button onClick={() => m.userId && setProfileId(m.userId)} className="transition hover:scale-105"><Avatar name={m.username} color={m.color} url={m.avatarUrl} size={36} presence={ou?.presence} verified={ou?.isVerified} frame={(m.meta as Record<string,string>)?.avatarFrame || (m.textStyle as Record<string,string>)?.avatarFrame || (ou as unknown as { avatarFrame?: string })?.avatarFrame} /></button>}</div>
                            <div className="min-w-0 flex-1">
                              {!grouped && <div className="flex flex-wrap items-center gap-1.5"><button onClick={() => m.userId && setProfileId(m.userId)} className="text-sm font-extrabold" style={{ color: m.color }}><span className={(m.meta as Record<string,string>)?.nickEffect === "neon" || (m.textStyle as Record<string,string>)?.nickEffect === "neon" ? "nick-neon" : (m.meta as Record<string,string>)?.nickEffect === "glow-pulse" ? "nick-glow-pulse" : (m.meta as Record<string,string>)?.nickEffect === "rainbow-anim" ? "nick-rainbow" : (m.meta as Record<string,string>)?.nickEffect === "fire-text" ? "nick-fire" : (m.meta as Record<string,string>)?.nickEffect === "ice" ? "nick-ice" : (m.meta as Record<string,string>)?.nickEffect === "gold-shine" ? "nick-gold" : ""}>{m.username}</span>{(ou as unknown as { gender?: string })?.gender === "kadin" ? <span title="Kadın" className="text-[11px]" style={{ color: "#ec4899" }}>♀</span> : (ou as unknown as { gender?: string })?.gender === "erkek" ? <span title="Erkek" className="text-[11px]" style={{ color: "#3b82f6" }}>♂</span> : null}{mine && <span className="ml-1 text-[10px] font-bold muted">(sen)</span>}</button>{voiceHolderId === m.userId && m.userId !== null && <span title="Canlı ses" className="inline-flex items-center gap-0.5 rounded-full bg-emerald-500 px-1.5 py-0.5 text-[9px] font-black text-white animate-pulse">🎙️ SES</span>}<RankBadge rank={m.rank} compact />{ou?.isDj && <span className="text-[10px]">🎧</span>}{ou?.cameraOn && <button onClick={() => ou && setCamPreviewId(ou.id)} className="rounded-full bg-rose-500 px-1.5 text-[9px] font-black text-white">📹</button>}{m.kind === "whisper" && <span className="text-[10px] font-extrabold" style={{ color: "var(--brand)" }}>🤫 fısıltı {m.whisperTo === me.id ? "sana" : `→ ${String(m.meta.to)}`}</span>}<span className="text-[11px] muted">{timeOf(m.createdAt)}</span></div>}
                              <div className="whitespace-pre-wrap break-words text-[15px] leading-relaxed" style={{ color: ts.color, fontWeight: ts.bold ? 800 : undefined, fontStyle: ts.italic ? "italic" : undefined }}>{renderContent(m)}</div>
                              {typeof m.meta.image === "string" && <a href={m.meta.image} target="_blank" rel="noreferrer"><img src={m.meta.image} alt="" className="mt-2 max-h-72 w-auto max-w-full rounded-xl border" style={{ borderColor: "var(--border)" }} /></a>}
                              {typeof m.meta.youtube === "string" && (ytPlaying === m.meta.youtube ? <iframe className="mt-2 aspect-video w-full rounded-xl" src={`https://www.youtube.com/embed/${m.meta.youtube}?autoplay=1`} allow="autoplay; encrypted-media" allowFullScreen /> : <button onClick={() => setYtPlaying(String(m.meta.youtube))} className="card mt-2 flex w-full items-center gap-3 rounded-xl p-2 text-left hover:brightness-95"><img src={`https://img.youtube.com/vi/${m.meta.youtube}/mqdefault.jpg`} alt="" className="h-20 w-36 rounded-lg object-cover" /><div className="min-w-0 flex-1"><div className="truncate text-sm font-extrabold">▶ {String(m.meta.title ?? "YouTube videosu")}</div><div className="text-[11px] muted">Tam sürüm — oynatmak için tıkla</div></div></button>)}
                              {Object.entries(m.reactions ?? {}).filter(([, v]) => v.length).length > 0 && <div className="mt-1 flex flex-wrap gap-1">{Object.entries(m.reactions).filter(([, v]) => v.length).map(([e, v]) => <button key={e} onClick={() => react(m.id, e)} className="rounded-full border px-1.5 py-0.5 text-[11px] font-bold" style={{ borderColor: v.includes(me.id) ? "var(--brand)" : "var(--border)", background: v.includes(me.id) ? "var(--brand-soft)" : "var(--surface)" }}>{e} {v.length}</button>)}</div>}
                            </div>
                            <div className="card absolute -top-3 right-2 hidden items-center gap-0.5 rounded-xl p-0.5 shadow group-hover:flex">{REACTION_EMOJIS.map((e) => <button key={e} onClick={() => react(m.id, e)} className="rounded-lg px-1 text-sm hover:bg-[var(--surface-2)]">{e}</button>)}<button onClick={() => setDraft((d) => `${d}@${m.username} `)} className="rounded-lg px-1 text-xs" title="Bahset">@</button>{canDel && <button onClick={() => del(m.id)} className="rounded-lg px-1 text-xs" title="Sil">🗑</button>}</div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              {typingUsers.length > 0 && <div className="px-6 text-[11px] font-bold muted">✍️ {typingUsers.slice(0, 3).join(", ")} yazıyor…</div>}
              {!atBottom && <div className="pointer-events-none relative"><button onClick={() => { setAtBottom(true); const el = listRef.current; if (el) el.scrollTop = el.scrollHeight; }} className="btn-primary pointer-events-auto absolute -top-10 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-xs font-extrabold">↓ Yeni mesajlar</button></div>}
              {(() => { const isMuted = !!me.mutedUntil && new Date(me.mutedUntil).getTime() > Date.now(); const mins = isMuted ? Math.ceil((new Date(me.mutedUntil!).getTime() - Date.now())/60000) : 0; return isMuted ? (
                <div className="card border-t p-4 text-center" style={{ borderColor: "var(--border)", background: "color-mix(in srgb, #fef2f2 80%, var(--surface))" }}>
                  <div className="mx-auto max-w-sm">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-rose-100 text-xl">🔇</div>
                    <div className="mt-2 text-sm font-black text-rose-600">Susturuldun — mesaj yazamazsın</div>
                    <div className="text-xs muted">Kalan süre: <b className="text-rose-600">{mins} dakika</b> — süre dolunca otomatik açılır, hiçbir yerde yazma alanı görünmez.</div>
                    <div className="mt-2 text-[11px] muted">Açıldıktan sonra sohbetine kaldığın yerden devam edebilirsin.</div>
                  </div>
                </div>
              ) : (
                <form onSubmit={send} className="card relative border-t p-2 pb-[max(12px,env(safe-area-inset-bottom))] mb-14 md:mb-0 md:p-2.5">
                  {emojiOpen && <EmojiPicker onPick={(e) => setDraft((d) => d + e)} onClose={() => setEmojiOpen(false)} />}
                  <div className="flex w-full items-center gap-1 md:gap-1.5">
                    <button type="button" onClick={() => setEmojiOpen((o) => !o)} className="btn-ghost shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg" title="Emoji">😊</button>
                    <button type="button" onClick={() => setModalState("youtube")} className="btn-ghost shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg hidden sm:flex" title="YouTube paylaş">▶️</button>
                    <button type="button" onClick={() => setModalState("gift")} className="shrink-0 rounded-xl px-2.5 py-2 text-base font-black text-white shadow md:px-2.5 md:py-2.5 md:text-lg" style={{ background: "linear-gradient(135deg,#ec4899,#a855f7)" }} title="Hediye gönder">🎁</button>
                    <MicButton amHolder={voice.amHolder} holderName={voice.holder?.username ?? null} myPosition={voice.myPosition} busy={voiceBusy} live={voiceLive} onToggle={() => (voice.amHolder ? voiceRelease() : voiceTake())} onLeave={() => voiceLeave()} />
                    <button type="button" onClick={async () => { if (!cam.stream) { const ok = await cam.start(); if (!ok) notify("Kamera izni ver"); return; } try { const track = cam.stream!.getVideoTracks()[0]; if (!track) throw new Error(); let blob: Blob | null = null; try { const Ic = (window as unknown as { ImageCapture: new(t: MediaStreamTrack) => { takePhoto: () => Promise<Blob> } }).ImageCapture; blob = await new Ic(track).takePhoto(); } catch { const c = document.createElement("canvas"); const v = document.createElement("video"); v.srcObject = cam.stream!; await v.play().catch(() => {}); await new Promise((r) => setTimeout(r, 200)); c.width = v.videoWidth || 640; c.height = v.videoHeight || 480; c.getContext("2d")!.drawImage(v, 0, 0); blob = await new Promise<Blob>((res) => c.toBlob((b) => res(b!), "image/jpeg", 0.8)); } if (!blob) throw new Error(); const f = new File([blob], "kamera.jpg", { type: "image/jpeg" }); const url = await fileToDataUrl(f, 640); setDraft((d) => d + (d ? " " : "") + url); notify("📷 Kamera fotoğrafı eklendi — Gönder'e bas"); } catch { notify("Fotoğraf alınamadı"); } }} className="btn-ghost shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg hidden sm:flex" title="Kameradan fotoğraf">📷</button>
                    <input ref={inputRef} value={draft} onChange={(e) => onType(e.target.value)} maxLength={1000} placeholder={`#${activeRoom?.name ?? "oda"} odasına yaz…`} className="input min-w-0 flex-1 rounded-2xl px-3 py-2.5 text-sm font-semibold" />
                    <button type="submit" disabled={sending || !draft.trim()} className="btn-primary shrink-0 rounded-2xl px-4 py-2.5 text-sm font-extrabold whitespace-nowrap md:px-5 disabled:opacity-40 flex items-center justify-center min-w-[56px]"><span className="sm:hidden">➤</span><span className="hidden sm:inline">{sending ? "…" : "Gönder"}</span></button>
                  </div>
                </form>
              ); })()}
            </>
          )}
        </main>

        <aside className={`card absolute inset-y-0 right-0 z-20 flex w-[85vw] max-w-72 flex-col border-l p-3 shadow-xl transition-all duration-300 md:static md:shadow-none ${rightOpen ? "translate-x-0 pointer-events-auto md:w-72 md:opacity-100" : "translate-x-full pointer-events-none md:translate-x-full md:w-0 md:opacity-0 md:p-0 md:border-0 md:overflow-hidden"}`}>
          <div className="mb-2 flex items-center justify-between px-1 text-[11px] font-extrabold uppercase tracking-widest muted"><span>Çevrimiçi · {online.filter((u) => !u.isBot).length}</span><span className="flex items-center gap-1">🤖 {online.filter((u) => u.isBot).length} · <LevelRing xp={me.xp} size={20} /></span></div>
          {broadcasters.length > 0 && (
            <div className="mb-2 rounded-2xl p-2" style={{ background: "color-mix(in srgb, #ef4444 12%, var(--surface))", border: "1px solid color-mix(in srgb, #ef4444 20%, var(--border))" }}>
              <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-widest" style={{ color: "#ef4444" }}><span>🔴 Yayında · {broadcasters.length}</span><button onClick={() => setStage(true)} className="rounded-lg bg-rose-500 px-1.5 py-0.5 text-[10px] text-white">Sahne</button></div>
              <div className="mt-1.5 flex gap-1 overflow-x-auto">{broadcasters.map((b) => <button key={b.id} onClick={() => setCamPreviewId(b.id)} className="flex shrink-0 flex-col items-center gap-1 rounded-xl px-2 py-1 hover:bg-white/50"><Avatar name={b.username} color={b.color} url={b.avatarUrl} size={36} /><span className="max-w-[60px] truncate text-[10px] font-extrabold" style={{ color: b.color }}>{b.username}</span></button>)}</div>
            </div>
          )}
          <div className="scroll-thin min-h-0 flex-1 space-y-0.5 overflow-y-auto">
            {RANK_ORDER.map((rk) => {
              const group = online.filter((u) => u.rank === rk);
              if (!group.length) return null;
              const info = RANKS[rk];
              return (
                <div key={rk} className="mb-1.5">
                  <div className="flex items-center gap-1.5 px-1 py-1 text-[10px] font-extrabold uppercase tracking-widest" style={{ color: info.color }}><span className="rank-sprite" style={{ width: 14, height: 14, backgroundPosition: `${(info.sprite / 6) * 100}% 0` }} /> {info.label} · {group.length}</div>
                  {group.map((u) => { const room = rooms.find((r) => r.id === u.currentRoomId); const n = unread[u.id] ?? 0; const eff = (u as unknown as { nickEffect?: string }).nickEffect; const effCls = eff === "neon" ? "nick-neon" : eff === "glow-pulse" ? "nick-glow-pulse" : eff === "rainbow-anim" ? "nick-rainbow" : eff === "fire-text" ? "nick-fire" : eff === "ice" ? "nick-ice" : eff === "gold-shine" ? "nick-gold" : eff === "shadow" ? "nick-shadow" : ""; return (
                    <button key={u.id} onClick={() => setProfileId(u.id)} className="flex w-full items-center gap-2 rounded-xl px-2 py-1 text-left hover:bg-[var(--surface-2)]">
                      <div className="relative"><Avatar name={u.username} color={u.color} url={u.avatarUrl} size={30} presence={u.presence} verified={u.isVerified} frame={(u as unknown as { avatarFrame?: string }).avatarFrame} />{u.cameraOn && <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] text-white">📹</span>}</div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1 truncate text-sm font-extrabold" style={{ color: u.nickColor || u.color }}><span className={effCls}>{u.username}</span>{voiceHolderId === u.id && <span title="Canlı ses" className="inline-flex items-center rounded-full bg-emerald-500 px-1 py-px text-[9px] font-black text-white animate-pulse">🎙️</span>}{(u as unknown as { gender?: string }).gender === "kadin" ? <span title="Kadın" className="text-[11px]" style={{ color: "#ec4899" }}>♀</span> : (u as unknown as { gender?: string }).gender === "erkek" ? <span title="Erkek" className="text-[11px]" style={{ color: "#3b82f6" }}>♂</span> : null}{u.id === me.id && <span className="text-[10px] muted">(sen)</span>}{u.isBot && <span className="text-[10px]">🤖</span>}{u.isDj && <span className="text-[10px]">🎧</span>}{u.mutedUntil && <span className="text-[10px]">🔇</span>}</div>
                        <div className="flex items-center gap-1 truncate text-[10px] muted"><span className="truncate">{u.status || u.mood || (room ? `${room.icon} ${room.name}` : "Gezinmede")}</span>{(() => { const ls = getLevelStyle(u.level); return <span className="lvl-badge shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-black text-white" style={{ background: ls.bg, boxShadow: ls.glow, animation: u.level >= 15 ? "lvl-pulse 2s infinite" : undefined }}>{ls.label} {u.level}</span>; })()}</div>
                      </div>
                      <div className="flex flex-col items-end gap-0.5">{voiceHolderId === u.id && <span className="rounded-full bg-emerald-500 px-1 text-[9px] font-black text-white animate-pulse">SES</span>}{u.cameraOn && <span className="rounded-full bg-rose-500 px-1 text-[9px] font-black text-white">CANLI</span>}{n > 0 && <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-black text-white">{n}</span>}</div>
                    </button>); })}
                </div>
              );
            })}
          </div>
          <div className="soft mt-2 flex cursor-pointer items-center gap-2 rounded-xl p-2" onClick={() => setModalState("points")}><LevelRing xp={me.xp} size={32} /><div className="min-w-0 flex-1 text-[11px] font-bold"><div>{me.points} puan · 🐷 {me.piggyBank} · tıkla detay</div><div className="muted">Seviye {levelFromXp(me.xp)} · {me.rank} · {Math.max(0, (xpForLevel(levelFromXp(me.xp)+1)-me.xp))} XP kaldı</div></div><button onClick={(e) => { e.stopPropagation(); setModalState("wheel"); }} className="text-lg">🎡</button></div>
        </aside>
        {mobile && (leftOpen || rightOpen) && <div className="absolute inset-0 z-[5] bg-black/30" onClick={() => { setLeftOpen(false); setRightOpen(false); }} />}
      </div>

      <div className="pointer-events-none fixed bottom-14 md:bottom-0 left-2 right-2 md:left-auto md:right-[19rem] z-30 flex flex-col md:flex-row items-end gap-2 justify-end">
        {dmWindows.map((w) => <div key={w.id} className="pointer-events-auto"><DmWindowWithCam peer={w} me={me} unread={unread[w.id] ?? 0} minimized={w.min} onToggle={() => setDmWindows((ws) => ws.map((x) => (x.id === w.id ? { ...x, min: !x.min } : x)))} onClose={() => setDmWindows((ws) => ws.filter((x) => x.id !== w.id))} notify={notify} cam={cam} /></div>)}
      </div>

      {modalState === "gift" && <GiftQuickModal me={me} online={online as unknown as { id: number; username: string; color: string; avatarUrl: string | null }[]} roomId={activeRoomId} onClose={() => setModalState(null)} notify={notify} />}
      {modalState === "points" && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setModalState(null)}><div onClick={(e) => e.stopPropagation()} className="w-full max-w-md"><PointsHUD me={me} /></div></div>}
      {profileId && <ProfileCard userId={profileId} me={me} roomId={activeRoomId} onClose={() => setProfileId(null)} onDm={openDm} onCall={startCall} notify={notify} refreshMe={refreshMe} />}
      {modalState === "settings" && <SettingsModal me={me} onClose={() => setModalState(null)} update={updateProfile} logout={logout} notify={notify} goRegister={async () => { await logout(); router.push("/?mode=register"); }} />}
      {modalState === "wheel" && <WheelModal onClose={() => setModalState(null)} notify={notify} refreshMe={refreshMe} />}
      {modalState === "leader" && <LeaderboardModal onClose={() => setModalState(null)} />}
      {modalState === "challenges" && <ChallengesModal me={me} onClose={() => setModalState(null)} notify={notify} refreshMe={refreshMe} />}
      {showNotifPrompt && (
        <div className="fixed bottom-20 left-4 right-4 z-50 md:left-auto md:right-4 md:max-w-sm">
          <div className="card rounded-2xl p-4 shadow-2xl border-2" style={{ borderColor: "var(--brand)" }}>
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full brand-gradient text-white text-lg">🔔</div>
              <div className="flex-1">
                <div className="text-sm font-black">Bildirimleri aç?</div>
                <div className="text-xs muted mt-1">Özel mesaj, bahsedilme ve aramaları kaçırmamak için izin ver. Sadece ilk girişte bir kez sorulur.</div>
                <div className="mt-3 flex gap-2">
                  <button onClick={async () => { localStorage.setItem("srcn_notif_asked", "1"); setShowNotifPrompt(false); if ("Notification" in window) { try { await Notification.requestPermission(); } catch {} } }} className="btn-primary flex-1 rounded-xl py-2 text-xs font-black">Evet, aç</button>
                  <button onClick={() => { localStorage.setItem("srcn_notif_asked", "1"); localStorage.setItem("srcn_notif_decision", "dismissed"); setShowNotifPrompt(false); }} className="btn-ghost flex-1 rounded-xl py-2 text-xs font-bold">Şimdi değil</button>
                </div>
                <div className="mt-2 text-[10px] muted text-center">Çerezler silinince tekrar sorulur. Ayarlar → Sesler’den değiştirebilirsin.</div>
              </div>
            </div>
          </div>
        </div>
      )}
      {modalState === "dj" && <DjPanel onClose={() => setModalState(null)} notify={notify} isDj={me.isDj || me.rank === "kurucu"} nowPlaying={nowPlaying} onCloseSong={closeSong} />}
      {toastEl}
      {/* Mobil alt navigasyon — masaüstünde gizli */}
      <MobileBottomNav
        activeTab={leftTab}
        onTab={(t) => { setLeftTab(t); setLeftOpen(true); }}
        onRooms={() => setLeftOpen(true)}
        onFriends={() => { setLeftTab("dostlar"); setLeftOpen(true); }}
        onCamera={() => { setLeftTab("kamera"); setLeftOpen(true); }}
        onGift={() => setModalState("gift")}
        onYoutube={() => setModalState("youtube")}
        onSettings={() => setModalState("settings")}
        unread={totalUnread}
        pendingFriends={pendingFriends}
        broadcasters={broadcasters.length}
        leftOpen={leftOpen}
        rightOpen={rightOpen}
        onToggleLeft={() => setLeftOpen((v) => !v)}
        onToggleRight={() => setRightOpen((v) => !v)}
        micAmHolder={voice.amHolder}
        micBusy={voiceBusy}
        micPosition={voice.myPosition}
        micHolderName={voice.holder?.username ?? null}
        onMicToggle={() => (voice.amHolder ? voiceRelease() : voiceTake())}
        onMicLeave={() => voiceLeave()}
      />
      <div className="h-14 md:hidden" />
    </div>
  );
}

function OwnPip({ cam }: { cam: ReturnType<typeof useCamera> }) {
  const ref = useRef<HTMLVideoElement | null>(null);
  useEffect(() => { if (ref.current && cam.stream) ref.current.srcObject = cam.stream; }, [cam.stream]);
  return (
    <div className="flex items-center gap-2 border-b px-2 py-1.5" style={{ background: "var(--surface-2)", borderColor: "var(--border)" }}>
      <video ref={ref} autoPlay muted playsInline className="h-16 w-24 rounded-xl bg-black object-cover" style={{ filter: cam.filterCss, transform: "scaleX(-1)" }} />
      <div className="min-w-0 flex-1"><div className="text-xs font-black">📹 Yayındasın</div><div className="text-[11px] muted">Herkes seni izleyebilir</div><div className="mt-1 flex gap-1">{cam.FILTERS.map((f) => <button key={f.key} onClick={() => cam.setFilter(f.key)} className={`rounded-lg px-1.5 py-0.5 text-[10px] font-extrabold ${cam.filter === f.key ? "brand-gradient text-white" : "soft"}`}>{f.label}</button>)}</div></div>
      <button onClick={cam.stop} className="btn-danger rounded-xl px-2 py-1 text-xs font-extrabold">Kapat</button>
    </div>
  );
}

function DmWindowWithCam({ peer, me, unread, minimized, onToggle, onClose, notify, cam }: { peer: DmPeer; me: { id: number; points: number }; unread: number; minimized: boolean; onToggle: () => void; onClose: () => void; notify: (m: string) => void; cam: ReturnType<typeof useCamera> }) {
  const [snapOpen, setSnapOpen] = useState(false);
  const snapRef = useRef<HTMLVideoElement | null>(null);
  const [snapStream, setSnapStream] = useState<MediaStream | null>(null);
  useEffect(() => { if (snapOpen && snapRef.current && snapStream) snapRef.current.srcObject = snapStream; }, [snapOpen, snapStream]);
  async function openSnap() {
    // try own broadcast stream first, else request new
    if (cam.stream) {
      // capture from own broadcast
      const v = document.createElement("video"); v.srcObject = cam.stream; await v.play().catch(() => {}); await new Promise((r) => setTimeout(r, 200));
      const c = document.createElement("canvas"); c.width = v.videoWidth || 640; c.height = v.videoHeight || 480; c.getContext("2d")!.drawImage(v, 0, 0);
      const url = c.toDataURL("image/jpeg", 0.85);
      const r = await fetch(`/api/dm/${peer.id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: url, kind: "ephemeral" }) });
      if (r.ok) notify("📷 Fotoğraf gönderildi (5 sn)"); else notify("Gönderilemedi");
      return;
    }
    try { const s = await navigator.mediaDevices.getUserMedia({ video: true }); setSnapStream(s); setSnapOpen(true); } catch { notify("Kamera açılamadı"); }
  }
  async function captureAndSend() {
    if (!snapStream) return;
    const v = snapRef.current!; const c = document.createElement("canvas"); c.width = v.videoWidth; c.height = v.videoHeight; c.getContext("2d")!.drawImage(v, 0, 0);
    const url = c.toDataURL("image/jpeg", 0.85);
    snapStream.getTracks().forEach((t) => t.stop()); setSnapStream(null); setSnapOpen(false);
    const r = await fetch(`/api/dm/${peer.id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: url, kind: "ephemeral" }) });
    if (r.ok) notify("📷 Kaybolan fotoğraf gönderildi"); else notify("Gönderilemedi");
  }
  return (
    <div className="flex flex-col">
      {snapOpen && <div className="card mb-1 rounded-2xl p-2"><video ref={snapRef} autoPlay muted playsInline className="h-32 w-full rounded-xl bg-black object-cover" style={{ transform: "scaleX(-1)" }} /><div className="mt-1 flex gap-1"><button onClick={captureAndSend} className="btn-primary flex-1 rounded-lg py-1 text-xs font-extrabold">📸 Gönder (5 sn)</button><button onClick={() => { snapStream?.getTracks().forEach((t) => t.stop()); setSnapStream(null); setSnapOpen(false); }} className="btn-ghost flex-1 rounded-lg py-1 text-xs font-extrabold">İptal</button></div></div>}
      <div className="relative">
        <DmWindow peer={peer} me={me} unread={unread} minimized={minimized} onToggle={onToggle} onClose={onClose} notify={notify} />
        {!minimized && <button onClick={openSnap} className="absolute bottom-12 right-2 rounded-full bg-black/60 px-2 py-1 text-xs font-extrabold text-white">📷</button>}
      </div>
    </div>
  );
}

function LeftRadioDJ({ radio, nowPlaying, onStopDj }: { radio: { enabled: boolean; station: string; customUrl: string }; nowPlaying: { title: string; artist: string; youtubeId?: string; previewUrl?: string; artwork?: string; djName?: string } | null; onStopDj: () => void }) {
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [station, setStation] = useState(radio.station || "paradise");
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [djPlaying, setDjPlaying] = useState(true);
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);
  useEffect(() => { const a = audioRef.current; if (!a) return; const st = THEMES ? null : null; void st; if (playing) { const s = (radio.enabled ? (station === "custom" ? radio.customUrl : (RADIO_STATIONS.find((x) => x.id === station)?.url ?? "")) : ""); if (s) { a.src = s; a.play().catch(()=>{}); } } else { a.pause(); } }, [playing, station, radio.enabled, radio.customUrl]);
  useEffect(() => { if (nowPlaying?.youtubeId) setDjPlaying(true); }, [nowPlaying?.youtubeId]);
  if (!radio.enabled && !nowPlaying) return <div className="soft rounded-xl p-3 text-center text-xs muted">📻 Radyo kapalı</div>;
  // need RADIO_STATIONS import
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between"><span className="text-[11px] font-black tracking-widest" style={{ color: "var(--brand)" }}>📻 RADYO & DJ</span>{nowPlaying && <span className="rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-black text-white animate-pulse">CANLI</span>}</div>
      <div className="soft rounded-xl p-2">
        <div className="flex items-center gap-2">
          <button onClick={() => setPlaying(!playing)} className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white ${playing ? "bg-red-500" : "brand-gradient"}`}>{playing ? "❚❚" : "▶"}</button>
          <div className="min-w-0 flex-1"><div className="truncate text-xs font-black">{playing ? (RADIO_STATIONS.find((x) => x.id === station)?.name ?? "Radyo") : "Radyo durdu"}</div><div className="truncate text-[10px] muted">{playing ? "Canlı yayın" : "Başlat için ▶"}</div></div>
          <select value={station} onChange={(e) => setStation(e.target.value)} className="input rounded-lg px-1 py-1 text-[10px]"><option value="paradise">Paradise</option><option value="soma-groove">Groove</option><option value="paradise-mellow">Mellow</option></select>
        </div>
        <div className="mt-1 flex items-center gap-1 text-[10px]">🔈<input type="range" min={0} max={1} step={0.05} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="flex-1" style={{ accentColor: "var(--brand)" }} /></div>
        <audio ref={audioRef} preload="none" style={{ display: "none" }} />
      </div>
      {nowPlaying ? (
        <div className="card rounded-xl p-2">
          <div className="flex items-center gap-2"><span className={`flex h-7 w-7 items-center justify-center rounded-lg text-white ${nowPlaying.youtubeId ? "bg-red-500" : "brand-gradient"}`}>{nowPlaying.youtubeId ? "▶" : "🎧"}</span><div className="min-w-0 flex-1"><div className="truncate text-xs font-black">{nowPlaying.title}</div><div className="truncate text-[10px] muted">{nowPlaying.artist} · DJ {nowPlaying.djName}</div></div></div>
          {nowPlaying.youtubeId ? (
            <div className="mt-2 overflow-hidden rounded-xl border" style={{ borderColor: "var(--border)" }}>{djPlaying ? <iframe src={`https://www.youtube.com/embed/${nowPlaying.youtubeId}?autoplay=1&controls=1&rel=0`} className="h-28 w-full" allow="autoplay; encrypted-media" allowFullScreen title={nowPlaying.title} /> : <div className="flex h-16 items-center justify-center bg-black text-[10px] font-bold text-white/60">Durduruldu</div>}</div>
          ) : nowPlaying.previewUrl ? <audio controls autoPlay src={nowPlaying.previewUrl} className="mt-2 w-full" /> : null}
          <div className="mt-2 flex gap-1"><button onClick={() => setDjPlaying(!djPlaying)} className={`flex-1 rounded-lg py-1 text-xs font-extrabold ${djPlaying ? "btn-ghost" : "brand-gradient text-white"}`}>{djPlaying ? "⏸ Durdur" : "▶ Başlat"}</button><button onClick={onStopDj} className="btn-danger flex-1 rounded-lg py-1 text-xs font-bold">✕ Kapat</button></div>
          {nowPlaying.artwork && <img src={nowPlaying.artwork} alt="" className="mt-2 h-12 w-12 rounded-lg object-cover" />}
        </div>
      ) : <div className="soft rounded-xl p-2 text-center text-[11px] muted">DJ’den şarkı bekleniyor… İstek at!</div>}
      <div className="text-[10px] muted text-center">Bot sistemi YouTube’dan tam sürüm çeker — kısa demo değil, full şarkı.</div>
    </div>
  );
}
