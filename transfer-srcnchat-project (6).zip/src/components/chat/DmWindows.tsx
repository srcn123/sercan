"use client";
import { useEffect, useRef, useState } from "react";
import { Avatar, RankBadge, fileToDataUrl, timeOf } from "../ui";
import { makePeer, onSignal, sendSignal } from "./webrtc";
import type { Notify } from "./Panels";

export type DmPeer = { id: number; username: string; color: string; rank: string; avatarUrl?: string | null };
type Dm = { id: number; fromUserId: number; toUserId: number; content: string; kind: string; meta: Record<string, unknown>; isRead: boolean; createdAt: string };
type Game = { id: number; type: string; player1: number; player2: number; bet: number; state: Record<string, unknown>; status: string; winnerId: number | null };

export function DmWindow({ peer, me, onClose, notify, minimized, onToggle, unread }: { peer: DmPeer; me: { id: number; points: number }; onClose: () => void; notify: Notify; minimized: boolean; onToggle: () => void; unread: number }) {
  const [msgs, setMsgs] = useState<Dm[]>([]);
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(false);
  const [game, setGame] = useState<Game | null>(null);
  const [showGames, setShowGames] = useState(false);
  const [bet, setBet] = useState(0);
  const last = useRef(0);
  const listRef = useRef<HTMLDivElement | null>(null);
  const typingSent = useRef(0);

  useEffect(() => {
    let alive = true; last.current = 0;
    const load = async () => {
      const r = await fetch(`/api/dm/${peer.id}${last.current ? `?after=${last.current}` : ""}`, { cache: "no-store" });
      if (!r.ok || !alive) return;
      const d = await r.json();
      setTyping(!!d.peer?.typing);
      const inc: Dm[] = d.messages;
      if (d.updates) setMsgs((p) => p.map((m) => { const u = (d.updates as Dm[]).find((x) => x.id === m.id); return u ? { ...m, isRead: u.isRead, kind: u.kind, content: u.content } : m; }));
      if (inc.length) { last.current = inc[inc.length - 1].id; setMsgs((p) => { const ids = new Set(p.map((x) => x.id)); return [...p, ...inc.filter((x) => !ids.has(x.id))].slice(-200); }); }
      const g = await fetch(`/api/games?peer=${peer.id}`, { cache: "no-store" });
      if (g.ok && alive) setGame((await g.json()).game);
    };
    load(); const t = setInterval(load, 2500);
    return () => { alive = false; clearInterval(t); };
  }, [peer.id]);
  useEffect(() => { const el = listRef.current; if (el) el.scrollTop = el.scrollHeight; }, [msgs, minimized]);

  async function send(e?: React.FormEvent) {
    e?.preventDefault();
    const c = draft.trim(); if (!c) return;
    setDraft("");
    const r = await fetch(`/api/dm/${peer.id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: c }) });
    const d = await r.json();
    if (!r.ok) { notify(d.error); return; }
    setMsgs((p) => (p.some((m) => m.id === d.message.id) ? p : [...p, d.message])); last.current = Math.max(last.current, d.message.id);
  }
  async function sendEphemeral(file?: File) {
    if (!file) return;
    const url = await fileToDataUrl(file, 640);
    const r = await fetch(`/api/dm/${peer.id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: url, kind: "ephemeral" }) });
    if (r.ok) notify("⏱ 5 saniyelik medya gönderildi");
  }
  function onType(v: string) { setDraft(v); if (Date.now() - typingSent.current > 2500) { typingSent.current = Date.now(); fetch("/api/typing", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target: `dm:${peer.id}` }) }); } }
  async function newGame(type: string) { const r = await fetch("/api/games", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, peer: peer.id, bet }) }); const d = await r.json(); if (r.ok) { setGame(d.game); setShowGames(false); } else notify(d.error); }
  async function play(body: Record<string, unknown>) { if (!game) return; const r = await fetch(`/api/games/${game.id}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const d = await r.json(); if (r.ok) setGame(d.game); else notify(d.error); }

  const gameName = (t: string) => ({ rps: "Taş-Kağıt-Makas", trivia: "Trivia", word: "Kelime Tahmin", truth: "Doğruluk mu Cesaret mi" })[t] ?? t;

  return (
    <div className="dm-window card flex w-full sm:w-[320px] flex-col overflow-hidden rounded-t-2xl shadow-2xl" style={{ height: minimized ? 44 : 360, maxHeight: "min(420px, 60vh)", maxWidth: "100%" }}>
      <div className="brand-gradient flex cursor-pointer items-center gap-2 px-3 py-2 text-white" onClick={onToggle}>
        <Avatar name={peer.username} color={peer.color} url={peer.avatarUrl} size={24} />
        <span className="truncate text-sm font-extrabold">{peer.username}</span>
        <RankBadge rank={peer.rank} compact />
        {unread > 0 && minimized && <span className="rounded-full bg-white px-1.5 text-[10px] font-black" style={{ color: "var(--brand)" }}>{unread}</span>}
        <div className="ml-auto flex gap-1">
          <button onClick={(e) => { e.stopPropagation(); setShowGames((s) => !s); }} className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20 text-sm md:h-6 md:w-6 md:text-xs" title="Mini oyun">🎮</button>
          <button onClick={(e) => { e.stopPropagation(); window.dispatchEvent(new CustomEvent("srcn:call", { detail: peer.id })); }} className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20 text-sm md:h-6 md:w-6 md:text-xs" title="Görüntülü ara">📹</button>
          <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20 text-base font-black md:h-6 md:w-6 md:text-xs" aria-label="Kapat">✕</button>
        </div>
      </div>
      {!minimized && (
        <>
          {showGames && (
            <div className="soft border-b p-2 text-xs">
              <div className="mb-1 flex items-center gap-2 font-extrabold">Oyun seç <input type="number" min={0} max={me.points} value={bet} onChange={(e) => setBet(Number(e.target.value))} className="input ml-auto w-16 rounded-lg px-2 py-0.5" title="Bahis (puan)" /><span className="muted">puan bahis</span></div>
              <div className="grid grid-cols-2 gap-1">{["rps", "trivia", "word", "truth"].map((t) => <button key={t} onClick={() => newGame(t)} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">{gameName(t)}</button>)}</div>
            </div>
          )}
          {game && game.status === "active" && <GameBox game={game} meId={me.id} play={play} name={gameName(game.type)} />}
          <div ref={listRef} className="scroll-thin flex-1 space-y-1.5 overflow-y-auto p-2">
            {msgs.map((m) => {
              const mine = m.fromUserId === me.id;
              return (
                <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[82%] rounded-2xl px-3 py-1.5 text-sm shadow-sm ${mine ? "rounded-br-md text-white" : "soft rounded-bl-md"}`} style={mine ? { background: "var(--bubble-me)" } : undefined}>
                    {m.kind === "ephemeral" ? <Ephemeral m={m} mine={mine} peerId={peer.id} /> : m.kind === "expired" ? <span className="text-xs italic opacity-70">⏱ Kaybolan medya süresi doldu</span> : <div className="whitespace-pre-wrap break-words">{m.content}</div>}
                    <div className={`mt-0.5 flex items-center justify-end gap-1 text-[10px] ${mine ? "text-white/70" : "muted"}`}>{timeOf(m.createdAt)}{mine && <span title={m.isRead ? "Okundu" : "İletildi"}>{m.isRead ? "✓✓" : "✓"}</span>}</div>
                  </div>
                </div>
              );
            })}
            {typing && <div className="text-[11px] font-bold muted">✍️ {peer.username} yazıyor…</div>}
          </div>
          <form onSubmit={send} className="flex items-center gap-1 border-t p-2" style={{ borderColor: "var(--border)" }}>
            <label className="cursor-pointer rounded-lg px-1.5 text-base" title="5 saniyelik kaybolan fotoğraf">⏱<input type="file" accept="image/*" className="hidden" onChange={(e) => sendEphemeral(e.target.files?.[0])} /></label>
            <input value={draft} onChange={(e) => onType(e.target.value)} className="input flex-1 rounded-xl px-3 py-1.5 text-sm" placeholder="Mesaj yaz…" />
            <button className="btn-primary rounded-xl px-3 py-1.5 text-xs font-extrabold">➤</button>
          </form>
        </>
      )}
    </div>
  );
}

function Ephemeral({ m, mine, peerId }: { m: Dm; mine: boolean; peerId: number }) {
  const [open, setOpen] = useState(false);
  const [left, setLeft] = useState(5);
  useEffect(() => { if (!open) return; fetch(`/api/dm/${peerId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "view", id: m.id }) }); const t = setInterval(() => setLeft((l) => { if (l <= 1) { clearInterval(t); setOpen(false); } return l - 1; }), 1000); return () => clearInterval(t); }, [open, m.id, peerId]);
  if (mine) return <span className="text-xs">⏱ Kaybolan fotoğraf gönderdin</span>;
  if (left <= 0) return <span className="text-xs italic opacity-70">⏱ Süresi doldu</span>;
  return open ? <div className="relative"><img src={m.content} alt="" className="max-h-40 rounded-xl" /><span className="absolute right-1 top-1 rounded-full bg-black/60 px-1.5 text-[10px] font-black text-white">{left}s</span></div> : <button onClick={() => setOpen(true)} className="text-xs font-extrabold underline">⏱ Kaybolan fotoğrafı aç (5 sn)</button>;
}

function GameBox({ game, meId, play, name }: { game: Game; meId: number; play: (b: Record<string, unknown>) => void; name: string }) {
  const [input, setInput] = useState("");
  const st = game.state as Record<string, Record<string, unknown> | unknown>;
  const key = String(meId);
  return (
    <div className="border-b p-2 text-xs" style={{ background: "var(--brand-soft)", borderColor: "var(--border)" }}>
      <div className="font-extrabold">🎮 {name}{game.bet ? ` · ${game.bet} puan bahis` : ""}</div>
      {game.type === "rps" && (((st.moves as Record<string, string>) ?? {})[key] ? <div className="muted">Hamleni yaptın, rakip bekleniyor…</div> : <div className="mt-1 flex gap-1">{[["tas", "✊ Taş"], ["kagit", "✋ Kağıt"], ["makas", "✌️ Makas"]].map(([k, l]) => <button key={k} onClick={() => play({ move: k })} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">{l}</button>)}</div>)}
      {game.type === "trivia" && (() => { const q = st.q as { q: string; a: string[] }; const answered = ((st.answers as Record<string, number>) ?? {})[key] !== undefined; return <div><div className="mt-1 font-bold">{q.q}</div>{answered ? <div className="muted">Cevapladın, rakip bekleniyor…</div> : <div className="mt-1 grid grid-cols-2 gap-1">{q.a.map((a, i) => <button key={i} onClick={() => play({ answer: i })} className="btn-ghost rounded-lg px-2 py-1 font-extrabold">{a}</button>)}</div>}</div>; })()}
      {game.type === "word" && <div><div className="mt-1 font-bold tracking-widest">{String(st.hint)} ({String(st.word).length} harf)</div><div className="muted">Denemelerin: {(((st.guesses as Record<string, string[]>) ?? {})[key] ?? []).join(", ") || "—"}</div><form onSubmit={(e) => { e.preventDefault(); if (input) { play({ guess: input }); setInput(""); } }} className="mt-1 flex gap-1"><input value={input} onChange={(e) => setInput(e.target.value)} className="input flex-1 rounded-lg px-2 py-1" placeholder="tahmin" /><button className="btn-primary rounded-lg px-2 font-extrabold">Dene</button></form></div>}
      {game.type === "truth" && (() => { const p = st.prompt as { kind: string; text: string }; const done = ((st.done as Record<string, string>) ?? {})[key]; return <div><div className="mt-1 font-bold">{p.kind}: {p.text}</div>{done ? <div className="muted">Cevabın: {done}</div> : <form onSubmit={(e) => { e.preventDefault(); if (input) { play({ answer: input }); setInput(""); } }} className="mt-1 flex gap-1"><input value={input} onChange={(e) => setInput(e.target.value)} className="input flex-1 rounded-lg px-2 py-1" placeholder="cevabın" /><button className="btn-primary rounded-lg px-2 font-extrabold">Gönder</button></form>}</div>; })()}
    </div>
  );
}

/* ---------------- VIDEO CALL ---------------- */
export function VideoCall({ peerId, peerName, incoming, offer, onEnd }: { peerId: number; peerName: string; incoming: boolean; offer?: RTCSessionDescriptionInit; onEnd: () => void }) {
  const local = useRef<HTMLVideoElement | null>(null);
  const remote = useRef<HTMLVideoElement | null>(null);
  const [state, setState] = useState(incoming ? "Bağlanıyor…" : "Aranıyor…");
  useEffect(() => {
    let pc: RTCPeerConnection | null = null; let stream: MediaStream | null = null; let ended = false;
    const end = () => { if (ended) return; ended = true; stream?.getTracks().forEach((t) => t.stop()); pc?.close(); onEnd(); };
    const off = onSignal(async (s) => {
      if (s.channel !== "call" || s.fromUserId !== peerId || !pc) return;
      if (s.type === "answer") await pc.setRemoteDescription(s.payload as unknown as RTCSessionDescriptionInit).catch(() => {});
      else if (s.type === "ice") await pc.addIceCandidate(s.payload as unknown as RTCIceCandidateInit).catch(() => {});
      else if (s.type === "bye") { setState("Görüşme bitti"); setTimeout(end, 800); }
    });
    (async () => {
      try { stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true }); } catch { setState("Kamera erişimi yok"); return; }
      if (local.current) local.current.srcObject = stream;
      pc = makePeer(peerId, "call", (rs) => { if (remote.current) remote.current.srcObject = rs; setState("Görüşmede"); }, () => setState("Bağlantı koptu"));
      stream.getTracks().forEach((t) => pc!.addTrack(t, stream!));
      if (incoming && offer) {
        await pc.setRemoteDescription(offer);
        const ans = await pc.createAnswer(); await pc.setLocalDescription(ans);
        await sendSignal(peerId, "call", "answer", ans as unknown as Record<string, unknown>);
      } else {
        const of = await pc.createOffer(); await pc.setLocalDescription(of);
        await sendSignal(peerId, "call", "offer", of as unknown as Record<string, unknown>);
      }
    })();
    return () => { off(); if (!ended) { sendSignal(peerId, "call", "bye"); stream?.getTracks().forEach((t) => t.stop()); pc?.close(); } };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [peerId]);
  return (
    <div className="fixed bottom-4 right-4 z-[55] w-[320px] overflow-hidden rounded-3xl bg-black shadow-2xl">
      <video ref={remote} autoPlay playsInline className="h-60 w-full object-cover" />
      <video ref={local} autoPlay muted playsInline className="absolute right-3 top-3 h-20 w-28 rounded-xl border-2 border-white/40 object-cover" style={{ transform: "scaleX(-1)" }} />
      <div className="flex items-center justify-between px-4 py-3 text-white"><div><div className="text-sm font-extrabold">📹 {peerName}</div><div className="text-[11px] text-white/70">{state}</div></div><button onClick={() => { sendSignal(peerId, "call", "bye"); onEnd(); }} className="rounded-full bg-rose-500 px-4 py-2 text-xs font-extrabold">Kapat</button></div>
    </div>
  );
}
