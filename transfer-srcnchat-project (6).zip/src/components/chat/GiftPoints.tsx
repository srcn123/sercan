"use client";
import { useEffect, useState } from "react";
import { GIFTS, levelFromXp, xpForLevel } from "@/lib/constants";
import { Avatar, GiftIcon, Modal } from "../ui";
import type { PublicUser } from "@/lib/auth";

export function GiftQuickModal({ me, online, roomId, onClose, notify }: { me: PublicUser; online: { id: number; username: string; color: string; avatarUrl: string | null }[]; roomId: number | null; onClose: () => void; notify: (m: string) => void }) {
  const [target, setTarget] = useState<number | null>(null);
  const [q, setQ] = useState("");
  const filtered = online.filter((u) => u.id !== me.id && u.username.toLowerCase().includes(q.toLowerCase())).slice(0, 8);
  const [sending, setSending] = useState<string | null>(null);
  async function send(giftKey: string) {
    if (!target) { notify("Önce bir kullanıcı seç"); return; }
    setSending(giftKey);
    const r = await fetch("/api/gifts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ giftKey, toUserId: target, roomId }) });
    const d = await r.json().catch(() => ({}));
    setSending(null);
    if (!r.ok) notify(d.error ?? "Gönderilemedi"); else { const t = filtered.find((u) => u.id === target); const g = GIFTS.find((x) => x.key === giftKey); notify(`${g?.emoji ?? "🎁"} ${g?.name ?? giftKey} → ${t?.username ?? "—"} gönderildi! Kısa süre sonra kaybolacak`); onClose(); }
  }
  return (
    <Modal onClose={onClose} wide>
      <div className="text-lg font-black">🎁 Hediye Gönder — Daha Belirgin</div>
      <p className="text-xs muted">Bir kullanıcı seç, ardından 12 hediyeden birini tek tıkla gönder. Tüm odada anons edilir, puan anında düşer.</p>
      <div className="label">Alıcı seç (çevrimiçi)</div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Kullanıcı ara..." className="input w-full rounded-xl px-3 py-2 text-sm" />
      <div className="mt-2 grid max-h-32 grid-cols-2 gap-1 overflow-y-auto sm:grid-cols-4">
        {filtered.map((u) => (
          <button key={u.id} onClick={() => setTarget(u.id)} className={`flex items-center gap-2 rounded-xl border px-2 py-1.5 text-left ${target === u.id ? "border-[var(--brand)] bg-[var(--brand-soft)]" : "soft"}`}>
            <Avatar name={u.username} color={u.color} url={u.avatarUrl} size={28} />
            <span className="truncate text-xs font-extrabold" style={{ color: u.color }}>{u.username}</span>
            {target === u.id && <span className="ml-auto text-xs">✓</span>}
          </button>
        ))}
        {filtered.length === 0 && <div className="col-span-full py-2 text-center text-xs muted">Eşleşen kullanıcı yok — adını tam yaz.</div>}
      </div>
      <div className="label">Hediye seç — puanına dikkat et: {me.points} P</div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
        {GIFTS.map((g) => (
          <button key={g.key} disabled={!!sending} onClick={() => send(g.key)} className="gift-fly soft flex flex-col items-center rounded-2xl p-2 transition hover:scale-105 disabled:opacity-40">
            <GiftIcon giftKey={g.key} size={56} />
            <div className="mt-1 text-xs font-extrabold">{g.name}</div>
            <div className="text-[11px] font-black" style={{ color: me.points >= g.points ? "var(--brand)" : "#ef4444" }}>{g.points} P {me.points < g.points && "— yetersiz"}</div>
            {sending === g.key && <span className="text-[10px] muted">gönderiliyor…</span>}
          </button>
        ))}
      </div>
      <div className="soft mt-3 rounded-2xl p-3 text-xs leading-relaxed muted">💡 İpucu: En pahalı hediye <b>Saray (5000 P)</b> tüm odada büyük animasyonla duyurulur. Günlük çark ve okey ile puan kas, seviye atla!</div>
    </Modal>
  );
}

export function PointsHUD({ me }: { me: PublicUser }) {
  const lvl = levelFromXp(me.xp);
  const cur = xpForLevel(lvl), nxt = xpForLevel(lvl + 1);
  const pct = Math.max(4, Math.min(100, Math.round(((me.xp - cur) / Math.max(1, nxt - cur)) * 100)));
  const toNext = nxt - me.xp;
  const missions = [
    { icon: "💬", text: "5 oda mesajı at", done: me.totalMessages % 5, total: 5, reward: "+5 P" },
    { icon: "👥", text: "1 arkadaş ekle", done: 0, total: 1, reward: "+10 P" },
    { icon: "🎡", text: "Çark çevir", done: 0, total: 1, reward: "+10-250 P" },
    { icon: "🀄", text: "Okey bitir", done: 0, total: 1, reward: "+25 P" },
  ];
  return (
    <div className="soft rounded-2xl p-3">
      <div className="flex items-center justify-between"><span className="text-xs font-black">⭐ Seviye {lvl} · {me.points} Puan</span><span className="text-[10px] font-bold muted">{toNext} XP sonra Lv {lvl + 1}</span></div>
      <div className="mt-1.5 h-2 overflow-hidden rounded-full" style={{ background: "var(--border)" }}><div className="h-full brand-gradient transition-all" style={{ width: `${pct}%` }} /></div>
      <div className="mt-2 grid grid-cols-2 gap-1.5 sm:grid-cols-4">
        {missions.map((m) => (
          <div key={m.text} className="card flex flex-col items-center rounded-xl p-2 text-center">
            <span className="text-lg">{m.icon}</span><span className="mt-0.5 text-[10px] font-extrabold leading-tight">{m.text}</span><span className="text-[9px] muted">{m.done}/{m.total} · {m.reward}</span>
            <div className="mt-1 h-1 w-full overflow-hidden rounded-full" style={{ background: "var(--border)" }}><div className="h-full bg-emerald-400" style={{ width: `${(m.done / m.total) * 100}%` }} /></div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center gap-2 text-[11px] font-bold muted">
        <span>🔥 Durdukça +5 P / 2 dk</span><span>·</span><span>💬 Mesaj +1 P</span><span>·</span><span>✉️ Özel +2 P</span>
        <span className="ml-auto rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-black text-amber-700">🐷 Kumbara: {me.piggyBank}</span>
      </div>
    </div>
  );
}
