"use client";
import { useCallback, useEffect, useState } from "react";
import { COLORS, RACK_SIZE, type Tile } from "@/lib/okey";

type SeatView = { userId: number; username: string; color: string; rack: (Tile | null)[]; drawn: boolean; tileCount: number } | null;
type View = { seats: SeatView[]; deckCount: number; indicator: Tile | null; okey: { color: number; num: number } | null; discards: Tile[][]; turn: number; phase: string; winner?: { username: string; pairs: boolean }; log: string[]; spectators: number[]; chat: { user: string; text: string; t: number }[] };
type Lobby = { id: number; players: string[]; phase: string; spectators: number }[];

function TileView({ t, okey, selected, onClick, draggable, onDragStart, small, tiny }: { t: Tile; okey: View["okey"]; selected?: boolean; onClick?: () => void; draggable?: boolean; onDragStart?: (e: React.DragEvent) => void; small?: boolean; tiny?: boolean }) {
  const joker = okey && !t.fake && t.color === okey.color && t.num === okey.num;
  const c = t.fake ? "#111827" : COLORS[t.color];
  const w = tiny ? 22 : small ? 26 : 34, h = tiny ? 32 : small ? 38 : 48, fs = tiny ? 12 : small ? 14 : 18;
  return (
    <div className={`tile ${selected ? "sel" : ""} ${joker ? "joker" : ""}`} style={{ color: c, width: w, height: h, fontSize: fs }} onClick={onClick} draggable={draggable} onDragStart={onDragStart} title={t.fake ? "Sahte okey ★" : joker ? "OKEY (joker)" : `${t.num}`}>
      {t.fake ? <span>★</span> : t.num}
      <span className="dot" style={{ background: c }} />
    </div>
  );
}

function PlayerBar({ seat, idx, view, isTurn, vertical }: { seat: SeatView; idx: number; view: View; isTurn: boolean; vertical?: boolean }) {
  if (!seat) return <div className={`flex items-center gap-2 rounded-xl bg-black/40 px-3 py-2 text-white ${vertical ? "flex-col" : ""}`}><span className="text-xs font-bold text-white/60">Boş koltuk</span></div>;
  const lastDiscard = view.discards[idx]?.[view.discards[idx].length - 1];
  return (
    <div className={`flex items-center gap-2 rounded-xl px-3 py-2 text-white shadow-lg ${isTurn ? "bg-amber-400 text-black ring-2 ring-amber-200" : "bg-black/50"}`} style={{ minWidth: 120 }}>
      <img src={`https://i.pravatar.cc/40?u=${seat.username}`} alt="" className="h-8 w-8 rounded-full border-2 border-white/80" />
      <div className="min-w-0 flex-1"><div className="truncate text-xs font-black">{seat.username}</div><div className="text-[10px] font-bold opacity-80">PUAN: {21} · {seat.tileCount} taş {seat.drawn ? "●" : ""}</div></div>
      {lastDiscard && <div className="flex flex-col items-center"><span className="text-[9px] font-bold opacity-70">attı</span><TileView t={lastDiscard} okey={view.okey} tiny /></div>}
      <div className={`h-6 w-6 rounded-full flex items-center justify-center text-xs ${isTurn ? "bg-black text-amber-300" : "bg-white/20"}`}>{isTurn ? "▶" : "●"}</div>
    </div>
  );
}

export function OkeyRoom({ me, notify }: { me: { id: number; username: string }; notify: (m: string) => void }) {
  const [lobby, setLobby] = useState<Lobby>([]);
  const [table, setTable] = useState<number | null>(null);
  const [view, setView] = useState<View | null>(null);
  const [sel, setSel] = useState<number | null>(null);
  const [chat, setChat] = useState("");
  const [over, setOver] = useState<number | null>(null);

  const loadLobby = useCallback(async () => { const r = await fetch("/api/okey/0", { cache: "no-store" }); if (r.ok) setLobby((await r.json()).tables); }, []);
  const loadTable = useCallback(async () => { if (!table) return; const r = await fetch(`/api/okey/${table}`, { cache: "no-store" }); if (r.ok) setView((await r.json()).state); }, [table]);
  useEffect(() => { loadLobby(); const t = setInterval(loadLobby, 5000); return () => clearInterval(t); }, [loadLobby]);
  useEffect(() => { if (!table) return; loadTable(); const t = setInterval(loadTable, 1800); return () => clearInterval(t); }, [table, loadTable]);
  async function act(action: string, extra: Record<string, unknown> = {}) {
    if (!table) return;
    const r = await fetch(`/api/okey/${table}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, ...extra }) });
    const d = await r.json();
    if (!r.ok) { notify(d.error); return; }
    setView(d.state); setSel(null);
  }

  if (!table) {
    return (
      <div className="mx-auto max-w-3xl space-y-4 p-4">
        <div className="text-center"><div className="text-2xl font-black">🀄 Okey Salonu — Gerçek Masa</div><div className="text-sm muted">Resimdeki gibi keçe masa, ahşap ıstaka, fildişi taşlar. 3 masa, 106 taş, gösterge & okey tam kurallı.</div></div>
        <div className="grid gap-3 sm:grid-cols-3">
          {lobby.map((t) => (
            <button key={t.id} onClick={() => setTable(t.id)} className="felt rounded-3xl p-5 text-left text-white transition hover:scale-[1.02]">
              <div className="text-lg font-black">Masa {t.id}</div>
              <div className="text-xs font-bold text-white/80">{t.phase === "playing" ? "🎲 Oyun sürüyor" : t.phase === "finished" ? "🏁 Bitti" : "⏳ Bekliyor"}</div>
              <div className="mt-3 text-xs font-bold">{t.players.length}/4 oyuncu · 👁 {t.spectators} izleyici</div>
              <div className="mt-1 truncate text-[11px] text-white/70">{t.players.join(", ") || "Boş masa — otur"}</div>
            </button>
          ))}
        </div>
        <div className="soft rounded-2xl p-4 text-xs leading-relaxed muted"><b>Gerçek kurallar:</b> 106 taş (4 renk × 1-13 × 2 + 2 sahte okey). Gösterge belirlendikten sonra bir üstü okey olur ve joker gibi her taşın yerine geçer. Ortadan veya soldaki oyuncunun attığından çek, elini seri/per veya 7 çift yaparak bitir. Taşları ıstakada sürükleyerek diz — aradaki boşluk grup sınırıdır.</div>
      </div>
    );
  }
  if (!view) return <div className="p-6 text-center text-sm font-bold muted">Masa yükleniyor…</div>;

  const mySeat = view.seats.findIndex((s) => s?.userId === me.id);
  const seated = mySeat >= 0;
  const myTurn = view.phase === "playing" && view.turn === mySeat;
  const my = seated ? view.seats[mySeat]! : null;
  const leftSeat = (() => { for (let k = 1; k <= 4; k++) { const i = (mySeat - k + 4) % 4; if (view.seats[i] && mySeat >=0) return i; } return -1; })();
  const rackIds = my ? my.rack.map((t) => (t ? t.id : null)) : [];
  function moveTile(from: number, to: number) { if (!my) return; const next = rackIds.slice(); const a = next[from]; next[from] = next[to]; next[to] = a; act("arrange", { rack: next }); }
  // seat order: 0=me bottom, 1=right, 2=top, 3=left (like image)
  const order = mySeat >=0 ? [0,1,2,3].map((k) => (mySeat + k) % 4) : [0,1,2,3];
  const topIdx = order[2], rightIdx = order[1], leftIdx = order[3];

  return (
    <div className="mx-auto w-full max-w-5xl p-2 noselect">
      <div className="mb-2 flex flex-wrap items-center gap-2 text-xs font-extrabold">
        <button onClick={() => { setTable(null); setView(null); }} className="btn-ghost rounded-lg px-2.5 py-1">← Salon</button>
        <span className="rounded-full bg-black px-2 py-0.5 text-white">Masa {table} · {view.deckCount} taş · Gösterge {view.indicator ? `${view.indicator.num}` : "?"} → Okey {view.okey ? `${view.okey.num}` : "?"}</span>
        <span className="muted">· 👁 {view.spectators.length} izleyici</span>
        <div className="ml-auto flex gap-1">
          {seated && view.phase !== "playing" && <button onClick={() => act("start")} className="btn-primary rounded-lg px-3 py-1.5">▶ Oyunu Başlat</button>}
          {seated && <button onClick={() => act("leave")} className="btn-ghost rounded-lg px-2 py-1">Masadan Kalk</button>}
          <button onClick={() => act("reset")} className="btn-ghost rounded-lg px-2 py-1">Sıfırla</button>
          <button onClick={() => act("destroy")} className="btn-danger rounded-lg px-2 py-1">Boz</button>
        </div>
      </div>

      <div className="felt relative rounded-[28px] p-4 text-white" style={{ minHeight: 520, backgroundImage: "radial-gradient(ellipse at center, #1f7a46 0%, #145c33 100%)" }}>
        {/* Top player */}
        <div className="absolute left-1/2 top-3 flex -translate-x-1/2 items-center gap-2">
          <PlayerBar seat={view.seats[topIdx] ?? null} idx={topIdx} view={view} isTurn={view.turn === topIdx} />
          <div className="flex flex-col items-center gap-1 rounded-full bg-orange-500 px-2 py-1 text-[10px] font-black text-white"><span>●</span><span>{view.discards[topIdx]?.length ?? 0}</span></div>
        </div>
        {/* Left player */}
        <div className="absolute left-3 top-1/2 flex -translate-y-1/2 flex-col items-center gap-2">
          <PlayerBar seat={view.seats[leftIdx] ?? null} idx={leftIdx} view={view} isTurn={view.turn === leftIdx} vertical />
          <div className="rounded-xl bg-black/60 px-2 py-1 text-xs font-black">{view.discards[leftIdx]?.length ?? 0} attı</div>
          {view.seats[leftIdx] ? view.discards[leftIdx]?.slice(-3).map((t,i) => <TileView key={i} t={t} okey={view.okey} tiny />) : null}
          {!seated && !view.seats[leftIdx] && view.phase !== "playing" && <button onClick={() => act("sit", { seat: leftIdx })} className="rounded-xl bg-white/20 px-3 py-1.5 text-xs font-black hover:bg-white/30">+ Otur</button>}
        </div>
        {/* Right player */}
        <div className="absolute right-3 top-1/2 flex -translate-y-1/2 flex-col items-center gap-2">
          <PlayerBar seat={view.seats[rightIdx] ?? null} idx={rightIdx} view={view} isTurn={view.turn === rightIdx} vertical />
          <div className="rounded-xl bg-black/60 px-2 py-1 text-xs font-black">{view.discards[rightIdx]?.length ?? 0} attı</div>
          {view.seats[rightIdx] ? view.discards[rightIdx]?.slice(-3).map((t,i) => <TileView key={i} t={t} okey={view.okey} tiny />) : null}
          {!seated && !view.seats[rightIdx] && view.phase !== "playing" && <button onClick={() => act("sit", { seat: rightIdx })} className="rounded-xl bg-white/20 px-3 py-1.5 text-xs font-black hover:bg-white/30">+ Otur</button>}
          {!seated && !view.seats[topIdx] && view.phase !== "playing" && <button onClick={() => act("sit", { seat: topIdx })} className="absolute -top-16 rounded-xl bg-white/20 px-3 py-1.5 text-xs font-black">+ Üste otur</button>}
        </div>

        {/* Center: indicator tiles + deck */}
        <div className="absolute left-1/2 top-[42%] flex -translate-x-1/2 -translate-y-1/2 items-center gap-4 rounded-2xl bg-black/30 p-3 backdrop-blur">
          <div className="flex flex-col items-center gap-1"><span className="text-[9px] font-black uppercase tracking-widest text-white/70">Gösterge</span><div className="flex gap-1">{view.indicator ? <TileView t={view.indicator} okey={null} /> : <div className="slot" />}<div className="flex h-12 w-[2px] bg-white/20" /></div></div>
          <div className="h-12 w-px bg-white/20" />
          <button disabled={!myTurn || my?.drawn} onClick={() => act("draw", { from: "middle" })} className="flex flex-col items-center gap-1 disabled:opacity-40 hover:scale-105 transition"><span className="text-[9px] font-black uppercase tracking-widest text-white/70">Ortadan Çek</span><div className="relative"><div className="tile back" /><div className="tile back absolute -left-1 -top-1" /><span className="absolute -bottom-1 -right-1 rounded-full bg-amber-400 px-1.5 text-[10px] font-black text-black">{view.deckCount}</span></div></button>
          {leftSeat >=0 && view.discards[leftSeat]?.length >0 && (
            <button disabled={!myTurn || my?.drawn} onClick={() => act("draw", { from: "left" })} className="flex flex-col items-center gap-1 disabled:opacity-40"><span className="text-[9px] font-black uppercase tracking-widest text-white/70">Soldan Al</span><TileView t={view.discards[leftSeat][view.discards[leftSeat].length -1]} okey={view.okey} /></button>
          )}
          <div className="flex gap-1">{view.discards[mySeat]?.slice(-2).map((t,i) => <TileView key={i} t={t} okey={view.okey} small />)}</div>
        </div>

        {view.phase === "finished" && view.winner && <div className="pop-in absolute left-1/2 top-[28%] flex -translate-x-1/2 flex-col items-center gap-1 rounded-2xl bg-black/80 px-6 py-3 text-center shadow-xl"><div className="text-3xl">🏆</div><div className="font-black text-amber-300">{view.winner.username} {view.winner.pairs ? "ÇİFTLE " : ""}BİTTİ!</div><div className="text-xs text-white/80">+{view.winner.pairs ? 50 : 25} puan</div></div>}

        {/* Bottom info */}
        {my && <div className={`absolute bottom-[148px] left-1/2 -translate-x-1/2 rounded-full px-4 py-1 text-xs font-black shadow ${myTurn ? "bg-amber-400 text-black animate-pulse" : "bg-black/60 text-white"}`}>{myTurn ? (my.drawn ? "Taş at veya bitir" : "Sıra sende — çek") : view.phase === "playing" ? `${view.seats[view.turn]?.username ?? ""} oynuyor...` : "Başlatmayı bekle"}</div>}
        {!seated && !view.seats[order[0]] && view.phase !== "playing" && <button onClick={() => act("sit", { seat: order[0] })} className="absolute bottom-[150px] left-1/2 -translate-x-1/2 rounded-xl bg-white px-4 py-2 text-sm font-black text-black shadow">+ Masaya Otur</button>}
      </div>

      {/* Wooden istaka — exactly like image */}
      {my && (
        <div className="wood relative mt-3 rounded-2xl p-3 shadow-xl">
          <div className="absolute -left-2 top-1/2 h-20 w-2 -translate-y-1/2 rounded-full bg-[#3d2410]" />
          <div className="absolute -right-2 top-1/2 h-20 w-2 -translate-y-1/2 rounded-full bg-[#3d2410]" />
          <div className="mb-1 flex items-center gap-2 text-[11px] font-black text-amber-100"><span>Istaka</span><span className="rounded bg-black/30 px-1.5 text-amber-200">Sürükle-bırak · boşluk = grup sınırı</span><div className="ml-auto flex gap-1"><button onClick={() => act("auto", { mode: "seri" })} className="rounded-lg bg-black/40 px-2 py-1 hover:bg-black/60">Seri Diz</button><button onClick={() => act("auto", { mode: "cift" })} className="rounded-lg bg-black/40 px-2 py-1 hover:bg-black/60">Çift Diz</button>{myTurn && my.drawn && sel && <button onClick={() => act("discard", { tileId: sel })} className="rounded-lg bg-amber-400 px-3 py-1 font-black text-black">At</button>}{myTurn && my.drawn && sel && <button onClick={() => act("finish", { tileId: sel })} className="rounded-lg bg-emerald-500 px-3 py-1 font-black text-white">BİTİR 🏆</button>}</div></div>
          {[0,1].map((row) => (
            <div key={row} className="flex justify-center gap-[2px]">
              {Array.from({ length: 13 }).map((_, i) => {
                const idx = row*13 + i;
                const t = my.rack[idx];
                return (
                  <div key={idx} className={`slot ${over===idx ? "over" : ""}`} onDragOver={(e)=>{e.preventDefault(); setOver(idx);}} onDragLeave={()=>setOver(null)} onDrop={(e)=>{e.preventDefault(); setOver(null); const from=Number(e.dataTransfer.getData("text/plain")); if(!Number.isNaN(from)&&from!==idx) moveTile(from,idx);}}>
                    {t && <TileView t={t} okey={view.okey} selected={sel===t.id} draggable onDragStart={(e)=>e.dataTransfer.setData("text/plain", String(idx))} onClick={()=>{ if(sel===t.id && myTurn && my.drawn) act("discard",{tileId:t.id}); else setSel(t.id); }} />}
                  </div>
                );
              })}
            </div>
          ))}
          <div className="mt-2 flex items-center justify-between text-[10px] font-bold text-amber-100/70"><span>Seçili taşa bir kez daha tıkla = at. 14 taşla tüm gruplar doğruysa Bitir.</span><span className="rounded bg-black/30 px-2 py-0.5">{my.rack.filter(Boolean).length}/15 taş</span></div>
        </div>
      )}

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <div className="card rounded-2xl p-3"><div className="label mt-0">Salon sohbeti</div><div className="scroll-thin max-h-28 space-y-1 overflow-y-auto text-xs">{view.chat.map((c,i)=><div key={i}><b>{c.user}:</b> {c.text}</div>)}{view.chat.length===0 && <div className="muted">Henüz mesaj yok</div>}</div><form onSubmit={(e)=>{e.preventDefault(); if(chat.trim()){act("chat",{text:chat}); setChat("");}}} className="mt-2 flex gap-1"><input value={chat} onChange={(e)=>setChat(e.target.value)} className="input flex-1 rounded-lg px-2 py-1.5 text-xs" placeholder="Masaya yaz…" /><button className="btn-primary rounded-lg px-3 text-xs font-extrabold">Gönder</button></form></div>
        <div className="card rounded-2xl p-3"><div className="label mt-0">Oyun kaydı</div><div className="scroll-thin max-h-32 space-y-0.5 overflow-y-auto text-xs muted">{view.log.slice().reverse().map((l,i)=><div key={i}>• {l}</div>)}</div></div>
      </div>
    </div>
  );
}
