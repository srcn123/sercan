"use client";
import { useEffect, useRef, useState } from "react";
import { AchBadge, Avatar, GiftIcon, LevelRing, Modal, RankBadge, SectionLabel, duration, fileToDataUrl, memberSince } from "../ui";
import { AVATAR_COLORS, AVATAR_FRAMES, EMOJIS, GIFTS, MUTE_DURATIONS, NICK_EFFECTS, PERM, RADIO_STATIONS, RANKS, RANK_ORDER, THEMES, countryFlag, levelFromXp, rankInfo, rankLevel, type RankKey } from "@/lib/constants";
import { getSoundSettings, saveSoundSettings, SOUND_CATEGORIES, SOUND_PRESETS, testSound, type SoundCategory, type SoundSettings } from "@/lib/sounds";
import type { PublicUser } from "@/lib/auth";

const PREF_LABEL: Record<string, string> = { everyone: "Herkes", friends: "Dostlarım", nobody: "Hiçkimse" };

export type Notify = (m: string) => void;
type ProfileData = { user: PublicUser & { lastSeen: string; isBanned: boolean }; gifts: { giftKey: string; from: string | null; createdAt: string }[]; achievements: { key: string }[]; friendCount: number; relation: { id: number; status: string; incoming: boolean } | null };

/* ---------------- KÜNYE — premium vitrin ---------------- */
export function ProfileCard({ userId, me, roomId, onClose, onDm, onCall, notify, refreshMe }: { userId: number; me: PublicUser; roomId: number | null; onClose: () => void; onDm: (u: { id: number; username: string; color: string; rank: string; avatarUrl?: string | null }) => void; onCall: (id: number) => void; notify: Notify; refreshMe: () => void }) {
  const [data, setData] = useState<ProfileData | null>(null);
  const [friends, setFriends] = useState<{ user: { id: number; username: string; color: string; avatarUrl: string | null } }[]>([]);
  const [tab, setTab] = useState<"ozet" | "hediye" | "dost" | "yonet">("ozet");
  const [bigAvatar, setBigAvatar] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const load = async () => {
    const r = await fetch(`/api/profile/${userId}`, { cache: "no-store" });
    if (r.ok) setData(await r.json());
    const f = await fetch(`/api/friends?user=${userId}`, { cache: "no-store" });
    if (f.ok) setFriends((await f.json()).friends.filter((x: { status: string }) => x.status === "accepted"));
  };
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [userId]);
  if (!data) return <Modal onClose={onClose}><div className="py-10 text-center text-sm font-bold muted">Künye yükleniyor…</div></Modal>;
  const u = data.user;
  const isMe = u.id === me.id;
  const myLevel = rankLevel(me.rank), tLevel = rankLevel(u.rank);
  const canMod = !isMe && tLevel < myLevel && myLevel >= PERM.mute;
  const xp = u.xp, lvl = levelFromXp(xp);
  const nextXp = (lvl * lvl) * 100, curXp = ((lvl-1)*(lvl-1))*100;
  const pct = Math.min(100, Math.round(((xp - curXp) / Math.max(1, nextXp - curXp)) * 100));
  async function mod(action: string, extra: Record<string, unknown> = {}) {
    const r = await fetch("/api/moderation", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, userId: u.id, roomId, ...extra }) });
    const d = await r.json();
    notify(r.ok ? "İşlem tamam ✓" : d.error);
    if (r.ok) { load(); refreshMe(); }
  }
  async function friend(action: string) {
    const r = await fetch("/api/friends", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, userId: u.id, id: data?.relation?.id }) });
    const d = await r.json();
    notify(r.ok ? (d.accepted ? "Arkadaş oldunuz! 🤝" : action === "request" ? "İstek gönderildi" : "Tamam ✓") : d.error);
    load();
  }
  const style = u.textStyle ?? {};
  const stats: [string, string|number, string][] = [["💬", u.totalMessages, "mesaj"], ["🤝", data.friendCount, "dost"], ["🎁", u.giftsReceived, "hediye"], ["⏱", duration(u.onlineSeconds), "süre"], ["⭐", lvl, "seviye"], ["💰", u.points, "puan"]];
  return (
    <Modal onClose={onClose} wide>
      {bigAvatar && <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-6" onClick={() => setBigAvatar(false)}>{u.avatarUrl ? <img src={u.avatarUrl} alt={u.username} className="max-h-[80vh] max-w-full rounded-3xl object-contain" /> : <div className="flex h-64 w-64 items-center justify-center rounded-full text-9xl font-black text-white" style={{ background: u.color }}>{u.username[0]}</div>}</div>}
      {giftOpen && <GiftModal me={me} to={u} roomId={roomId} onClose={() => setGiftOpen(false)} notify={notify} onSent={() => { load(); refreshMe(); }} />}
      <div className="-m-5 sm:-m-6">
        {/* banner — kompakt, pencereye sığar */}
        <div className="relative h-28 overflow-hidden rounded-t-3xl" style={{ background: u.bannerUrl ? `url(${u.bannerUrl}) center/cover` : `linear-gradient(135deg, ${u.color} 0%, color-mix(in srgb, ${u.color} 55%, white) 100%)` }}>
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          <button onClick={onClose} className="absolute right-3 top-3 rounded-full bg-black/50 px-2.5 py-1 text-xs font-extrabold text-white backdrop-blur">✕</button>
          <div className="absolute left-3 top-3 flex gap-1.5 flex-wrap">
            {u.presence !== "online" && <span className="rounded-full bg-black/50 px-2 py-0.5 text-[10px] font-extrabold text-white backdrop-blur">{u.presence === "busy" ? "⛔ Meşgul" : "🌙 Uzakta"}</span>}
            {u.isVerified && <span className="rounded-full bg-sky-500 px-2 py-0.5 text-[10px] font-black text-white">✓ Doğrulandı</span>}
            {(u as unknown as { gender?: string }).gender === "kadin" ? <span className="rounded-full bg-pink-500 px-2 py-0.5 text-[10px] font-black text-white">♀ Kadın</span> : (u as unknown as { gender?: string }).gender === "erkek" ? <span className="rounded-full bg-blue-500 px-2 py-0.5 text-[10px] font-black text-white">♂ Erkek</span> : null}
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1" style={{ background: "rgba(255,255,255,.25)" }}><div className="h-full brand-gradient" style={{ width: `${pct}%` }} /></div>
        </div>
        <div className="px-4 pb-5 sm:px-6">
          {/* avatar + name — tamamen görünür, temanın üstünde değil */}
          <div className="relative -mt-10 flex flex-col gap-3 rounded-2xl bg-white p-3 shadow-lg sm:flex-row sm:items-center" style={{ border: `1.5px solid ${u.nickColor || u.color}15` }}>
            <button onClick={() => setBigAvatar(true)} className="relative shrink-0 self-start rounded-full ring-[3px] shadow-md sm:self-center" style={{ ["--tw-ring-color" as string]: "var(--surface)" }}>
              <Avatar name={u.username} color={u.color} url={u.avatarUrl} size={64} presence={u.presence} verified={false} ring frame={(u as unknown as { avatarFrame?: string }).avatarFrame} />
              <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-black text-white shadow" style={{ background: "var(--brand)" }}>{lvl}</div>
              {u.isVerified && <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-sky-500 text-[10px] text-white">✓</span>}
            </button>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`break-all text-lg font-black leading-tight tracking-tight sm:text-xl ${(u as unknown as { nickEffect?: string }).nickEffect === "neon" ? "nick-neon" : (u as unknown as { nickEffect?: string }).nickEffect === "glow-pulse" ? "nick-glow-pulse" : (u as unknown as { nickEffect?: string }).nickEffect === "rainbow-anim" ? "nick-rainbow" : ""}`} style={{ color: u.nickColor || u.color, overflowWrap: "anywhere", wordBreak: "break-word", textShadow: (u as unknown as { nickEffect?: string }).nickEffect === "neon" ? `0 0 8px ${u.nickColor || u.color}` : undefined }}>{u.username}</span>
                <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-black shadow-sm" style={{ background: `linear-gradient(135deg, ${rankInfo(u.rank).color}15, white)`, color: rankInfo(u.rank).color, border: `1px solid ${rankInfo(u.rank).color}25`, boxShadow: `0 2px 8px ${rankInfo(u.rank).color}20` }}><span className="rank-sprite" style={{ width: 16, height: 16, backgroundPosition: `${(rankInfo(u.rank).sprite / 6) * 100}% 0` }} />{rankInfo(u.rank).label}</span>
                {u.isDj && <span className="shrink-0 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-800 shadow">🎧 DJ</span>}
                {u.isBot && <span className="shrink-0 rounded-full bg-purple-100 px-2 py-0.5 text-[10px] font-extrabold text-purple-800 shadow">🤖 Bot</span>}
              </div>
              <div className="mt-1 flex flex-wrap gap-x-3 text-xs font-bold muted">
                {(u.city || u.country) && <span>📍 {countryFlag(u.country)} {[u.city, u.country].filter(Boolean).join(", ")}</span>}
                {u.mood && <span>💭 {u.mood}</span>}
                <span>🗓 {memberSince(u.createdAt)}</span>
                <span>· Seviye {lvl} · {xp} XP</span>
              </div>
              <div className="mt-1.5 h-1.5 w-full max-w-[220px] overflow-hidden rounded-full" style={{ background: "var(--border)" }}><div className="h-full brand-gradient" style={{ width: `${pct}%` }} /></div>
            </div>
          </div>
          {/* about / status bubble */}
          {(u.about || u.status) && <div className="soft mt-4 rounded-2xl p-3">
            {u.status && <div className="text-sm font-extrabold" style={{ color: "var(--brand)" }}>“{u.status}”</div>}
            {u.about && <p className="mt-1 text-sm leading-relaxed" style={{ color: style.color, fontWeight: style.bold ? 800 : 500, fontStyle: style.italic ? "italic" : undefined }}>{u.about}</p>}
          </div>}

          {/* stats grid — 6 items */}
          <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {stats.map(([i, v, l]) => <div key={String(l)} className="soft flex flex-col items-center rounded-2xl p-2.5 text-center"><div className="text-base">{i}</div><div className="text-sm font-black">{v}</div><div className="text-[10px] font-bold uppercase tracking-wider muted">{l}</div></div>)}
          </div>

          {!isMe && (
            <div className="mt-4 flex flex-wrap gap-2">
              <button onClick={() => onDm(u)} className="btn-primary flex-1 rounded-2xl py-2.5 text-sm font-extrabold">💬 Özel mesaj</button>
              <button onClick={() => setGiftOpen(true)} className="soft rounded-2xl px-4 py-2.5 text-sm font-extrabold">🎁 Hediye Gönder</button>
              {!u.isBot && <button onClick={() => onCall(u.id)} className="soft rounded-2xl px-3 py-2.5 text-sm font-extrabold">📹 Ara</button>}
              {!data.relation && <button onClick={() => friend("request")} className="btn-ghost rounded-2xl px-4 py-2.5 text-sm font-extrabold">➕ Takip Et</button>}
              {data.relation?.status === "pending" && data.relation.incoming && <><button onClick={() => friend("accept")} className="btn-primary rounded-2xl px-4 py-2.5 text-sm font-extrabold">✓ Kabul</button><button onClick={() => friend("reject")} className="btn-danger rounded-2xl px-4 py-2.5 text-sm font-extrabold">✕ Reddet</button></>}
              {data.relation?.status === "pending" && !data.relation.incoming && <span className="soft rounded-2xl px-4 py-2.5 text-xs font-bold muted">İstek gönderildi…</span>}
              {data.relation?.status === "accepted" && <button onClick={() => friend("remove")} className="soft rounded-2xl px-4 py-2.5 text-sm font-extrabold">💔 Takibi bırak</button>}
            </div>
          )}

          <div className="soft mt-4 flex rounded-2xl p-1 text-xs font-extrabold">
            {(["ozet", "hediye", "dost", ...(canMod ? ["yonet"] : [])] as const).map((t) => <button key={t} onClick={() => setTab(t as typeof tab)} className={`flex-1 rounded-xl py-2 ${tab === t ? "brand-gradient text-white shadow" : "muted"}`}>{t === "ozet" ? "✨ Vitrin" : t === "hediye" ? `🎁 Hediyeler · ${data.gifts.length}` : t === "dost" ? `👥 Dostlar · ${friends.length}` : "🛡 Yönet"}</button>)}
          </div>
          <div className="mt-3 min-h-[96px]">
            {tab === "ozet" && <div>{data.achievements.length ? <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">{data.achievements.map((a) => <div key={a.key} className="soft flex items-center gap-2 rounded-xl px-3 py-2"><AchBadge k={a.key} /><span className="ml-auto text-[10px] font-bold muted">{new Date((a as unknown as { earnedAt: string }).earnedAt ?? Date.now()).toLocaleDateString("tr-TR")}</span></div>)}</div> : <div className="soft rounded-2xl p-6 text-center"><div className="text-2xl">🌟</div><div className="mt-1 text-sm font-extrabold">Henüz vitrin boş</div><div className="text-xs muted">Mesaj yaz, hediye gönder, okey oyna — başarımlar burada birikir.</div></div>}</div>}
            {tab === "hediye" && <div>{data.gifts.length ? <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">{data.gifts.map((g, i) => <div key={i} className="soft flex flex-col items-center rounded-2xl p-2 text-center transition hover:scale-105"><GiftIcon giftKey={g.giftKey} size={48} /><div className="mt-1 w-full truncate text-[10px] font-bold">{g.from ?? "?"}</div><div className="text-[9px] muted">{new Date(g.createdAt).toLocaleDateString("tr-TR")}</div></div>)}</div> : <div className="soft rounded-2xl p-6 text-center"><div className="text-2xl">🎁</div><div className="text-sm font-extrabold">Henüz hediye yok</div><div className="text-xs muted">İlk hediyeyi sen gönder — tüm odada duyurulur!</div><button onClick={() => setGiftOpen(true)} className="btn-primary mt-3 rounded-xl px-4 py-2 text-xs font-extrabold">Hediye Gönder</button></div>}</div>}
            {tab === "dost" && <div>{friends.length ? <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">{friends.map((f) => <div key={f.user.id} className="soft flex items-center gap-2 rounded-xl px-3 py-2"><Avatar name={f.user.username} color={f.user.color} url={f.user.avatarUrl} size={28} /><div className="min-w-0 flex-1"><div className="truncate text-xs font-extrabold" style={{ color: f.user.color }}>{f.user.username}</div><div className="text-[10px] muted">Lv {levelFromXp(0)}</div></div></div>)}</div> : <div className="soft rounded-2xl p-6 text-center text-xs muted">Henüz dostu yok. Arkadaş ekle ve sohbeti renklendir.</div>}</div>}
            {tab === "yonet" && canMod && (
              <div className="space-y-3">
                <div><div className="label">Rütbe ver — yalnızca senden düşük</div><div className="flex flex-wrap gap-1.5">{RANK_ORDER.filter((rk) => RANKS[rk].level < myLevel && rk !== u.rank).map((rk) => <button key={rk} onClick={() => mod("rank", { rank: rk })} className="rounded-xl px-2.5 py-1.5 text-xs font-extrabold shadow-sm" style={{ background: `color-mix(in srgb, ${RANKS[rk].color} 16%, transparent)`, color: RANKS[rk].color, border: `1px solid ${RANKS[rk].color}30` }}>{RANKS[rk].icon} {RANKS[rk].label}</button>)}</div></div>
                <div><div className="label">Sustur</div><div className="flex flex-wrap gap-1.5">{MUTE_DURATIONS.map((d) => <button key={d.minutes} onClick={() => mod("mute", { minutes: d.minutes })} className="btn-ghost rounded-xl px-2.5 py-1.5 text-xs font-extrabold">🔇 {d.label}</button>)}{u.mutedUntil && <button onClick={() => mod("unmute")} className="btn-ghost rounded-xl px-2.5 py-1.5 text-xs font-extrabold">🔊 Kaldır</button>}</div></div>
                <div className="flex flex-wrap gap-1.5">
                  {myLevel >= PERM.kick && <button onClick={() => mod("kick")} className="btn-danger rounded-xl px-3 py-1.5 text-xs font-extrabold">👢 Odadan at</button>}
                  {myLevel >= PERM.ban && !u.isBanned && <button onClick={() => mod("ban", { withIp: true })} className="btn-danger rounded-xl px-3 py-1.5 text-xs font-extrabold">🚫 Yasakla (IP ile)</button>}
                  {myLevel >= PERM.ban && u.isBanned && <button onClick={() => mod("unban")} className="btn-ghost rounded-xl px-3 py-1.5 text-xs font-extrabold">Yasağı kaldır</button>}
                  {me.rank === "kurucu" && <button onClick={() => mod("dj", { value: !u.isDj })} className="btn-ghost rounded-xl px-3 py-1.5 text-xs font-extrabold">{u.isDj ? "🎧 DJ al" : "🎧 DJ yap"}</button>}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- HEDİYE ---------------- */
export function GiftModal({ me, to, roomId, onClose, notify, onSent }: { me: PublicUser; to: { id: number; username: string }; roomId: number | null; onClose: () => void; notify: Notify; onSent: () => void }) {
  const [busy, setBusy] = useState<string | null>(null);
  async function send(key: string) {
    setBusy(key);
    const r = await fetch("/api/gifts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ giftKey: key, toUserId: to.id, roomId }) });
    const d = await r.json();
    setBusy(null);
    if (!r.ok) { notify(d.error); return; }
    const gift = d.gift ?? { name: key, emoji: "🎁" };
    notify(`${gift.emoji} ${gift.name} → ${to.username} gönderildi! Kısa süre sonra kaybolacak`);
    onSent(); onClose();
  }
  return (
    <Modal onClose={onClose}>
      <div className="text-lg font-black">🎁 {to.username} için hediye</div>
      <div className="text-xs muted">Puanın: <b style={{ color: "var(--brand)" }}>{me.points}</b> · Alıcı puanın yarısını kazanır, hediye odada duyurulur.</div>
      <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
        {GIFTS.map((g) => (
          <button key={g.key} disabled={!!busy || me.points < g.points} onClick={() => send(g.key)} className="soft flex flex-col items-center rounded-2xl p-2 transition hover:scale-105 disabled:opacity-40">
            <GiftIcon giftKey={g.key} size={56} />
            <div className="mt-1 text-xs font-extrabold">{g.name}</div>
            <div className="text-[10px] font-bold" style={{ color: "var(--brand)" }}>{g.points} puan</div>
          </button>
        ))}
      </div>
    </Modal>
  );
}

/* ---------------- ÇARK ---------------- */
const WHEEL_LABELS = ["10", "25", "Pas", "50", "VIP", "100", "🎰", "250"];
export function WheelModal({ onClose, notify, refreshMe }: { onClose: () => void; notify: Notify; refreshMe: () => void }) {
  const [rot, setRot] = useState(0);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  async function spin() {
    setBusy(true); setResult(null);
    const r = await fetch("/api/wheel", { method: "POST" });
    const d = await r.json();
    if (!r.ok) { notify(d.error); setBusy(false); return; }
    const target = 360 * 5 + (360 - (d.index * 45 + 22.5));
    setRot((p) => p + target - (p % 360));
    setTimeout(() => { setResult(d.prize.label); setBusy(false); refreshMe(); }, 4200);
  }
  return (
    <Modal onClose={onClose}>
      <div className="text-center text-lg font-black">🎡 Günlük Şans Çarkı</div>
      <div className="text-center text-xs muted">Günde bir kez ücretsiz çevir; puan, VIP deneme veya özel emoji kazan.</div>
      <div className="relative mx-auto mt-5 w-[260px]">
        <div className="absolute -top-3 left-1/2 z-10 -translate-x-1/2 text-2xl">🔻</div>
        <div className="wheel" style={{ transform: `rotate(${rot}deg)` }}>
          {WHEEL_LABELS.map((l, i) => <div key={i} className="wheel-label" style={{ transform: `rotate(${i * 45 + 22.5 - 90}deg) translate(70px, -6px)` }}>{l}</div>)}
        </div>
      </div>
      {result && <div className="pop-in mt-4 rounded-2xl p-3 text-center text-sm font-black" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>🎉 Kazandın: {result}</div>}
      <button disabled={busy} onClick={spin} className="btn-primary mt-4 w-full rounded-2xl py-3 text-sm font-extrabold">{busy ? "Dönüyor…" : "Çevir!"}</button>
    </Modal>
  );
}

/* ---------------- LİDERLİK ---------------- */
type LRow = { id: number; username: string; color: string; avatarUrl: string | null; rank: string; value: string | number };
export function LeaderboardModal({ onClose }: { onClose: () => void }) {
  const [period, setPeriod] = useState<"week" | "month">("week");
  const [d, setD] = useState<{ points: LRow[]; gifts: LRow[]; online: LRow[]; alltime: LRow[]; analytics: { hourly: { hour: number; value: string }[]; giftCountries: { country: string; value: number }[] } } | null>(null);
  const [tab, setTab] = useState<"points" | "gifts" | "online" | "alltime" | "analiz">("points");
  useEffect(() => { fetch(`/api/leaderboard?period=${period}`, { cache: "no-store" }).then((r) => r.json()).then(setD); }, [period]);
  const rows = d && tab !== "analiz" ? d[tab] : [];
  const maxH = d ? Math.max(1, ...d.analytics.hourly.map((h) => Number(h.value))) : 1;
  return (
    <Modal onClose={onClose} wide>
      <div className="flex flex-wrap items-center gap-2"><div className="text-lg font-black">🏆 Liderlik Tabloları</div><div className="soft ml-auto flex rounded-xl p-0.5 text-xs font-extrabold"><button onClick={() => setPeriod("week")} className={`rounded-lg px-3 py-1 ${period === "week" ? "brand-gradient text-white" : "muted"}`}>Haftalık</button><button onClick={() => setPeriod("month")} className={`rounded-lg px-3 py-1 ${period === "month" ? "brand-gradient text-white" : "muted"}`}>Aylık</button></div></div>
      <div className="soft mt-3 flex flex-wrap rounded-2xl p-1 text-xs font-extrabold">{([["points", "En Çok Puan"], ["gifts", "Hediye Kralları"], ["online", "En Uzun Çevrimiçi"], ["alltime", "Tüm Zamanlar"], ["analiz", "📊 Analizim"]] as const).map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`flex-1 rounded-xl px-2 py-2 ${tab === k ? "brand-gradient text-white" : "muted"}`}>{l}</button>)}</div>
      {tab !== "analiz" ? (
        <div className="mt-3 space-y-1">{rows.map((r, i) => <div key={r.id} className="soft flex items-center gap-3 rounded-xl px-3 py-2"><span className="w-6 text-center text-sm font-black">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : i + 1}</span><Avatar name={r.username} color={r.color} url={r.avatarUrl} size={28} /><span className="flex-1 truncate text-sm font-extrabold" style={{ color: r.color }}>{r.username}</span><RankBadge rank={r.rank} compact /><span className="text-sm font-black" style={{ color: "var(--brand)" }}>{Number(r.value).toLocaleString("tr-TR")}{tab === "online" ? " dk" : ""}</span></div>)}{rows.length === 0 && <div className="py-6 text-center text-xs muted">Henüz veri yok.</div>}</div>
      ) : d && (
        <div className="mt-3 space-y-4">
          <div><div className="label">Saatlere göre kazandığın puan</div><div className="flex h-28 items-end gap-[2px]">{Array.from({ length: 24 }).map((_, h) => { const v = Number(d.analytics.hourly.find((x) => x.hour === h)?.value ?? 0); return <div key={h} className="flex flex-1 flex-col items-center justify-end gap-0.5" title={`${h}:00 — ${v} puan`}><div className="w-full rounded-t brand-gradient" style={{ height: `${(v / maxH) * 100}%`, minHeight: v ? 3 : 0 }} /><span className="text-[8px] muted">{h % 6 === 0 ? h : ""}</span></div>; })}</div></div>
          <div><div className="label">Hediye gönderenlerin ülkeleri</div><div className="flex flex-wrap gap-2">{d.analytics.giftCountries.map((c) => <span key={c.country || "?"} className="soft rounded-xl px-3 py-1 text-xs font-bold">{c.country || "Belirtilmemiş"} · {c.value}</span>)}{d.analytics.giftCountries.length === 0 && <span className="text-xs muted">Henüz hediye almadın.</span>}</div></div>
        </div>
      )}
    </Modal>
  );
}

/* ---------------- MEYDAN OKUMA ---------------- */
type Ch = { id: number; creatorId: number; creatorName: string; title: string; target: number; progress: number; endsAt: string };
export function ChallengesModal({ me, onClose, notify, refreshMe }: { me: PublicUser; onClose: () => void; notify: Notify; refreshMe: () => void }) {
  const [list, setList] = useState<Ch[]>([]);
  const [target, setTarget] = useState(1000);
  const [minutes, setMinutes] = useState(10);
  const load = () => fetch("/api/challenges", { cache: "no-store" }).then((r) => r.json()).then((d) => setList(d.challenges ?? []));
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, []);
  async function post(body: Record<string, unknown>) { const r = await fetch("/api/challenges", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const d = await r.json(); if (!r.ok) notify(d.error); else { notify("✓"); load(); refreshMe(); } }
  return (
    <Modal onClose={onClose}>
      <div className="text-lg font-black">🏁 Topluluk Meydan Okumaları</div>
      <div className="soft mt-3 rounded-2xl p-3"><div className="label mt-0">Yeni meydan okuma</div><div className="flex gap-2"><input type="number" value={target} onChange={(e) => setTarget(Number(e.target.value))} className="input w-24 rounded-xl px-3 py-2 text-sm" /><span className="self-center text-xs muted">puan /</span><input type="number" value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} className="input w-20 rounded-xl px-3 py-2 text-sm" /><span className="self-center text-xs muted">dk</span><button onClick={() => post({ action: "create", target, minutes })} className="btn-primary ml-auto rounded-xl px-3 text-xs font-extrabold">Başlat</button></div></div>
      <div className="mt-3 space-y-2">{list.map((c) => { const left = Math.max(0, Math.round((new Date(c.endsAt).getTime() - Date.now()) / 60000)); const p = Math.min(100, Math.round((c.progress / c.target) * 100)); return <div key={c.id} className="card rounded-2xl p-3"><div className="flex items-center justify-between text-sm font-extrabold"><span>{c.title}</span><span className="text-xs muted">{left ? `${left} dk kaldı` : "bitti"}</span></div><div className="text-[11px] muted">{c.creatorName} · {c.progress}/{c.target} puan</div><div className="mt-2 h-2 overflow-hidden rounded-full" style={{ background: "var(--border)" }}><div className="h-full brand-gradient" style={{ width: `${p}%` }} /></div>{c.creatorId !== me.id && left > 0 && <div className="mt-2 flex gap-1">{[10, 50, 100].map((a) => <button key={a} onClick={() => post({ action: "support", id: c.id, amount: a })} className="btn-ghost rounded-lg px-2 py-1 text-[11px] font-extrabold">+{a}</button>)}</div>}</div>; })}{list.length === 0 && <div className="py-6 text-center text-xs muted">Aktif meydan okuma yok.</div>}</div>
    </Modal>
  );
}

/* ---------------- DJ ---------------- */
type Req = { id: number; username: string; title: string; artist: string; artwork: string | null; previewUrl: string | null; status: string };
export function DjPanel({ onClose, notify, isDj, nowPlaying, onCloseSong }: { onClose: () => void; notify: Notify; isDj: boolean; nowPlaying?: { title: string; artist: string; youtubeId?: string; previewUrl?: string; artwork?: string; djName?: string } | null; onCloseSong?: () => void }) {
  const [reqs, setReqs] = useState<Req[]>([]);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ title: string; artist: string; youtubeId: string; artwork?: string; duration?: string }[]>([]);
  const [searching, setSearching] = useState(false);
  const load = () => fetch("/api/dj/requests", { cache: "no-store" }).then((r) => r.json()).then((d) => setReqs(d.requests ?? []));
  useEffect(() => { load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, []);
  async function act(body: Record<string, unknown>, url = "/api/dj/requests") { const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const d = await r.json(); notify(r.ok ? "✓" : d.error); load(); }
  async function searchMusic() {
    if (!q.trim()) return;
    setSearching(true);
    const r = await fetch(`/api/music/search?q=${encodeURIComponent(q)}`, { cache: "no-store" });
    setSearching(false);
    if (r.ok) setResults((await r.json()).results ?? []);
    else notify("Arama başarısız");
  }
  async function playTrack(t: { title: string; artist: string; youtubeId?: string; artwork?: string; previewUrl?: string }) {
    const r = await fetch("/api/dj/play", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ track: t }) });
    const d = await r.json().catch(() => ({}));
    notify(r.ok ? "🎧 Çalmaya başladı" : d.error);
  }
  return (
    <Modal onClose={onClose} wide>
      <div className="flex items-center justify-between"><div className="text-lg font-black">🎧 {isDj ? "DJ Paneli — Tam Şarkı Yayını" : "Şarkı İste"}</div>{isDj && nowPlaying && <button onClick={onCloseSong} className="btn-danger rounded-xl px-3 py-1 text-xs font-extrabold">✕ Yayını kapat</button>}</div>
      {isDj && nowPlaying && <div className="soft mt-2 flex items-center gap-3 rounded-2xl p-3"><div className={`flex h-10 w-10 items-center justify-center rounded-xl text-white ${nowPlaying.youtubeId ? "bg-red-500" : "brand-gradient"}`}>{nowPlaying.youtubeId ? "▶" : "🎧"}</div><div className="min-w-0 flex-1"><div className="truncate text-sm font-black">{nowPlaying.title} — {nowPlaying.artist}</div><div className="text-[11px] muted">DJ {nowPlaying.djName} · {nowPlaying.youtubeId ? "YouTube tam sürüm" : "önizleme"}</div></div>{nowPlaying.youtubeId && <a href={`https://youtu.be/${nowPlaying.youtubeId}`} target="_blank" rel="noreferrer" className="btn-ghost rounded-xl px-3 py-1 text-xs font-bold">YouTube'da aç</a>}</div>}
      <div className="mt-3 flex gap-2"><input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), isDj ? searchMusic() : act({ action: "request", query: q }))} className="input flex-1 rounded-xl px-3 py-2 text-sm" placeholder={isDj ? "Ara: sanatçı - parça (YouTube tam sürüm)" : "İstek: sanatçı - parça"} /><button onClick={() => isDj ? searchMusic() : act({ action: "request", query: q })} className="btn-primary rounded-xl px-4 text-xs font-extrabold">{searching ? "…" : isDj ? "Ara" : "İste"}</button></div>
      {isDj && results.length > 0 && <div className="mt-3"><div className="label">YouTube sonuçları — tam şarkı</div><div className="space-y-1">{results.slice(0, 8).map((t, i) => <div key={i} className="soft flex items-center gap-2 rounded-xl p-2"><img src={t.artwork ?? `https://img.youtube.com/vi/${t.youtubeId}/mqdefault.jpg`} alt="" className="h-10 w-10 rounded-lg object-cover" /><div className="min-w-0 flex-1"><div className="truncate text-xs font-extrabold">{t.title}</div><div className="truncate text-[10px] muted">{t.artist} {t.duration && `· ${t.duration}`}</div></div><button onClick={() => playTrack(t)} className="brand-gradient rounded-xl px-3 py-1 text-xs font-extrabold text-white">▶ Çal</button><button onClick={() => act({ action: "request", query: `${t.artist} ${t.title}` })} className="btn-ghost rounded-xl px-2 py-1 text-xs">İstek olarak ekle</button></div>)}</div></div>}
      <div className="label">İstek kutusu — onayla / reddet / sil</div>
      <div className="space-y-1.5">{reqs.map((r) => <div key={r.id} className="soft flex items-center gap-2 rounded-xl p-2">{r.artwork ? <img src={r.artwork} alt="" className="h-9 w-9 rounded-lg object-cover" /> : <div className="flex h-9 w-9 items-center justify-center rounded-lg brand-gradient text-white">♪</div>}<div className="min-w-0 flex-1"><div className="truncate text-xs font-extrabold">{r.title}</div><div className="truncate text-[10px] muted">{r.artist} · {r.username} · {r.status === "pending" ? "🕒 bekliyor — okunmadı" : r.status === "approved" ? "✅ onaylandı" : "❌ reddedildi"}</div></div>{isDj ? <div className="flex gap-1"><button onClick={() => playTrack({ title: r.title, artist: r.artist, previewUrl: r.previewUrl ?? undefined, artwork: r.artwork ?? undefined })} className="rounded-lg px-2 py-1 text-[11px] font-extrabold brand-gradient text-white" title="Çal">▶</button><button onClick={() => act({ action: "approve", id: r.id })} className="btn-ghost rounded-lg px-2 py-1 text-[11px] font-extrabold" title="Onayla">✓</button><button onClick={() => act({ action: "reject", id: r.id })} className="btn-ghost rounded-lg px-2 py-1 text-[11px] font-extrabold" title="Reddet">✕</button><button onClick={() => act({ action: "delete", id: r.id })} className="btn-danger rounded-lg px-2 py-1 text-[11px] font-extrabold" title="Sil">🗑</button></div> : <span className="text-[10px] font-bold muted">{r.status === "pending" ? "Beklemede" : r.status}</span>}</div>)}{reqs.length === 0 && <div className="py-4 text-center text-xs muted">Henüz istek yok.</div>}</div>
      {isDj && <div className="soft mt-3 rounded-2xl p-3 text-xs muted">💡 Ara → sonuçlardan “Çal” ile tam YouTube şarkısını anında herkese yayınla. İsteyenler 30 dk boyunca kapatmazsan otomatik durur — isteyen kullanıcı <b>✕ Kapat</b> ile kendi cihazında susturabilir. Tüm şarkılar tam sürüm (YouTube embed).</div>}
    </Modal>
  );
}

/* ---------------- RADYO + DJ TAM ŞARKI ---------------- */
export function RadioPlayer({ radio, nowPlaying, onStopDj }: { radio: { enabled: boolean; station: string; customUrl: string }; nowPlaying: { title: string; artist: string; previewUrl?: string; youtubeId?: string; artwork?: string; djName?: string } | null; onStopDj?: () => void }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ytWrapRef = useRef<HTMLDivElement | null>(null);
  const [stationId, setStationId] = useState<string>(radio.station || RADIO_STATIONS[0].id);
  const [custom, setCustom] = useState(radio.customUrl || "");
  const [playing, setPlaying] = useState(false);
  const [djPlaying, setDjPlaying] = useState(true);
  const [djMuted, setDjMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [err, setErr] = useState(false);
  const [open, setOpen] = useState(false);
  const [np, setNp] = useState<string>("");
  const station = RADIO_STATIONS.find((s) => s.id === stationId) ?? RADIO_STATIONS[0];
  const src = stationId === "custom" ? custom : station.url;
  useEffect(() => { if (audioRef.current) audioRef.current.volume = volume; }, [volume]);
  useEffect(() => { const el = audioRef.current; if (!el) return; if (playing && src) { setErr(false); el.src = src; el.play().catch(() => { setErr(true); setPlaying(false); }); } else { el.pause(); el.removeAttribute("src"); el.load(); } }, [playing, src]);
  useEffect(() => { if (!playing) return; const load = async () => { const r = await fetch("/api/radio/nowplaying", { cache: "no-store" }); if (r.ok) { const d = await r.json(); if (d.track) setNp(`${d.track.artist} — ${d.track.title}`); } }; load(); const t = setInterval(load, 30000); return () => clearInterval(t); }, [playing]);
  useEffect(() => { if (nowPlaying?.youtubeId) setDjPlaying(true); }, [nowPlaying?.youtubeId]);
  if (!radio.enabled && !nowPlaying) return null;
  const hasDj = !!nowPlaying;
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)} className="soft flex items-center gap-2 rounded-xl px-2.5 py-1.5 text-xs font-extrabold">
        <span className={`flex h-6 w-6 items-center justify-center rounded-full ${playing || hasDj ? "brand-gradient text-white" : "bg-[var(--border)]"}`}>{hasDj ? "🎧" : playing ? "♪" : "📻"}</span>
        <span className="hidden max-w-[160px] truncate sm:inline">{hasDj ? `${nowPlaying.title} · DJ` : playing ? np || station.name : "Radyo"}</span>
        {(playing || hasDj) && <span className="flex h-3 items-end gap-[2px]" style={{ color: "var(--brand)" }}><i className="eq-bar" /><i className="eq-bar" /><i className="eq-bar" /></span>}
        {hasDj && !djMuted && djPlaying && <span className="hidden h-2 w-2 rounded-full bg-red-500 sm:inline-block" />}
      </button>
      {open && (
        <div className="card absolute right-0 top-10 z-30 w-80 rounded-2xl p-3 shadow-xl">
          {/* Radio station */}
          <div className="flex items-center gap-3">
            <button onClick={() => setPlaying((p) => !p)} className="brand-gradient flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white">{playing ? "❚❚" : "▶"}</button>
            <div className="min-w-0 flex-1"><div className="truncate text-sm font-extrabold">{stationId === "custom" ? "Özel yayın" : station.name}</div><div className="truncate text-[11px] muted">{err ? "Yayına ulaşılamadı" : np || (stationId === "custom" ? custom : station.genre)}</div></div>
          </div>
          <select value={stationId} onChange={(e) => setStationId(e.target.value)} className="input mt-2 w-full rounded-xl px-2 py-1.5 text-xs font-bold">{RADIO_STATIONS.map((s) => <option key={s.id} value={s.id}>{s.name} — {s.genre}</option>)}<option value="custom">Özel yayın adresi…</option></select>
          {stationId === "custom" && <input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="https://…/stream.mp3" className="input mt-2 w-full rounded-xl px-2 py-1.5 text-xs" />}
          <div className="mt-2 flex items-center gap-2 text-xs">🔈 Radyo<input type="range" min={0} max={1} step={0.05} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="w-full" style={{ accentColor: "var(--brand)" }} /></div>
          {/* DJ full track */}
          {hasDj && (
            <div className="soft mt-3 rounded-xl p-2">
              <div className="flex items-center gap-2"><div className={`flex h-8 w-8 items-center justify-center rounded-lg text-white ${nowPlaying.youtubeId ? "bg-red-500" : "brand-gradient"}`}>{nowPlaying.youtubeId ? "▶" : "🎧"}</div><div className="min-w-0 flex-1"><div className="truncate text-xs font-black">{nowPlaying.title}</div><div className="truncate text-[10px] muted">{nowPlaying.artist} · DJ {nowPlaying.djName} {nowPlaying.youtubeId ? "· YouTube tam sürüm" : "· önizleme"}</div></div></div>
              {nowPlaying.youtubeId ? (
                <div ref={ytWrapRef} className="mt-2 overflow-hidden rounded-xl border" style={{ borderColor: "var(--border)" }}>
                  {djPlaying ? <iframe src={`https://www.youtube.com/embed/${nowPlaying.youtubeId}?autoplay=1&controls=1&rel=0&modestbranding=1`} className="h-36 w-full" allow="autoplay; encrypted-media" allowFullScreen title={nowPlaying.title} /> : <div className="flex h-20 items-center justify-center bg-black text-xs font-bold text-white/70">Durduruldu — Başlat’a bas</div>}
                </div>
              ) : nowPlaying.previewUrl ? (
                <audio controls autoPlay className="mt-2 w-full" src={nowPlaying.previewUrl} onPlay={() => setDjPlaying(true)} onPause={() => setDjPlaying(false)} />
              ) : null}
              <div className="mt-2 flex flex-wrap gap-1">
                <button onClick={() => setDjPlaying((v) => !v)} className={`rounded-lg px-2 py-1 text-xs font-extrabold ${djPlaying ? "btn-ghost" : "brand-gradient text-white"}`}>{djPlaying ? "⏸ Durdur" : "▶ Başlat"}</button>
                <button onClick={() => setDjMuted((v) => !v)} className="btn-ghost rounded-lg px-2 py-1 text-xs font-extrabold">{djMuted ? "🔇 Sessiz — Aç" : "🔊 Ses açık — Sustur"}</button>
                <button onClick={() => { setDjPlaying(false); onStopDj?.(); }} className="btn-danger ml-auto rounded-lg px-2 py-1 text-xs font-extrabold">✕ Yayını kapat</button>
                {nowPlaying.youtubeId && <a href={`https://youtu.be/${nowPlaying.youtubeId}`} target="_blank" rel="noreferrer" className="btn-ghost rounded-lg px-2 py-1 text-xs font-bold">YouTube'da aç</a>}
              </div>
              {nowPlaying.artwork && <img src={nowPlaying.artwork} alt="" className="mt-2 h-16 w-16 rounded-lg object-cover" />}
            </div>
          )}
          {hasDj && !nowPlaying.youtubeId && !nowPlaying.previewUrl && <div className="mt-2 text-center text-xs muted">Ses kaynağı yok — DJ farklı bir şarkı seçsin</div>}
        </div>
      )}
      {/* hidden radio audio */}
      <audio ref={audioRef} preload="none" style={{ display: "none" }} />
    </div>
  );
}

/* ---------------- EMOJİ ---------------- */
export function EmojiPicker({ onPick, onClose }: { onPick: (e: string) => void; onClose: () => void }) {
  return (
    <div className="card absolute bottom-14 left-0 z-30 w-72 rounded-2xl p-2 shadow-xl">
      <div className="flex items-center justify-between px-1 text-[11px] font-extrabold muted"><span>{EMOJIS.length}+ emoji</span><button onClick={onClose}>✕</button></div>
      <div className="scroll-thin mt-1 grid max-h-48 grid-cols-8 gap-0.5 overflow-y-auto">{EMOJIS.map((e, i) => <button key={i} type="button" onClick={() => onPick(e)} className="rounded-lg p-1 text-lg hover:bg-[var(--surface-2)]">{e}</button>)}</div>
    </div>
  );
}

/* ---------------- AYARLAR ---------------- */
export function SettingsModal({ me, onClose, update, logout, notify, goRegister }: { me: PublicUser; onClose: () => void; update: (p: Record<string, unknown>) => Promise<boolean>; logout: () => void; notify: Notify; goRegister: () => void }) {
  const [tab, setTab] = useState<"profil" | "gorunum" | "sesler" | "tercihler" | "guvenlik">("profil");
  type PrefKey = "prefDm" | "prefVoice" | "prefVideo" | "prefAudio" | "prefImage" | "prefFollow" | "prefNotif";
  const [prefs, setPrefs] = useState<Record<PrefKey, string>>({
    prefDm: (me as unknown as Record<string, unknown>).prefDm as string ?? "everyone",
    prefVoice: (me as unknown as Record<string, unknown>).prefVoice as string ?? "everyone",
    prefVideo: (me as unknown as Record<string, unknown>).prefVideo as string ?? "everyone",
    prefAudio: (me as unknown as Record<string, unknown>).prefAudio as string ?? "everyone",
    prefImage: (me as unknown as Record<string, unknown>).prefImage as string ?? "everyone",
    prefFollow: (me as unknown as Record<string, unknown>).prefFollow as string ?? "everyone",
    prefNotif: (me as unknown as Record<string, unknown>).prefNotif as string ?? "everyone",
  });
  const cyclePref = async (key: PrefKey) => {
    const order = ["everyone", "friends", "nobody"];
    const cur = prefs[key] ?? "everyone";
    const next = order[(order.indexOf(cur) + 1) % order.length];
    setPrefs((p) => ({ ...p, [key]: next }));
    const ok = await update({ [key]: next });
    if (ok) notify("Tercih kaydedildi ✓");
    else setPrefs((p) => ({ ...p, [key]: cur }));
  };
  const [f, setF] = useState({ status: me.status, mood: me.mood, country: me.country, city: me.city, about: me.about, nickColor: me.nickColor ?? "", tsColor: me.textStyle?.color ?? "", bold: !!me.textStyle?.bold, italic: !!me.textStyle?.italic, gender: (me as unknown as { gender?: string }).gender ?? "" });
  const [piggyBusy, setPiggyBusy] = useState(false);
  const [verifyStep, setVerifyStep] = useState(0);
  const vidRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [pw, setPw] = useState({ cur: "", nw: "" });
  const set = (k: string, v: unknown) => setF((p) => ({ ...p, [k]: v }));
  async function upload(k: "avatarUrl" | "bannerUrl", file?: File) { if (!file) return; const url = await fileToDataUrl(file, k === "avatarUrl" ? 320 : 1000); await update({ [k]: url }); notify("Yüklendi ✓"); }
  async function saveProfile() { const ok = await update({ status: f.status, mood: f.mood, country: f.country, city: f.city, about: f.about, gender: f.gender, nickColor: f.nickColor || null, textStyle: { color: f.tsColor || undefined, bold: f.bold, italic: f.italic } }); if (ok) notify("Profil kaydedildi ✓"); }
  async function piggy() { setPiggyBusy(true); const r = await fetch("/api/piggy", { method: "POST" }); const d = await r.json(); notify(r.ok ? `🐷 Kumbara açıldı: +${d.gained - d.fee} puan` : d.error); setPiggyBusy(false); await update({}); }
  async function startVerify() { try { const s = await navigator.mediaDevices.getUserMedia({ video: true }); streamRef.current = s; setVerifyStep(1); setTimeout(() => { if (vidRef.current) { vidRef.current.srcObject = s; vidRef.current.play(); } }, 50); } catch { notify("Kameraya erişilemedi"); } }
  async function captureVerify() { const v = vidRef.current; if (!v) return; const c = document.createElement("canvas"); c.width = 320; c.height = 240; c.getContext("2d")!.drawImage(v, 0, 0, 320, 240); const selfie = c.toDataURL("image/jpeg", 0.8); streamRef.current?.getTracks().forEach((t) => t.stop()); setVerifyStep(0); await update({ verify: true, selfie }); notify("✅ Profilin doğrulandı — Mavi Tık!"); }
  const isVip = rankLevel(me.rank) >= 2;
  return (
    <Modal onClose={onClose} wide>
      <div className="flex items-center gap-3"><Avatar name={me.username} color={me.color} url={me.avatarUrl} size={56} verified={me.isVerified} presence={me.presence} /><div><div className="text-lg font-black">{me.username}</div><div className="flex items-center gap-2"><RankBadge rank={me.rank} /><span className="text-xs font-bold muted">Seviye {me.level} · {me.points} puan</span></div></div><LevelRing xp={me.xp} /></div>
      {me.isGuest && <div className="mt-4 rounded-2xl px-4 py-3 text-xs font-bold" style={{ background: "var(--brand-soft)", color: "var(--brand)" }}>Misafir olarak sohbet ediyorsun. Adını korumak, çark çevirmek, oda sahibi olmak ve rütbe kazanmak için <button onClick={goRegister} className="underline">kayıt ol</button> (+100 puan).</div>}
      <div className="soft mt-4 grid grid-cols-5 gap-1 rounded-2xl p-1 text-xs font-extrabold">{([["profil", "Profil"], ["gorunum", "Görünüm"], ["sesler", "Sesler"], ["tercihler", "Tercihler"], ["guvenlik", "Hesap"]] as const).map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`rounded-xl py-2 ${tab === k ? "brand-gradient text-white" : "muted"}`}>{l}</button>)}</div>

      {tab === "profil" && (
        <div className="mt-3 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <label className="soft flex cursor-pointer items-center gap-2 rounded-2xl p-3 text-xs font-extrabold"><span>🖼 Profil fotoğrafı</span><input type="file" accept="image/*" className="hidden" onChange={(e) => upload("avatarUrl", e.target.files?.[0])} /></label>
            <label className="soft flex cursor-pointer items-center gap-2 rounded-2xl p-3 text-xs font-extrabold"><span>🏞 Banner</span><input type="file" accept="image/*" className="hidden" onChange={(e) => upload("bannerUrl", e.target.files?.[0])} /></label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Cinsiyet</label><select value={f.gender ?? me.gender} onChange={(e) => set("gender", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm font-bold"><option value="">Belirtme</option><option value="kadin">♀ Kadın</option><option value="erkek">♂ Erkek</option><option value="diger">⚧ Diğer</option></select></div>
            <div><label className="label">Ruh hali</label><input value={f.mood} maxLength={40} onChange={(e) => set("mood", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" placeholder="Mutlu 😊" /></div>
            <div><label className="label">Durum mesajı</label><input value={f.status} maxLength={80} onChange={(e) => set("status", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" placeholder="müzik dinliyorum 🎧" /></div>
            <div><label className="label">Ülke</label><input value={f.country} onChange={(e) => set("country", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" placeholder="Türkiye" /></div>
            <div><label className="label">Şehir</label><input value={f.city} onChange={(e) => set("city", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" placeholder="İstanbul" /></div>
          </div>
          <div><label className="label">Hakkımda</label><textarea value={f.about} maxLength={300} rows={3} onChange={(e) => set("about", e.target.value)} className="input w-full rounded-xl px-3 py-2 text-sm" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Nick rengi</label><div className="flex items-center gap-2"><input type="color" value={f.nickColor || me.color} onChange={(e) => set("nickColor", e.target.value)} className="h-9 w-12 rounded-lg" /><button onClick={() => set("nickColor", "")} className="btn-ghost rounded-lg px-2 py-1 text-xs font-bold">Sıfırla</button></div></div>
            <div><label className="label">Mesaj yazı stili</label><div className="flex items-center gap-2"><input type="color" value={f.tsColor || "#333333"} onChange={(e) => set("tsColor", e.target.value)} className="h-9 w-12 rounded-lg" /><button onClick={() => set("bold", !f.bold)} className={`rounded-lg px-2.5 py-1 text-sm font-black ${f.bold ? "brand-gradient text-white" : "soft"}`}>B</button><button onClick={() => set("italic", !f.italic)} className={`rounded-lg px-2.5 py-1 text-sm italic ${f.italic ? "brand-gradient text-white" : "soft"}`}>I</button></div></div>
          </div>
          <div className="soft rounded-xl p-3 text-sm" style={{ color: f.tsColor || undefined, fontWeight: f.bold ? 800 : 500, fontStyle: f.italic ? "italic" : undefined }}>Önizleme: <span style={{ color: f.nickColor || me.color }} className="font-extrabold">{me.username}</span>: merhaba dünya!</div>
          <div className="flex gap-2"><button onClick={saveProfile} className="btn-primary flex-1 rounded-2xl py-2.5 text-sm font-extrabold">Kaydet</button>
            <div className="soft flex rounded-2xl p-1 text-xs font-extrabold">{([["online", "🟢 Çevrimiçi"], ["busy", "⛔ Meşgul"], ["away", "🌙 Uzakta"]] as const).map(([k, l]) => <button key={k} onClick={() => update({ presence: k })} className={`rounded-xl px-2 py-1.5 ${me.presence === k ? "brand-gradient text-white" : "muted"}`}>{l}</button>)}</div></div>
        </div>
      )}
      {tab === "gorunum" && (
        <div className="mt-3 space-y-4">
          <div><SectionLabel className="mt-0">Tema — {THEMES.length} gerçekçi</SectionLabel>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">{THEMES.map((t) => <button key={t.key} onClick={() => update({ theme: t.key })} className="theme-card flex items-center gap-2 rounded-xl border px-2.5 py-2 text-xs font-extrabold" style={{ borderColor: me.theme === t.key ? "var(--brand)" : "var(--border)", background: me.theme === t.key ? "var(--brand-soft)" : "var(--surface-2)" }}><span className="flex h-5 w-5 overflow-hidden rounded-full border border-black/10"><span className="w-1/2" style={{ background: t.swatch[0] }} /><span className="w-1/2" style={{ background: t.swatch[1] }} /></span>{t.label}</button>)}</div></div>
          <div><SectionLabel>Avatar rengi</SectionLabel>
          <div className="grid grid-cols-8 gap-2">{AVATAR_COLORS.map((c) => <button key={c} onClick={() => update({ color: c })} className="aspect-square rounded-full transition hover:scale-110" style={{ background: `linear-gradient(135deg, ${c}, color-mix(in srgb, ${c} 70%, white))`, boxShadow: me.color === c ? `0 0 0 3px var(--surface), 0 0 0 5px ${c}` : undefined }} />)}</div></div>
          <div>
            <SectionLabel>💎 Avatar Çerçeveleri — seviye ile açılır</SectionLabel>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {AVATAR_FRAMES.map((f) => {
                const locked = me.level < f.unlockLevel;
                return <button key={f.id} disabled={locked} onClick={() => !locked && update({ avatarFrame: f.id })} className={`flex flex-col items-center gap-1 rounded-xl border p-2 text-xs font-bold transition ${locked ? "opacity-40 cursor-not-allowed" : "hover:scale-105"} ${me.avatarFrame === f.id ? "border-[var(--brand)] bg-[var(--brand-soft)]" : "soft"}`}>
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--surface)] text-lg" style={{ boxShadow: locked ? "none" : f.css || "0 0 0 1px var(--border)" }}>{f.preview}</span>
                  <span className="text-[10px] leading-tight">{f.name}</span>
                  <span className="text-[9px] muted">Lv {f.unlockLevel}{locked ? " 🔒" : me.avatarFrame === f.id ? " ✓" : ""}</span>
                </button>;
              })}
            </div>
          </div>
          <div>
            <SectionLabel>✨ Nick Efektleri — hareketli neon</SectionLabel>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {NICK_EFFECTS.map((e) => {
                const locked = me.level < e.unlockLevel;
                return <button key={e.id} disabled={locked} onClick={() => !locked && update({ nickEffect: e.id })} className={`rounded-xl border p-2 text-left transition ${locked ? "opacity-40 cursor-not-allowed" : "hover:scale-[1.02]"} ${me.nickEffect === e.id ? "border-[var(--brand)] bg-[var(--brand-soft)]" : "soft"}`}>
                  <div className={`text-sm font-black truncate ${e.id === "neon" ? "nick-neon" : e.id === "glow-pulse" ? "nick-glow-pulse" : e.id === "rainbow-anim" ? "nick-rainbow" : e.id === "fire-text" ? "nick-fire" : e.id === "ice" ? "nick-ice" : e.id === "gold-shine" ? "nick-gold" : ""}`} style={{ color: me.nickColor || me.color }}>{e.preview} {e.name}</div>
                  <div className="text-[9px] muted">Lv {e.unlockLevel}{locked ? " 🔒" : me.nickEffect === e.id ? " ✓" : ""}</div>
                </button>;
              })}
            </div>
            <div className="mt-2 soft rounded-xl p-2 text-[11px] muted">💡 Seviye yükseldikçe yeni çerçeve ve neon efektler açılır. Hediye ve okey ile XP kas, seviye atla!</div>
          </div>
          <div><SectionLabel>Rütbeler</SectionLabel>
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">{RANK_ORDER.map((rk) => <div key={rk} className="soft flex items-center gap-2 rounded-lg px-2 py-1.5"><RankBadge rank={rk} /></div>)}</div></div>
        </div>
      )}
      {tab === "sesler" && <SoundSettingsPanel notify={notify} />}
      {tab === "tercihler" && (
        <div className="mt-0 -m-5 sm:-m-6">
          <div className="bg-white rounded-b-3xl overflow-hidden">
            <div className="flex items-center gap-3 px-4 pt-4 pb-3 border-b" style={{ borderColor: "#eef1f4" }}>
              <button onClick={() => setTab("profil")} className="text-xl leading-none text-slate-800" aria-label="Geri">←</button>
              <div className="text-[17px] font-black text-slate-900">Tercihlerim</div>
            </div>
            <div className="px-4 py-4 space-y-5 bg-white">
              {([
                ["prefDm", "Özel Mesaj", "Sana kimler özel mesaj gönderebilir?"],
                ["prefVoice", "Sesli Arama", "Seni kimler sesli arayabilir?"],
                ["prefVideo", "Görüntülü Arama", "Seni kimler görüntülü arayabilir?"],
                ["prefAudio", "Özel Ses", "Sana kimler özel mesajda ses gönderebilir?"],
                ["prefImage", "Özel Görsel", "Sana kimler özel mesajda görsel veya video gönderebilir?"],
                ["prefFollow", "Takip İstekleri", "Sana kimler takip isteği gönderebilir?"],
                ["prefNotif", "Bildirimler", "Bildirim almak ister misin?"],
              ] as [PrefKey, string, string][]).map(([key, title, sub]) => (
                <div key={key}>
                  <div className="text-[15px] font-bold" style={{ color: "#1a73e8" }}>{title}</div>
                  <div className="text-[12px] text-slate-500 mt-0.5">{sub}</div>
                  <button onClick={() => cyclePref(key)} className="mt-1.5 flex w-full items-center rounded-md border bg-white text-left" style={{ borderColor: "#d7dce1" }}>
                    <span className="flex-1 px-3 py-3 text-[14px] text-slate-600">{PREF_LABEL[(prefs[key] ?? "everyone") as "everyone" | "friends" | "nobody"]}</span>
                    <span className="flex w-14 items-center justify-center border-l py-3" style={{ borderColor: "#d7dce1", color: "#1a73e8" }} title="Değiştir">⇄</span>
                  </button>
                </div>
              ))}
              <div className="rounded-xl px-3 py-2 text-[11px] text-slate-500" style={{ background: "var(--surface-2)" }}>💡 Kutuya dokundukça değişir: Herkes → Dostlarım → Hiçkimse. Değişiklik anında kaydedilir.</div>
            </div>
          </div>
        </div>
      )}
      {tab === "guvenlik" && (
        <div className="mt-3 space-y-3">
          <div className="soft flex items-center justify-between rounded-2xl p-3"><div><div className="text-sm font-extrabold">🐷 Puan kumbarası: {me.piggyBank}</div><div className="text-[11px] muted">Her mesajda birikir. {isVip ? "VIP olduğun için ücretsiz açarsın." : "Açmak için %25 ücret (VIP için ücretsiz)."}</div></div><button disabled={piggyBusy || me.piggyBank < 20} onClick={piggy} className="btn-primary rounded-xl px-3 py-2 text-xs font-extrabold">Aç</button></div>
          <div className="soft flex items-center justify-between rounded-2xl p-3"><div><div className="text-sm font-extrabold">👻 Hayalet modu {!isVip && <span className="text-[10px] text-amber-600">VIP</span>}</div><div className="text-[11px] muted">Listelerde görünmeden gez.</div></div><button disabled={!isVip} onClick={() => update({ ghostMode: !me.ghostMode })} className={`rounded-xl px-3 py-2 text-xs font-extrabold ${me.ghostMode ? "brand-gradient text-white" : "btn-ghost"}`}>{me.ghostMode ? "Açık" : "Kapalı"}</button></div>
          <div className="soft rounded-2xl p-3">
            <div className="text-sm font-extrabold">✅ AI Selfie Doğrulama {me.isVerified && <span className="text-blue-500">— Doğrulandı</span>}</div>
            <div className="text-[11px] muted">Kameraya bak, göz kırp ve sağa bak; canlılık kontrolünden geçince Mavi Tık alırsın.</div>
            {!me.isVerified && verifyStep === 0 && <button onClick={startVerify} className="btn-primary mt-2 rounded-xl px-3 py-2 text-xs font-extrabold">Doğrulamayı başlat</button>}
            {verifyStep === 1 && <div className="mt-2"><video ref={vidRef} muted playsInline className="w-full rounded-xl bg-black" style={{ aspectRatio: "4/3", transform: "scaleX(-1)" }} /><div className="mt-1 text-center text-xs font-bold">👁 Göz kırp → 👉 sağa bak → 📸</div><button onClick={captureVerify} className="btn-primary mt-2 w-full rounded-xl py-2 text-xs font-extrabold">Selfie çek ve doğrula</button></div>}
          </div>
          {!me.isGuest && <div className="soft rounded-2xl p-3"><div className="text-sm font-extrabold">🔑 Şifre değiştir</div><div className="mt-2 flex gap-2"><input type="password" placeholder="Mevcut" value={pw.cur} onChange={(e) => setPw({ ...pw, cur: e.target.value })} className="input flex-1 rounded-xl px-3 py-2 text-sm" /><input type="password" placeholder="Yeni" value={pw.nw} onChange={(e) => setPw({ ...pw, nw: e.target.value })} className="input flex-1 rounded-xl px-3 py-2 text-sm" /><button onClick={async () => { if (await update({ currentPassword: pw.cur, newPassword: pw.nw })) { notify("Şifre güncellendi ✓"); setPw({ cur: "", nw: "" }); } }} className="btn-primary rounded-xl px-3 text-xs font-extrabold">Kaydet</button></div></div>}
          <div className="soft rounded-2xl p-3 text-[11px] muted">🛡 <b>Anti-screenshot:</b> Web sürümünde sağ tık ve geliştirici kısayolları kısıtlıdır; mobil uygulamada ekran kaydı engellenir. 📱 Uygulamayı ana ekrana ekleyerek bildirimleri arka planda alabilirsin.</div>
          <button onClick={logout} className="btn-danger w-full rounded-2xl py-2.5 text-sm font-extrabold">Çıkış yap</button>
        </div>
      )}
    </Modal>
  );
}

function SoundSettingsPanel({ notify }: { notify: Notify }) {
  const [settings, setSettings] = useState<SoundSettings>(() => getSoundSettings());
  const update = (cat: SoundCategory, patch: Partial<SoundSettings[SoundCategory]>) => {
    const next = { ...settings, [cat]: { ...settings[cat], ...patch } };
    setSettings(next); saveSoundSettings(next);
  };
  const allOff = Object.values(settings).every((v) => !v.enabled);
  return (
    <div className="mt-3 space-y-3">
      <div className="soft flex items-center justify-between rounded-2xl p-3">
        <div><div className="text-sm font-extrabold">🔊 Tüm sesler</div><div className="text-[11px] muted">{allOff ? "Kapalı" : "Açık — her kategori ayrı ayarlanır"}</div></div>
        <button onClick={() => { const en = allOff; const next = Object.fromEntries(Object.entries(settings).map(([k, v]) => [k, { ...v, enabled: en }])) as SoundSettings; setSettings(next); saveSoundSettings(next); notify(en ? "Sesler açıldı" : "Sesler kapatıldı"); }} className={`rounded-xl px-3 py-1.5 text-xs font-extrabold ${allOff ? "btn-ghost" : "brand-gradient text-white"}`}>{allOff ? "Aç" : "Kapat"}</button>
      </div>
      {(Object.keys(SOUND_CATEGORIES) as SoundCategory[]).map((cat) => {
        const meta = SOUND_CATEGORIES[cat];
        const cfg = settings[cat];
        return (
          <div key={cat} className="card rounded-2xl p-3">
            <div className="flex items-center gap-2"><span className="text-lg">{meta.icon}</span><div className="flex-1"><div className="text-sm font-black">{meta.label}</div><div className="text-[11px] muted">{meta.desc}</div></div><button onClick={() => update(cat, { enabled: !cfg.enabled })} className={`rounded-full px-3 py-1 text-xs font-extrabold ${cfg.enabled ? "brand-gradient text-white" : "btn-ghost"}`}>{cfg.enabled ? "Açık" : "Kapalı"}</button></div>
            {cfg.enabled && (
              <div className="mt-3 space-y-2">
                <div className="flex items-center gap-2 text-xs"><span className="w-12 font-bold muted">Ses</span>
                  <select value={cfg.preset} onChange={(e) => { update(cat, { preset: e.target.value }); setTimeout(() => testSound(cat, e.target.value, cfg.volume), 100); }} className="input flex-1 rounded-xl px-2 py-1.5 text-xs font-bold">
                    {SOUND_PRESETS[cat].map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <button onClick={() => testSound(cat)} className="btn-ghost rounded-lg px-2 py-1 text-xs font-bold">▶ Test</button>
                </div>
                <div className="flex items-center gap-2 text-xs"><span className="w-12 font-bold muted">Ses seviyesi</span><input type="range" min={0} max={100} value={cfg.volume} onChange={(e) => update(cat, { volume: Number(e.target.value) })} className="flex-1" style={{ accentColor: "var(--brand)" }} /><span className="w-8 text-center text-xs font-black">{cfg.volume}</span><button onClick={() => testSound(cat, undefined, cfg.volume)} className="btn-ghost rounded-lg px-2 py-1 text-xs">🔊</button></div>
              </div>
            )}
          </div>
        );
      })}
      <div className="soft rounded-2xl p-3 text-[11px] muted">💡 Her kategori bağımsız: <b>Sohbet</b> oda mesajı, <b>Özel</b> DM, <b>Bildirim</b> genel, <b>Username</b> @mention, <b>Çağrı</b> görüntülü arama. Test ile önizle, otomatik kaydedilir.</div>
    </div>
  );
}

export function levelOf(xp: number) { return levelFromXp(xp); }
export type { RankKey };
