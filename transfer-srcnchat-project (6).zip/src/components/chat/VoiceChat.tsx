"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { makePeer, onSignal, sendSignal, type Signal } from "./webrtc";

export type VoiceHolder = { roomId: number; userId: number; username: string; startedAt: string; updatedAt: string } | null;
export type VoiceQueueEntry = { id: number; userId: number; username: string; createdAt: string };
export type VoiceState = { holder: VoiceHolder; queue: VoiceQueueEntry[]; amHolder: boolean; myPosition: number };

export function useVoiceMic(roomId: number | null, meId: number, notify: (m: string) => void) {
  const [voice, setVoice] = useState<VoiceState>({ holder: null, queue: [], amHolder: false, myPosition: 0 });
  const [busy, setBusy] = useState(false);
  const localStream = useRef<MediaStream | null>(null);
  const peers = useRef(new Map<number, RTCPeerConnection>());
  const listenerPc = useRef<RTCPeerConnection | null>(null);
  const listenerKey = useRef<string>("");
  const remoteAudio = useRef<HTMLAudioElement | null>(null);
  const [live, setLive] = useState(false);

  const load = useCallback(async () => {
    if (!roomId) return;
    try {
      const r = await fetch(`/api/rooms/${roomId}/voice`, { cache: "no-store" });
      if (!r.ok) return;
      const d = await r.json();
      setVoice({ holder: d.holder ?? null, queue: d.queue ?? [], amHolder: !!d.amHolder, myPosition: d.myPosition ?? 0 });
    } catch {}
  }, [roomId]);

  useEffect(() => {
    setVoice({ holder: null, queue: [], amHolder: false, myPosition: 0 });
    if (!roomId) return;
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [roomId, load]);

  // Heartbeat while holding
  useEffect(() => {
    if (!roomId || !voice.amHolder) return;
    const t = setInterval(() => {
      fetch(`/api/rooms/${roomId}/voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "heartbeat" }),
      }).catch(() => {});
    }, 5000);
    return () => clearInterval(t);
  }, [roomId, voice.amHolder]);

  const stopLocal = useCallback(() => {
    localStream.current?.getTracks().forEach((t) => t.stop());
    localStream.current = null;
    peers.current.forEach((pc) => pc.close());
    peers.current.clear();
    setLive(false);
  }, []);

  const stopListener = useCallback(() => {
    listenerPc.current?.close();
    listenerPc.current = null;
    listenerKey.current = "";
    if (remoteAudio.current) remoteAudio.current.srcObject = null;
  }, []);

  // Holder: answer listener offers
  useEffect(() => {
    if (!roomId || !voice.amHolder || !localStream.current) return;
    const off = onSignal(async (sig: Signal) => {
      if (sig.channel !== "voice") return;
      const room = (sig.payload as Record<string, unknown>)?.["roomId"];
      if (room !== roomId) return;
      if (sig.type === "offer") {
        const pc = makePeer(sig.fromUserId, "voice", () => {}, () => {
          peers.current.get(sig.fromUserId)?.close();
          peers.current.delete(sig.fromUserId);
        });
        localStream.current?.getAudioTracks().forEach((t) => pc.addTrack(t, localStream.current!));
        peers.current.set(sig.fromUserId, pc);
        await pc.setRemoteDescription(sig.payload["offer"] as unknown as RTCSessionDescriptionInit);
        const ans = await pc.createAnswer();
        await pc.setLocalDescription(ans);
        await sendSignal(sig.fromUserId, "voice", "answer", { answer: ans, roomId });
      } else if (sig.type === "ice") {
        await peers.current.get(sig.fromUserId)?.addIceCandidate(sig.payload as unknown as RTCIceCandidateInit).catch(() => {});
      } else if (sig.type === "bye") {
        peers.current.get(sig.fromUserId)?.close();
        peers.current.delete(sig.fromUserId);
      }
    });
    return () => off();
  }, [roomId, voice.amHolder]);

  // Listener: connect to holder
  useEffect(() => {
    if (!roomId) return;
    const holder = voice.holder;
    if (!holder || holder.userId === meId) {
      if (listenerPc.current) stopListener();
      return;
    }
    const key = `${holder.userId}:${holder.startedAt}`;
    if (listenerPc.current && listenerKey.current === key) return;
    stopListener();
    let pc: RTCPeerConnection | null = null;
    let alive = true;
    const off = onSignal(async (sig: Signal) => {
      if (sig.channel !== "voice" || sig.fromUserId !== holder.userId || !pc) return;
      if ((sig.payload as Record<string, unknown>)?.["roomId"] !== roomId) return;
      if (sig.type === "answer") {
        await pc.setRemoteDescription((sig.payload as Record<string, unknown>)["answer"] as unknown as RTCSessionDescriptionInit).catch(() => {});
      } else if (sig.type === "ice") {
        await pc.addIceCandidate(sig.payload as unknown as RTCIceCandidateInit).catch(() => {});
      } else if (sig.type === "bye") {
        if (alive) stopListener();
      }
    });
    (async () => {
      pc = makePeer(holder.userId, "voice", (s) => {
        if (remoteAudio.current) {
          remoteAudio.current.srcObject = s;
          remoteAudio.current.play().catch(() => {});
        }
      });
      listenerPc.current = pc;
      listenerKey.current = key;
      pc.addTransceiver("audio", { direction: "recvonly" });
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await sendSignal(holder.userId, "voice", "offer", { offer, roomId });
    })();
    return () => {
      alive = false;
      off();
    };
  }, [roomId, voice.holder, meId, stopListener]);

  // Cleanup on room change / unmount
  useEffect(() => {
    return () => {
      stopLocal();
      stopListener();
    };
  }, [roomId, stopLocal, stopListener]);

  const take = useCallback(async () => {
    if (!roomId || busy) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/rooms/${roomId}/voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "take" }),
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) {
        notify(d.error ?? "Mikrofon alınamadı");
        return;
      }
      setVoice({ holder: d.holder ?? null, queue: d.queue ?? [], amHolder: !!d.amHolder, myPosition: d.myPosition ?? 0 });
      if (d.amHolder) {
        try {
          const s = await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          });
          localStream.current = s;
          setLive(true);
        } catch {
          notify("Mikrofon izni ver");
          await fetch(`/api/rooms/${roomId}/voice`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "release" }),
          });
          const r2 = await fetch(`/api/rooms/${roomId}/voice`, { cache: "no-store" });
          if (r2.ok) {
            const d2 = await r2.json();
            setVoice({ holder: d2.holder ?? null, queue: d2.queue ?? [], amHolder: false, myPosition: d2.myPosition ?? 0 });
          }
          return;
        }
      } else if (d.queued) {
        notify(`Sıradasın (${d.myPosition}). Mikrofon boşalınca otomatik sana geçecek.`);
      }
    } finally {
      setBusy(false);
    }
  }, [roomId, busy, notify]);

  const release = useCallback(async () => {
    if (!roomId || busy) return;
    setBusy(true);
    try {
      stopLocal();
      if (voice.holder) {
        for (const [, pc] of peers.current) {
          try {
            pc.close();
          } catch {}
        }
        peers.current.clear();
        await sendSignal(voice.holder.userId, "voice", "bye", { roomId }).catch(() => {});
      }
      const r = await fetch(`/api/rooms/${roomId}/voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "release" }),
      });
      const d = await r.json().catch(() => ({}));
      if (!r.ok) {
        notify(d.error ?? "Bırakılamadı");
        return;
      }
      setVoice({ holder: d.holder ?? null, queue: d.queue ?? [], amHolder: false, myPosition: 0 });
    } finally {
      setBusy(false);
    }
  }, [roomId, busy, notify, stopLocal, voice.holder]);

  const leaveQueue = useCallback(async () => {
    if (!roomId) return;
    await fetch(`/api/rooms/${roomId}/voice`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "leave" }),
    });
    load();
  }, [roomId, load]);

  return { voice, busy, take, release, leaveQueue, live, remoteAudio, refresh: load };
}

export function MicButton({
  amHolder,
  holderName,
  myPosition,
  busy,
  live,
  onToggle,
  onLeave,
}: {
  amHolder: boolean;
  holderName: string | null;
  myPosition: number;
  busy: boolean;
  live: boolean;
  onToggle: () => void;
  onLeave: () => void;
}) {
  if (amHolder) {
    return (
      <button
        type="button"
        onClick={onToggle}
        disabled={busy}
        title="Mikrofonu bırak"
        className="shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg bg-rose-500 text-white shadow animate-pulse"
      >
        🎤
      </button>
    );
  }
  if (myPosition > 0) {
    return (
      <button
        type="button"
        onClick={onLeave}
        title={`Sıradasın (${myPosition}) — çıkmak için dokun`}
        className="btn-ghost shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg relative"
      >
        🎤<span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[9px] font-black text-white">{myPosition}</span>
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={busy}
      title={holderName ? `${holderName} konuşuyor — sıraya gir` : "Mikrofon al ve konuş"}
      className="btn-ghost shrink-0 rounded-xl px-2 py-2 text-base md:px-2.5 md:py-2.5 md:text-lg"
    >
      🎤
    </button>
  );
}

export function VoiceBar({
  holderName,
  isMe,
  queue,
  myPosition,
  live,
}: {
  holderName: string | null;
  isMe: boolean;
  queue: { username: string }[];
  myPosition: number;
  live: boolean;
}) {
  if (!holderName) return null;
  return (
    <div
      className="flex items-center gap-2 border-b px-3 py-1.5 text-xs"
      style={{ background: "color-mix(in srgb, #ef4444 10%, var(--surface))", borderColor: "var(--border)" }}
    >
      <span className="flex h-4 items-end gap-[2px] text-rose-500">
        <i className="eq-bar" />
        <i className="eq-bar" />
        <i className="eq-bar" />
      </span>
      <span className="font-bold truncate">
        🎙️ {holderName} {isMe ? "(sen) " : ""}konuşuyor{live && isMe ? " ● canlı" : ""}
      </span>
      {queue.length > 0 && <span className="muted truncate">· sırada: {queue.map((q) => q.username).slice(0, 3).join(", ")}{queue.length > 3 ? ` +${queue.length - 3}` : ""}</span>}
      {myPosition > 0 && <span className="ml-auto shrink-0 font-black text-amber-600">Sıran: {myPosition}</span>}
    </div>
  );
}
