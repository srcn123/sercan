"use client";
// DB-polled signaling for WebRTC (cam broadcast + 1:1 calls)
export const ICE: RTCConfiguration = { iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }] };

export type Signal = { id: number; fromUserId: number; toUserId: number; channel: string; type: string; payload: Record<string, unknown> };

export async function sendSignal(to: number, channel: string, type: string, payload: Record<string, unknown> = {}) {
  await fetch("/api/signals", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ to, channel, type, payload }) });
}

type Handler = (s: Signal) => void;
const handlers = new Set<Handler>();
let polling = false;
let lastId = 0;
export function onSignal(h: Handler) {
  handlers.add(h);
  if (!polling) {
    polling = true;
    const tick = async () => {
      try {
        const r = await fetch(`/api/signals?after=${lastId}`, { cache: "no-store" });
        if (r.ok) {
          const d = await r.json();
          for (const s of d.signals as Signal[]) { lastId = Math.max(lastId, s.id); handlers.forEach((fn) => fn(s)); }
        }
      } catch {}
      if (handlers.size) setTimeout(tick, 1200); else polling = false;
    };
    tick();
  }
  return () => { handlers.delete(h); };
}

export function makePeer(remoteId: number, channel: string, onTrack: (stream: MediaStream) => void, onClose?: () => void) {
  const pc = new RTCPeerConnection(ICE);
  pc.onicecandidate = (e) => { if (e.candidate) sendSignal(remoteId, channel, "ice", e.candidate.toJSON() as unknown as Record<string, unknown>); };
  pc.ontrack = (e) => { if (e.streams[0]) onTrack(e.streams[0]); };
  pc.onconnectionstatechange = () => { if (["failed", "closed", "disconnected"].includes(pc.connectionState)) onClose?.(); };
  return pc;
}

// Adaptive bitrate: lower encoding when RTT is high
export async function adaptQuality(pc: RTCPeerConnection, userId: number) {
  try {
    const stats = await pc.getStats();
    let rtt = 0, bitrate = 0;
    stats.forEach((r) => {
      if (r.type === "candidate-pair" && r.state === "succeeded" && r.currentRoundTripTime) rtt = r.currentRoundTripTime * 1000;
      if (r.type === "outbound-rtp" && r.kind === "video" && r.bytesSent) bitrate = r.bytesSent / 1000;
    });
    const sender = pc.getSenders().find((s) => s.track?.kind === "video");
    if (sender) {
      const p = sender.getParameters();
      if (!p.encodings?.length) p.encodings = [{}];
      p.encodings[0].maxBitrate = rtt > 400 ? 250_000 : rtt > 200 ? 600_000 : 1_500_000;
      p.encodings[0].scaleResolutionDownBy = rtt > 400 ? 3 : rtt > 200 ? 2 : 1;
      await sender.setParameters(p).catch(() => {});
    }
    void userId;
    return { rtt, bitrate };
  } catch { return { rtt: 0, bitrate: 0 }; }
}
