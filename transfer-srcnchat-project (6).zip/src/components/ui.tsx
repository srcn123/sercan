"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ACHIEVEMENTS, AVATAR_FRAMES, GIFTS, NICK_EFFECTS, levelFromXp, rankInfo, xpForLevel, type AchievementKey } from "@/lib/constants";

export function RankBadge({ rank, compact = false, sprite = true }: { rank: string; compact?: boolean; sprite?: boolean }) {
  const info = rankInfo(rank);
  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-black uppercase tracking-tight shadow-sm backdrop-blur ${compact ? "px-2 py-0.5 text-[10px]" : "px-3 py-1 text-xs"}`} style={{ background: `color-mix(in srgb, ${info.color} 14%, white)`, color: info.color, border: `1px solid ${info.color}25`, boxShadow: `0 2px 6px ${info.color}15, 0 1px 2px rgba(0,0,0,0.05)` }} title={info.label}>
      {sprite ? <span className="rank-sprite drop-shadow-sm" style={{ width: compact ? 14 : 18, height: compact ? 14 : 18, backgroundPosition: `${(info.sprite / 6) * 100}% 0`, filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.15))" }} /> : <span className="text-[1.1em]">{info.icon}</span>}
      {!compact && <span className="tracking-wide">{info.label}</span>}
    </span>
  );
}

export function GiftIcon({ giftKey, size = 40 }: { giftKey: string; size?: number }) {
  const g = GIFTS.find((x) => x.key === giftKey);
  if (!g) return <span>🎁</span>;
  const col = g.sprite % 4, row = Math.floor(g.sprite / 4);
  return <span className="gift-sprite" style={{ width: size, height: size, backgroundPosition: `${(col / 3) * 100}% ${(row / 2) * 100}%` }} title={g.name} />;
}

export function getFrameStyle(frameId: string) {
  const f = AVATAR_FRAMES.find((x) => x.id === frameId);
  return f?.css || "";
}
export function getNickEffect(effectId: string) {
  const e = NICK_EFFECTS.find((x) => x.id === effectId);
  return e;
}

export function Avatar({ name, color, size = 32, url, presence, verified, ring, frame }: { name: string; color: string; size?: number; url?: string | null; presence?: string | null; verified?: boolean; ring?: boolean; frame?: string }) {
  const pc = presence === "busy" ? "#ef4444" : presence === "away" ? "#f59e0b" : "#22c55e";
  const frameCss = getFrameStyle(frame || "none");
  const isRainbow = frame === "rainbow";
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div className={`flex h-full w-full items-center justify-center overflow-hidden rounded-full font-black text-white ${isRainbow ? "frame-rainbow" : ""}`} style={{ fontSize: size * 0.42, background: `linear-gradient(135deg, ${color}, color-mix(in srgb, ${color} 70%, white))`, boxShadow: isRainbow ? undefined : (frameCss || (ring ? `0 0 0 2px var(--surface), 0 0 0 4px ${color}` : undefined)) }}>
        {url ? <img src={url} alt={name} className="h-full w-full object-cover" /> : name[0]?.toUpperCase()}
      </div>
      {presence && <span className="absolute -bottom-0.5 -left-0.5 rounded-full border-2 shadow-sm" style={{ width: size * 0.3, height: size * 0.3, background: pc, borderColor: "var(--surface)" }} />}
      {verified && <span className="absolute -right-1 -top-1 flex items-center justify-center rounded-full bg-blue-500 text-white shadow" style={{ width: size * 0.36, height: size * 0.36, fontSize: size * 0.22 }}>✓</span>}
    </div>
  );
}

export function LevelRing({ xp, size = 44 }: { xp: number; size?: number }) {
  const lvl = levelFromXp(xp);
  const cur = xpForLevel(lvl), next = xpForLevel(lvl + 1);
  const p = Math.min(100, Math.round(((xp - cur) / Math.max(1, next - cur)) * 100));
  return (
    <div className="level-ring flex items-center justify-center rounded-full" style={{ width: size, height: size, ["--p" as string]: p }} title={`Seviye ${lvl} · ${xp - cur}/${next - cur} XP`}>
      <div className="flex items-center justify-center rounded-full text-[11px] font-black" style={{ width: size - 8, height: size - 8, background: "var(--surface)" }}>{lvl}</div>
    </div>
  );
}

export function NickText({ text, color, effectId, textStyle }: { text: string; color: string; effectId?: string; textStyle?: { color?: string; bold?: boolean; italic?: boolean; neon?: boolean } }) {
  const eff = getNickEffect(effectId || "none");
  const isRainbow = eff?.id === "rainbow-anim";
  const isNeon = eff?.id === "neon" || textStyle?.neon;
  const style: React.CSSProperties = {
    color: isRainbow ? undefined : (textStyle?.color || color),
    fontWeight: textStyle?.bold ? 900 : 700,
    fontStyle: textStyle?.italic ? "italic" : undefined,
    textShadow: isNeon ? (eff?.css as unknown as string) : eff?.css ? (eff.css as unknown as string) : undefined,
  };
  const cls = [
    isNeon ? "nick-neon" : "",
    eff?.id === "glow-pulse" ? "nick-glow-pulse" : "",
    isRainbow ? "nick-rainbow" : "",
    eff?.id === "fire-text" ? "nick-fire" : "",
    eff?.id === "ice" ? "nick-ice" : "",
    eff?.id === "gold-shine" ? "nick-gold" : "",
    eff?.id === "shadow" ? "nick-shadow" : "",
  ].join(" ");
  if (isRainbow) {
    return <span className={`nick-rainbow ${eff?.animated ? "nick-rainbow" : ""}`} style={{ fontWeight: style.fontWeight as number }}>{text}</span>;
  }
  return <span className={cls} style={style}>{text}</span>;
}

export function Modal({ children, onClose, wide }: { children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => { const h = (e: KeyboardEvent) => e.key === "Escape" && onClose(); window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h); }, [onClose]);
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/50 p-3 backdrop-blur-sm sm:items-center" onClick={onClose}>
      <div className={`card pop-in scroll-thin max-h-[92vh] w-full overflow-y-auto rounded-3xl p-5 shadow-2xl sm:p-6 ${wide ? "max-w-3xl" : "max-w-md"} relative`} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-black/10 text-lg font-black hover:bg-black/20 md:hidden" aria-label="Kapat">✕</button>
        {children}
      </div>
    </div>
  );
}

export function SectionLabel({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`label mt-5 ${className}`}>{children}</div>;
}

export function AchBadge({ k }: { k: string }) {
  const a = ACHIEVEMENTS[k as AchievementKey];
  if (!a) return null;
  return <span className="soft inline-flex items-center gap-1 rounded-xl px-2 py-1 text-xs font-bold" title={a.desc}>{a.icon} {a.name}</span>;
}

export function useToast() {
  const [toast, setToast] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const notify = useCallback((m: string) => {
    setToast(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 2800);
  }, []);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const el = toast ? <div className="fade-in fixed bottom-20 left-1/2 z-[60] -translate-x-1/2 rounded-2xl px-4 py-2.5 text-sm font-extrabold text-white shadow-xl" style={{ background: "var(--text)", color: "var(--bg)" }}>{toast}</div> : null;
  return { notify, el };
}

export function fileToDataUrl(file: File, max = 512): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = reject;
    img.src = url;
  });
}

export function timeOf(iso: string) { return new Date(iso).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }); }
export function dayOf(iso: string) {
  const d = new Date(iso), t = new Date();
  const same = (a: Date, b: Date) => a.toDateString() === b.toDateString();
  if (same(d, t)) return "Bugün";
  const y = new Date(t); y.setDate(t.getDate() - 1);
  if (same(d, y)) return "Dün";
  return d.toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
}
export function duration(sec: number) { const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60); return h ? `${h} sa ${m} dk` : `${m} dk`; }
export function memberSince(iso: string) { const d = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000); return d < 1 ? "Bugün katıldı" : d < 30 ? `${d} gündür üye` : d < 365 ? `${Math.floor(d / 30)} aydır üye` : `${Math.floor(d / 365)} yıldır üye`; }
