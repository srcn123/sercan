import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  timestamp,
  integer,
  index,
  jsonb,
  real,
} from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  key: varchar("key", { length: 48 }).primaryKey(),
  value: text("value").notNull().default(""),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 32 }).notNull().unique(),
  usernameLower: varchar("username_lower", { length: 32 }).notNull().unique(),
  email: varchar("email", { length: 120 }),
  passwordHash: text("password_hash"),
  secretWordHash: text("secret_word_hash"),
  resetCode: varchar("reset_code", { length: 12 }),
  color: varchar("color", { length: 16 }).notNull().default("#6d3bff"),
  nickColor: varchar("nick_color", { length: 16 }),
  textStyle: jsonb("text_style").$type<{ color?: string; bold?: boolean; italic?: boolean; neon?: boolean; gradient?: string; animation?: string }>().notNull().default({}),
  nickEffect: varchar("nick_effect", { length: 16 }).notNull().default("none"),
  avatarFrame: varchar("avatar_frame", { length: 20 }).notNull().default("none"),
  rank: varchar("rank", { length: 16 }).notNull().default("misafir"),
  isGuest: boolean("is_guest").notNull().default(true),
  isDj: boolean("is_dj").notNull().default(false),
  isBot: boolean("is_bot").notNull().default(false),
  botKind: varchar("bot_kind", { length: 16 }),
  botEnabled: boolean("bot_enabled").notNull().default(true),
  botRoomMode: varchar("bot_room_mode", { length: 12 }).notNull().default("all"),
  botRoomId: integer("bot_room_id"),
  isVerified: boolean("is_verified").notNull().default(false),
  theme: varchar("theme", { length: 16 }).notNull().default("mor"),
  status: varchar("status", { length: 80 }).notNull().default(""),
  presence: varchar("presence", { length: 10 }).notNull().default("online"),
  ghostMode: boolean("ghost_mode").notNull().default(false),
  avatarUrl: text("avatar_url"),
  bannerUrl: text("banner_url"),
  country: varchar("country", { length: 40 }).notNull().default(""),
  city: varchar("city", { length: 40 }).notNull().default(""),
  gender: varchar("gender", { length: 10 }).notNull().default(""),
  prefDm: varchar("pref_dm", { length: 10 }).notNull().default("everyone"),
  prefVoice: varchar("pref_voice", { length: 10 }).notNull().default("everyone"),
  prefVideo: varchar("pref_video", { length: 10 }).notNull().default("everyone"),
  prefAudio: varchar("pref_audio", { length: 10 }).notNull().default("everyone"),
  prefImage: varchar("pref_image", { length: 10 }).notNull().default("everyone"),
  prefFollow: varchar("pref_follow", { length: 10 }).notNull().default("everyone"),
  prefNotif: varchar("pref_notif", { length: 10 }).notNull().default("everyone"),
  mood: varchar("mood", { length: 40 }).notNull().default(""),
  about: varchar("about", { length: 300 }).notNull().default(""),
  points: integer("points").notNull().default(0),
  xp: integer("xp").notNull().default(0),
  piggyBank: integer("piggy_bank").notNull().default(0),
  totalMessages: integer("total_messages").notNull().default(0),
  giftsSent: integer("gifts_sent").notNull().default(0),
  giftsReceived: integer("gifts_received").notNull().default(0),
  onlineSeconds: integer("online_seconds").notNull().default(0),
  violations: integer("violations").notNull().default(0),
  mutedUntil: timestamp("muted_until", { withTimezone: true }),
  isBanned: boolean("is_banned").notNull().default(false),
  kickedAt: timestamp("kicked_at", { withTimezone: true }),
  cameraOn: boolean("camera_on").notNull().default(false),
  currentRoomId: integer("current_room_id"),
  typingAt: timestamp("typing_at", { withTimezone: true }),
  typingTarget: varchar("typing_target", { length: 20 }),
  lastWheelAt: timestamp("last_wheel_at", { withTimezone: true }),
  lastPointTickAt: timestamp("last_point_tick_at", { withTimezone: true }),
  lastIp: varchar("last_ip", { length: 64 }),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: varchar("token", { length: 64 }).primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 40 }).notNull(),
  slug: varchar("slug", { length: 48 }).notNull().unique(),
  description: varchar("description", { length: 160 }).notNull().default(""),
  icon: varchar("icon", { length: 8 }).notNull().default("💬"),
  imageUrl: text("image_url"),
  bgUrl: text("bg_url"),
  kind: varchar("kind", { length: 12 }).notNull().default("chat"),
  ownerId: integer("owner_id"),
  isDefault: boolean("is_default").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    roomId: integer("room_id").notNull().references(() => rooms.id, { onDelete: "cascade" }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    username: varchar("username", { length: 32 }).notNull(),
    color: varchar("color", { length: 16 }).notNull(),
    rank: varchar("rank", { length: 16 }).notNull().default("misafir"),
    avatarUrl: text("avatar_url"),
    textStyle: jsonb("text_style").$type<{ color?: string; bold?: boolean; italic?: boolean; neon?: boolean; gradient?: string; animation?: string }>().notNull().default({}),
    content: text("content").notNull(),
    kind: varchar("kind", { length: 12 }).notNull().default("text"),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    whisperTo: integer("whisper_to"),
    deleted: boolean("deleted").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("messages_room_idx").on(t.roomId, t.id)],
);

export const reactions = pgTable(
  "reactions",
  {
    id: serial("id").primaryKey(),
    messageId: integer("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    emoji: varchar("emoji", { length: 8 }).notNull(),
  },
  (t) => [index("reactions_msg_idx").on(t.messageId)],
);

export const privateMessages = pgTable(
  "private_messages",
  {
    id: serial("id").primaryKey(),
    fromUserId: integer("from_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    toUserId: integer("to_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    kind: varchar("kind", { length: 12 }).notNull().default("text"),
    meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
    isRead: boolean("is_read").notNull().default(false),
    viewedAt: timestamp("viewed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("pm_from_to_idx").on(t.fromUserId, t.toUserId, t.id),
    index("pm_to_idx").on(t.toUserId, t.isRead),
  ],
);

export const friendships = pgTable(
  "friendships",
  {
    id: serial("id").primaryKey(),
    requesterId: integer("requester_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    addresseeId: integer("addressee_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    status: varchar("status", { length: 10 }).notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("friend_req_idx").on(t.requesterId), index("friend_addr_idx").on(t.addresseeId)],
);

export const giftLog = pgTable("gift_log", {
  id: serial("id").primaryKey(),
  giftKey: varchar("gift_key", { length: 20 }).notNull(),
  fromUserId: integer("from_user_id").references(() => users.id, { onDelete: "set null" }),
  toUserId: integer("to_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  roomId: integer("room_id"),
  points: integer("points").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const pointLog = pgTable(
  "point_log",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    delta: integer("delta").notNull(),
    reason: varchar("reason", { length: 32 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("pointlog_user_idx").on(t.userId, t.createdAt)],
);

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  key: varchar("key", { length: 32 }).notNull(),
  earnedAt: timestamp("earned_at", { withTimezone: true }).notNull().defaultNow(),
});

export const bans = pgTable("bans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  username: varchar("username", { length: 32 }).notNull(),
  ip: varchar("ip", { length: 64 }),
  reason: varchar("reason", { length: 160 }).notNull().default(""),
  byUsername: varchar("by_username", { length: 32 }).notNull().default("sistem"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  username: varchar("username", { length: 32 }).notNull(),
  ip: varchar("ip", { length: 64 }).notNull().default(""),
  city: varchar("city", { length: 60 }).notNull().default(""),
  country: varchar("country", { length: 60 }).notNull().default(""),
  action: varchar("action", { length: 24 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const wordRules = pgTable("word_rules", {
  id: serial("id").primaryKey(),
  word: varchar("word", { length: 40 }).notNull(),
  replacement: varchar("replacement", { length: 40 }).notNull().default("***"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const djRequests = pgTable("dj_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 32 }).notNull(),
  title: varchar("title", { length: 120 }).notNull(),
  artist: varchar("artist", { length: 120 }).notNull().default(""),
  previewUrl: text("preview_url"),
  artwork: text("artwork"),
  status: varchar("status", { length: 10 }).notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const okeyTables = pgTable("okey_tables", {
  id: integer("id").primaryKey(),
  state: jsonb("state").$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const signals = pgTable(
  "signals",
  {
    id: serial("id").primaryKey(),
    fromUserId: integer("from_user_id").notNull(),
    toUserId: integer("to_user_id").notNull(),
    channel: varchar("channel", { length: 12 }).notNull(),
    type: varchar("type", { length: 12 }).notNull(),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("signals_to_idx").on(t.toUserId, t.id)],
);

export const camViewers = pgTable("cam_viewers", {
  id: serial("id").primaryKey(),
  broadcasterId: integer("broadcaster_id").notNull(),
  viewerId: integer("viewer_id").notNull(),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
});

export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  creatorId: integer("creator_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  creatorName: varchar("creator_name", { length: 32 }).notNull(),
  title: varchar("title", { length: 120 }).notNull(),
  target: integer("target").notNull(),
  progress: integer("progress").notNull().default(0),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const miniGames = pgTable("mini_games", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 12 }).notNull(),
  player1: integer("player1").notNull(),
  player2: integer("player2").notNull(),
  bet: integer("bet").notNull().default(0),
  state: jsonb("state").$type<Record<string, unknown>>().notNull().default({}),
  status: varchar("status", { length: 10 }).notNull().default("pending"),
  winnerId: integer("winner_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const stats = pgTable("stats", {
  key: varchar("key", { length: 32 }).primaryKey(),
  value: integer("value").notNull().default(0),
});

export const streamQuality = pgTable("stream_quality", {
  userId: integer("user_id").primaryKey(),
  latencyMs: real("latency_ms").notNull().default(0),
  bitrateKbps: real("bitrate_kbps").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  title: varchar("title", { length: 120 }).notNull(),
  excerpt: varchar("excerpt", { length: 200 }).notNull().default(""),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  authorId: integer("author_id").references(() => users.id, { onDelete: "set null" }),
  authorName: varchar("author_name", { length: 40 }).notNull().default(""),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const blogComments = pgTable("blog_comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => blogPosts.id, { onDelete: "cascade" }),
  userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
  username: varchar("username", { length: 32 }).notNull(),
  content: varchar("content", { length: 500 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 64 }).notNull().unique(),
  isUsed: boolean("is_used").notNull().default(false),
  usedBy: varchar("used_by", { length: 64 }),
  usedAt: timestamp("used_at", { withTimezone: true }),
  status: varchar("status", { length: 16 }).notNull().default("active"),
  note: text("note").notNull().default(""),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const ranks = pgTable("ranks", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 20 }).notNull().unique(),
  label: varchar("label", { length: 30 }).notNull(),
  level: integer("level").notNull(),
  color: varchar("color", { length: 16 }).notNull(),
  icon: varchar("icon", { length: 8 }).notNull(),
  sprite: integer("sprite").notNull().default(0),
  iconUrl: text("icon_url"),
  perms: jsonb("perms").$type<Record<string, boolean>>().notNull().default({}),
  isDefault: boolean("is_default").notNull().default(false),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const voiceHolders = pgTable("voice_holders", {
  roomId: integer("room_id").primaryKey().references(() => rooms.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 32 }).notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const voiceQueue = pgTable(
  "voice_queue",
  {
    id: serial("id").primaryKey(),
    roomId: integer("room_id").notNull().references(() => rooms.id, { onDelete: "cascade" }),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    username: varchar("username", { length: 32 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("voice_queue_room_idx").on(t.roomId, t.createdAt)],
);

export type User = typeof users.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type PrivateMessage = typeof privateMessages.$inferSelect;
