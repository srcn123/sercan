"use client";
import { useEffect, useState } from "react";
import { RANKS as DEFAULT_RANKS, type RankKey } from "@/lib/constants";

type Rank = { key: string; label: string; level: number; color: string; icon: string; sprite: number; perms: Record<string, boolean> };

export function useRanks() {
  const [ranks, setRanks] = useState<Record<string, Rank>>(DEFAULT_RANKS as unknown as Record<string, Rank>);
  const [order, setOrder] = useState<RankKey[]>(Object.keys(DEFAULT_RANKS) as RankKey[]);

  useEffect(() => {
    const load = async () => {
      try {
        const r = await fetch("/api/ranks", { cache: "no-store" });
        if (!r.ok) return;
        const d = await r.json();
        const list: Rank[] = d.ranks ?? [];
        if (list.length) {
          const map: Record<string, Rank> = {};
          list.forEach((rn) => { map[rn.key] = rn; });
          setRanks(map as Record<string, Rank>);
          setOrder(list.sort((a,b) => b.level - a.level).map((x) => x.key as RankKey));
        }
      } catch {}
    };
    load();
    const t = setInterval(load, 10000);
    return () => clearInterval(t);
  }, []);

  return { ranks, order };
}
