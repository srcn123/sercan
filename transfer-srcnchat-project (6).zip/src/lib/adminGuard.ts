import { getCurrentUser } from "@/lib/auth";
import { PERM, rankLevel } from "@/lib/constants";
export async function adminGuard(founderOnly = false) {
  const me = await getCurrentUser();
  if (!me || rankLevel(me.rank) < PERM.adminPanel) return { me: null, res: Response.json({ error: "Yetkin yok" }, { status: 403 }) };
  if (founderOnly && me.rank !== "kurucu") return { me: null, res: Response.json({ error: "Bu işlem yalnızca Kurucu içindir" }, { status: 403 }) };
  return { me, res: null };
}
