import { cookies, headers } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, bans, pointLog, sessions, settings, users, type User } from "@/db/schema";
import { ACHIEVEMENTS, levelFromXp, SESSION_COOKIE, type AchievementKey } from "./constants";
import { achievements } from "@/db/schema";

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function verifyPassword(password: string, stored: string | null | undefined) {
  if (!stored) return false;
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

export async function getIp() {
  const h = await headers();
  return (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "127.0.0.1").trim();
}

export async function geoLookup(ip: string): Promise<{ city: string; country: string }> {
  if (!ip || ip.startsWith("127.") || ip.startsWith("10.") || ip.startsWith("192.168.") || ip === "::1") {
    return { city: "Yerel", country: "Yerel Ağ" };
  }
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 1500);
    const res = await fetch(`http://ip-api.com/json/${ip}?fields=city,country&lang=tr`, { signal: ctrl.signal });
    clearTimeout(t);
    if (!res.ok) return { city: "", country: "" };
    const d = await res.json();
    return { city: d.city ?? "", country: d.country ?? "" };
  } catch {
    return { city: "", country: "" };
  }
}

export async function logActivity(user: { id: number; username: string }, action: string) {
  const ip = await getIp();
  const geo = await geoLookup(ip);
  await db.insert(activityLog).values({ userId: user.id, username: user.username, ip, ...geo, action });
  await db.update(users).set({ lastIp: ip, ...(geo.city && !user.id ? {} : {}) }).where(eq(users.id, user.id));
  return ip;
}

export async function isIpBanned(ip: string) {
  const [b] = await db.select({ id: bans.id }).from(bans).where(and(eq(bans.ip, ip), eq(bans.active, true))).limit(1);
  return !!b;
}

export async function createSession(userId: number, rememberMe = false) {
  const token = randomBytes(32).toString("hex");
  await db.insert(sessions).values({ token, userId });
  const store = await cookies();
  const maxAge = rememberMe ? 60 * 60 * 24 * 90 : undefined; // 90 gün hatırla, yoksa tarayıcı oturumu
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    ...(maxAge ? { maxAge } : { maxAge: undefined }),
  } as { httpOnly: true; sameSite: "lax"; path: string; maxAge?: number });
  return token;
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, token));
  store.delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<User | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.token, token))
    .limit(1);
  const u = rows[0]?.user ?? null;
  if (u && u.isBanned) return null;
  return u;
}

export async function touchPresence(userId: number, roomId?: number | null) {
  const patch: Partial<typeof users.$inferInsert> = { lastSeen: new Date() };
  if (roomId !== undefined) patch.currentRoomId = roomId;
  await db.update(users).set(patch).where(eq(users.id, userId));
}

export async function addPoints(userId: number, delta: number, reason: string) {
  if (!delta) return;
  await db
    .update(users)
    .set({
      points: sql`greatest(0, ${users.points} + ${delta})`,
      xp: delta > 0 ? sql`${users.xp} + ${delta}` : sql`${users.xp}`,
    })
    .where(eq(users.id, userId));
  await db.insert(pointLog).values({ userId, delta, reason });
}

export async function grantAchievement(userId: number, key: AchievementKey) {
  const [exists] = await db
    .select({ id: achievements.id })
    .from(achievements)
    .where(and(eq(achievements.userId, userId), eq(achievements.key, key)))
    .limit(1);
  if (exists) return false;
  await db.insert(achievements).values({ userId, key });
  return true;
}

export async function getSetting(key: string, fallback = "") {
  const [row] = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return row?.value ?? fallback;
}
export async function getSettings() {
  const rows = await db.select().from(settings);
  return Object.fromEntries(rows.map((r) => [r.key, r.value])) as Record<string, string>;
}
export async function setSetting(key: string, value: string) {
  await db.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
}

export async function isMuted(user: User) {
  return !!user.mutedUntil && user.mutedUntil.getTime() > Date.now();
}

export function publicUser(u: User) {
  return {
    id: u.id,
    username: u.username,
    color: u.color,
    nickColor: u.nickColor,
    textStyle: u.textStyle ?? {},
    nickEffect: (u as unknown as { nickEffect?: string }).nickEffect ?? "none",
    avatarFrame: (u as unknown as { avatarFrame?: string }).avatarFrame ?? "none",
    rank: u.rank,
    isGuest: u.isGuest,
    isDj: u.isDj,
    isBot: u.isBot,
    isVerified: u.isVerified,
    theme: u.theme,
    status: u.status,
    presence: u.presence,
    ghostMode: u.ghostMode,
    avatarUrl: u.avatarUrl,
    bannerUrl: u.bannerUrl,
    gender: (u as unknown as { gender?: string }).gender ?? "",
    prefDm: (u as unknown as { prefDm?: string }).prefDm ?? "everyone",
    prefVoice: (u as unknown as { prefVoice?: string }).prefVoice ?? "everyone",
    prefVideo: (u as unknown as { prefVideo?: string }).prefVideo ?? "everyone",
    prefAudio: (u as unknown as { prefAudio?: string }).prefAudio ?? "everyone",
    prefImage: (u as unknown as { prefImage?: string }).prefImage ?? "everyone",
    prefFollow: (u as unknown as { prefFollow?: string }).prefFollow ?? "everyone",
    prefNotif: (u as unknown as { prefNotif?: string }).prefNotif ?? "everyone",
    country: u.country,
    city: u.city,
    mood: u.mood,
    about: u.about,
    points: u.points,
    xp: u.xp,
    level: levelFromXp(u.xp),
    piggyBank: u.piggyBank,
    totalMessages: u.totalMessages,
    giftsSent: u.giftsSent,
    giftsReceived: u.giftsReceived,
    onlineSeconds: u.onlineSeconds,
    currentRoomId: u.currentRoomId,
    cameraOn: u.cameraOn,
    mutedUntil: u.mutedUntil ? u.mutedUntil.toISOString() : null,
    createdAt: u.createdAt.toISOString(),
    lastWheelAt: u.lastWheelAt ? u.lastWheelAt.toISOString() : null,
  };
}
export type PublicUser = ReturnType<typeof publicUser>;

export const ACH = ACHIEVEMENTS;
export { gt };
