import { db } from "@/db";
import { bans, messages, rooms, users, wordRules, type Room, type User } from "@/db/schema";
import { and, eq, gt, sql } from "drizzle-orm";
import { getSetting, setSetting } from "./auth";

const PROFANITY = ["amk", "aq", "orospu", "piç", "sik", "yarrak", "göt", "amcık", "pezevenk", "kahpe", "ibne"];
const PHONE_RE = /(\+?9?0?\s?5\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2})/g;
const RIVAL_RE = /\b(\w+\.(?:com|net|org|xyz|tv))\b/gi;

// --- flood ---
const floodMap = new Map<number, number[]>();
export function checkFlood(userId: number) {
  const now = Date.now();
  const arr = (floodMap.get(userId) ?? []).filter((t) => now - t < 5000);
  arr.push(now);
  floodMap.set(userId, arr);
  return arr.length > 5;
}

// --- word filter ---
export async function applyFilters(content: string, user: User) {
  let text = content;
  let violation = false;
  const rules = await db.select().from(wordRules);
  for (const r of rules) {
    const re = new RegExp(`\\b${escapeRe(r.word)}\\b`, "gi");
    if (re.test(text)) {
      violation = true;
      text = text.replace(re, r.replacement);
    }
  }
  for (const p of PROFANITY) {
    const re = new RegExp(`\\b${escapeRe(p)}\\w*`, "gi");
    if (re.test(text)) {
      violation = true;
      text = text.replace(re, (m) => m[0] + "*".repeat(Math.max(1, m.length - 1)));
    }
  }
  let smart = false;
  if (PHONE_RE.test(text)) {
    text = text.replace(PHONE_RE, "[numara gizlendi]");
    smart = true;
  }
  if (RIVAL_RE.test(text) && !/youtube\.com|youtu\.be|srcnchat|\.(png|jpg|jpeg|gif|webp)/i.test(text)) {
    text = text.replace(RIVAL_RE, "[reklam engellendi]");
    smart = true;
  }
  void user;
  return { text, violation, smart };
}
function escapeRe(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function botPost(bot: Pick<User, "id" | "username" | "color" | "rank" | "avatarUrl">, roomId: number, content: string, kind = "text", meta: Record<string, unknown> = {}) {
  const [m] = await db
    .insert(messages)
    .values({ roomId, userId: bot.id, username: bot.username, color: bot.color, rank: bot.rank, avatarUrl: bot.avatarUrl, content, kind, meta })
    .returning();
  await db.update(users).set({ lastSeen: new Date(), currentRoomId: roomId }).where(eq(users.id, bot.id));
  return m;
}

export async function getBots() {
  const botsOn = (await getSetting("botsEnabled", "1")) === "1";
  if (!botsOn) return [];
  return db.select().from(users).where(and(eq(users.isBot, true), eq(users.botEnabled, true)));
}

function botActiveInRoom(bot: User, roomId: number) {
  if (bot.botRoomMode === "all" || bot.botRoomMode === "roam") return true;
  return bot.botRoomId === roomId;
}

// --- security bot punishment ---
export async function punish(user: User, roomId: number, reason: string) {
  const bots = await getBots();
  const guards = bots.filter((b) => b.botKind === "security" && botActiveInRoom(b, roomId));
  const muteMin = Number(await getSetting("securityMuteMinutes", "5")) || 5;
  const banAfter = Number(await getSetting("securityBanAfter", "5")) || 5;
  const violations = user.violations + 1;
  const until = new Date(Date.now() + muteMin * 60000);
  await db.update(users).set({ violations, mutedUntil: until }).where(eq(users.id, user.id));
  const guard = guards[0];
  if (violations >= banAfter) {
    await db.update(users).set({ isBanned: true }).where(eq(users.id, user.id));
    await db.insert(bans).values({ userId: user.id, username: user.username, ip: user.lastIp, reason: `Güvenlik botu: ${violations} ihlal`, byUsername: guard?.username ?? "Güvenlik" });
    if (guard) await botPost(guard, roomId, `🚫 ${user.username} ${violations}. ihlalinden sonra siteden yasaklandı.`, "system");
    return "banned";
  }
  if (guard) await botPost(guard, roomId, `🛡 ${user.username}, ${reason}. ${muteMin} dakika susturuldun (${violations}/${banAfter} ihlal).`, "system");
  return "muted";
}

// --- Nova ---
const RULES: [RegExp, string | ((m: RegExpMatchArray) => string)][] = [
  [/merhaba|selam|hey|günaydın|iyi akşamlar/i, "Merhaba! 👋 Ben Nova. Sana nasıl yardımcı olabilirim?"],
  [/nasılsın|naber|ne haber/i, "Harikayım, teşekkürler! Sen nasılsın? 😊"],
  [/saat kaç/i, () => `Şu an saat ${new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" })} (İstanbul).`],
  [/tarih|bugün günlerden/i, () => `Bugün ${new Date().toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}.`],
  [/adın ne|sen kimsin|kimsin/i, "Ben Nova, SrcnChat'in yapay zekâ asistanıyım. ✨"],
  [/puan|nasıl puan/i, "Oda mesajı +1, özel mesaj +2, her 2 dakika çevrimiçi +5, okey bitirme +25 puan kazandırır. Günlük çarkı da unutma! 🎡"],
  [/rütbe|yetki/i, "Rütbeler: Kurucu > Admin > Operatör > Yrd. Operatör > VIP > Üye > Misafir. Aktif olup yöneticilerin dikkatini çek! 👑"],
  [/hediye/i, "12 farklı hediye var: Gül (10 puan) ile başlar, Saray (5000 puan) ile biter. Bir kullanıcının künyesinden gönderebilirsin 🎁"],
  [/okey/i, "Okey Salonu'nda 3 masa var. 106 taş, gösterge, okey ve sahte okey ile gerçek kurallar! 🀄"],
  [/radyo|müzik|şarkı/i, "Radyoyu sağ üstten açabilirsin. Müzik odasında şarkı adı yazarsan DJ botu çalar 🎧"],
  [/teşekkür|sağol|eyvallah/i, "Rica ederim! Her zaman buradayım 💜"],
  [/şaka|fıkra|güldür/i, "Programcı neden karanlıkta çalışır? Çünkü ışık bug'ları çeker! 😄"],
  [/(\d+)\s*([+\-*/x])\s*(\d+)/, (m) => {
    const a = Number(m[1]), b = Number(m[3]);
    const op = m[2] === "x" ? "*" : m[2];
    const r = op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : b === 0 ? NaN : a / b;
    return Number.isNaN(r) ? "Sıfıra bölemem 😅" : `${a} ${op} ${b} = ${r}`;
  }],
  [/hava/i, "Hava durumuna erişimim yok ama içerisi sıcacık, sohbet var ☀️"],
  [/seviyorum|aşk/i, "Aww 💕 Sohbette aşk da var demek!"],
  [/görüşürüz|bay bay|hoşçakal/i, "Görüşmek üzere! Tekrar beklerim 👋"],
];

export async function novaReply(prompt: string, username: string): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (key) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          messages: [
            { role: "system", content: "Sen Nova'sın: SrcnChat adlı Türkçe sohbet sitesinin samimi, kısa ve esprili yapay zekâ asistanısın. En fazla 3 cümle yaz, emoji kullanabilirsin." },
            { role: "user", content: `${username}: ${prompt}` },
          ],
          max_tokens: 200,
          temperature: 0.8,
        }),
      });
      if (res.ok) {
        const d = await res.json();
        const text = d.choices?.[0]?.message?.content?.trim();
        if (text) return text;
      }
    } catch {
      /* fall through */
    }
  }
  for (const [re, ans] of RULES) {
    const m = prompt.match(re);
    if (m) return typeof ans === "function" ? ans(m) : ans;
  }
  const generic = [
    `İlginç bir konu ${username}! Biraz daha açar mısın? 🤔`,
    "Bunu düşünmem gerekti… Sence en önemli kısmı ne?",
    "Anladım! Başka ne sormak istersin? ✨",
    `"${prompt.slice(0, 40)}" hakkında elimde çok bilgi yok ama sohbete devam edelim 💜`,
  ];
  return generic[prompt.length % generic.length];
}

export async function translateText(text: string, target: string) {
  const key = process.env.OPENAI_API_KEY;
  if (key) {
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4o-mini", messages: [{ role: "system", content: `Translate the user's message to ${target}. Reply only with the translation.` }, { role: "user", content: text }], max_tokens: 300 }),
      });
      if (res.ok) {
        const d = await res.json();
        const t = d.choices?.[0]?.message?.content?.trim();
        if (t) return t;
      }
    } catch {}
  }
  try {
    const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=tr|${encodeURIComponent(target)}`);
    if (res.ok) {
      const d = await res.json();
      return (d.responseData?.translatedText as string) || text;
    }
  } catch {}
  return text;
}

// --- YouTube full-song search (fallback iTunes) — for DJ bot & /api/music/search
export async function searchYoutube(q: string): Promise<{ title: string; artist: string; youtubeId: string; artwork?: string } | null> {
  const { searchYoutubeFull } = await import("./ytSearch");
  return searchYoutubeFull(q);
}
export async function searchTrack(q: string) {
  try {
    const res = await fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&limit=1&country=tr`);
    if (!res.ok) return null;
    const d = await res.json();
    const r = d.results?.[0];
    if (!r) return null;
    return { title: r.trackName as string, artist: r.artistName as string, previewUrl: r.previewUrl as string, artwork: (r.artworkUrl100 as string)?.replace("100x100", "300x300") };
  } catch {
    return null;
  }
}

export async function setNowPlaying(track: { title: string; artist: string; previewUrl?: string | null; artwork?: string | null }, djName: string, djId: number | null) {
  await setSetting("nowPlaying", JSON.stringify({ ...track, djName, djId, startedAt: Date.now() }));
}

// --- main dispatch after a user message ---
export async function handleBots(room: Room, msg: { content: string; username: string; userId: number }, user: User) {
  const bots = await getBots();
  for (const bot of bots) {
    if (!botActiveInRoom(bot, room.id)) continue;
    if (bot.botKind === "nova" && (room.kind === "ai" || bot.botRoomMode !== "fixed")) {
      if (room.kind !== "ai" && !new RegExp(`@?${bot.username}`, "i").test(msg.content)) continue;
      const reply = await novaReply(msg.content.replace(new RegExp(`@?${bot.username}`, "ig"), "").trim(), msg.username);
      await botPost(bot, room.id, `@${msg.username} ${reply}`);
    }
    if (bot.botKind === "user" && botActiveInRoom(bot, room.id)) {
      // kullanıcı gibi bot — rastgele samimi cevaplar
      if (Math.random() < 0.18 && msg.content.length > 6 && !msg.content.startsWith("/")) {
        const replies = ["Harika söyledin! 👏", `Katılıyorum ${msg.username} 😊`, "Aynen öyle!", "Bunu ben de düşünmüştüm 🤔", `${msg.username} haklısın!`, "Devam et, dinliyorum 👀"];
        await botPost(bot, room.id, replies[Math.floor(Math.random() * replies.length)]);
      }
    }
    if (bot.botKind === "dj" && room.kind === "music") {
      const q = msg.content.trim();
      if (q.length < 3 || q.startsWith("/")) continue;
      const ytLink = q.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
      if (ytLink) {
        const yt = { title: "YouTube", artist: msg.username, youtubeId: ytLink[1] };
        await setNowPlaying(yt, bot.username, bot.id);
        await botPost(bot, room.id, `🎧 Şimdi çalıyor: YouTube tam sürüm ▶ (istek: ${msg.username})`, "nowplaying", yt);
        continue;
      }
      const yt = await searchYoutube(q);
      if (yt) {
        await setNowPlaying(yt, bot.username, bot.id);
        await botPost(bot, room.id, `🎧 Şimdi çalıyor: ${yt.title} — ${yt.artist} (istek: ${msg.username}) 🎬 TAM SÜRÜM`, "nowplaying", yt);
      } else {
        // demo değil — tam sürüm bulunamadıysa YouTube link iste
        await botPost(bot, room.id, `@${msg.username} "${q}" için tam sürüm bulunamadı — lütfen YouTube linkini yapıştır (youtu.be/...) tam çalınsın 🎵`);
      }
    }
  }
  void user;
}

// --- radio now playing (external) ---
export async function fetchRadioNowPlaying(np: string): Promise<{ title: string; artist: string; artwork?: string } | null> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 2500);
    if (np.startsWith("rp:")) {
      const chan = np.split(":")[1];
      const res = await fetch(`https://api.radioparadise.com/api/now_playing?chan=${chan}`, { signal: ctrl.signal });
      clearTimeout(t);
      if (!res.ok) return null;
      const d = await res.json();
      return { title: d.title, artist: d.artist, artwork: d.cover };
    }
    if (np.startsWith("soma:")) {
      const ch = np.split(":")[1];
      const res = await fetch(`https://somafm.com/songs/${ch}.json`, { signal: ctrl.signal });
      clearTimeout(t);
      if (!res.ok) return null;
      const d = await res.json();
      const s = d.songs?.[0];
      return s ? { title: s.title, artist: s.artist } : null;
    }
  } catch {}
  return null;
}

export async function announceRadioTrack(track: { title: string; artist: string }) {
  const last = await getSetting("lastRadioTrack");
  const sig = `${track.artist} - ${track.title}`;
  if (last === sig) return;
  await setSetting("lastRadioTrack", sig);
  const [radioRoom] = await db.select().from(rooms).where(eq(rooms.kind, "radio")).limit(1);
  if (!radioRoom) return;
  const [bot] = await db.select().from(users).where(eq(users.botKind, "dj")).limit(1);
  const poster = bot ?? { id: null, username: "Radyo", color: "#f59e0b", rank: "vip", avatarUrl: null };
  await db.insert(messages).values({ roomId: radioRoom.id, userId: poster.id, username: poster.username, color: poster.color, rank: poster.rank, avatarUrl: poster.avatarUrl, content: `📻 Radyoda şimdi: ${sig}`, kind: "nowplaying", meta: track });
}

export const recentlyActive = (sec: number) => gt(users.lastSeen, sql`now() - interval '${sql.raw(String(sec))} seconds'`);
