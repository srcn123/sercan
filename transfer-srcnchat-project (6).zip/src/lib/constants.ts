export const AVATAR_COLORS = [
  "#6d3bff",
  "#1e90ff",
  "#22b14c",
  "#ff7a1a",
  "#d946ef",
  "#06b6d4",
  "#ef4444",
  "#a21caf",
  "#38bdf8",
  "#4ade80",
  "#fbbf24",
  "#f472b6",
  "#6366f1",
  "#14b8a6",
  "#fb7185",
  "#a78bfa",
] as const;

export const RANKS = {
  kurucu: { label: "Kurucu", level: 6, color: "#a855f7", icon: "♛", sprite: 0 },
  admin: { label: "Admin", level: 5, color: "#ef4444", icon: "⚑", sprite: 1 },
  operator: { label: "Operatör", level: 4, color: "#06b6d4", icon: "★", sprite: 2 },
  yrdoperator: { label: "Yrd. Operatör", level: 3, color: "#3b82f6", icon: "◆", sprite: 3 },
  vip: { label: "VIP", level: 2, color: "#f59e0b", icon: "✦", sprite: 4 },
  uye: { label: "Üye", level: 1, color: "#22c55e", icon: "●", sprite: 5 },
  misafir: { label: "Misafir", level: 0, color: "#94a3b8", icon: "○", sprite: 6 },
} as const;
export type RankKey = keyof typeof RANKS;
export const RANK_ORDER: RankKey[] = ["kurucu", "admin", "operator", "yrdoperator", "vip", "uye", "misafir"];
export function rankInfo(rank: string) {
  return RANKS[(rank as RankKey) in RANKS ? (rank as RankKey) : "misafir"];
}
export function rankLevel(rank: string) {
  return rankInfo(rank).level;
}
export const PERM = {
  mute: 3,
  kick: 3,
  deleteMsg: 4,
  ban: 4,
  clearRoom: 5,
  createRoom: 6,
  adminPanel: 5,
};

export const MUTE_DURATIONS = [
  { label: "1 dk", minutes: 1 },
  { label: "5 dk", minutes: 5 },
  { label: "15 dk", minutes: 15 },
  { label: "60 dk", minutes: 60 },
  { label: "1 gün", minutes: 1440 },
];

export const THEMES = [
  { key: "mor", label: "Mor Gece", desc: "Kadife mor, neon vurgu", swatch: ["#6d3bff", "#ede9fe"], bg: "linear-gradient(135deg,#6d3bff,#22d3c5)" },
  { key: "okyanus", label: "Okyanus", desc: "Derin mavi, turkuaz sis", swatch: ["#0e7490", "#cffafe"], bg: "linear-gradient(135deg,#0e7490,#06b6d4)" },
  { key: "zumrut", label: "Zümrüt", desc: "Orman yeşili, bal ışıltısı", swatch: ["#065f46", "#d1fae5"], bg: "linear-gradient(135deg,#065f46,#10b981)" },
  { key: "gunbatimi", label: "Gün Batımı", desc: "Kor alev, geceye geçiş", swatch: ["#c2410c", "#ffedd5"], bg: "linear-gradient(135deg,#c2410c,#f97316)" },
  { key: "yakut", label: "Yakut", desc: "Kadife bordo, gül vurgu", swatch: ["#9f1239", "#ffe4e6"], bg: "linear-gradient(135deg,#9f1239,#e11d48)" },
  { key: "altin", label: "Altın", desc: "Saray sarısı, bal parıltı", swatch: ["#92400e", "#fef3c7"], bg: "linear-gradient(135deg,#92400e,#d97706)" },
  { key: "geceyarisi", label: "Gece Yarısı", desc: "Zifiri lacivert, mor nebula", swatch: ["#4c1d95", "#1e1b4b"], bg: "linear-gradient(135deg,#1e1b4b,#7c3aed)" },
  { key: "pembe", label: "Pembe Şeker", desc: "Pamuk şeker, leylak", swatch: ["#db2777", "#fce7f3"], bg: "linear-gradient(135deg,#db2777,#f472b6)" },
  { key: "sis", label: "Gece Sisi", desc: "Çelik gri, sisli gece", swatch: ["#334155", "#1e293b"], bg: "linear-gradient(135deg,#334155,#0f172a)" },
  { key: "gunduz", label: "Gündüz", desc: "Bembeyaz, gökyüzü mavi", swatch: ["#1d4ed8", "#dbeafe"], bg: "linear-gradient(135deg,#1d4ed8,#60a5fa)" },
  { key: "volkan", label: "Volkan", desc: "Lav kırmızısı, köz parıltısı", swatch: ["#7f1d1d", "#fee2e2"], bg: "linear-gradient(135deg,#7f1d1d,#f97316)" },
  { key: "buz", label: "Buz Kristali", desc: "Kutup mavisi, buz ışıltısı", swatch: ["#0c4a6e", "#e0f2fe"], bg: "linear-gradient(135deg,#0c4a6e,#38bdf8)" },
  { key: "orman", label: "Orman", desc: "Yosun yeşili, altın yaprak", swatch: ["#14532d", "#dcfce7"], bg: "linear-gradient(135deg,#14532d,#22c55e)" },
  { key: "lavanta", label: "Lavanta", desc: "Derin mor, lila sis", swatch: ["#581c87", "#f3e8ff"], bg: "linear-gradient(135deg,#581c87,#c084fc)" },
  { key: "grafit", label: "Grafit", desc: "Antrasit, amber vurgu", swatch: ["#27272a", "#3f3f46"], bg: "linear-gradient(135deg,#18181b,#52525b)" },
  { key: "mercankopugu", label: "Mercan Köpüğü", desc: "Mercan pembesi, şeftali", swatch: ["#be123c", "#ffe4e6"], bg: "linear-gradient(135deg,#be123c,#fb7185)" },
  { key: "safir", label: "Safir", desc: "Gece laciverti, safir ışıltı", swatch: ["#1e3a8a", "#dbeafe"], bg: "linear-gradient(135deg,#1e3a8a,#60a5fa)" },
  { key: "citrus", label: "Narenciye", desc: "Limon sarısı, yeşil vurgu", swatch: ["#a16207", "#fef9c3"], bg: "linear-gradient(135deg,#a16207,#84cc16)" },
] as const;
export type ThemeKey = (typeof THEMES)[number]["key"];

export const AVATAR_FRAMES = [
  { id: "none", name: "Yok", css: "", preview: "○", unlockLevel: 1 },
  { id: "halo", name: "Hale", css: "0 0 0 3px #fbbf24, 0 0 12px 4px rgba(251,191,36,0.6)", preview: "◎", unlockLevel: 2 },
  { id: "neon-cyan", name: "Neon Camgöbeği", css: "0 0 0 2px #06b6d4, 0 0 10px 3px #06b6d4, 0 0 20px 6px rgba(6,182,214,0.5)", preview: "◉", unlockLevel: 5 },
  { id: "neon-pink", name: "Neon Pembe", css: "0 0 0 2px #ec4899, 0 0 12px 4px #ec4899, 0 0 24px 8px rgba(236,72,153,0.45)", preview: "◉", unlockLevel: 5 },
  { id: "gold", name: "Altın Taç", css: "0 0 0 3px #f59e0b, 0 0 0 6px #78350f, 0 6px 12px rgba(0,0,0,0.3)", preview: "⬢", unlockLevel: 8 },
  { id: "diamond", name: "Elmas", css: "0 0 0 2px #e0f2fe, 0 0 8px 2px #38bdf8, 0 0 16px 6px rgba(56,189,248,0.5), inset 0 0 8px rgba(255,255,255,0.8)", preview: "◇", unlockLevel: 12 },
  { id: "fire", name: "Alev", css: "0 0 0 2px #ef4444, 0 0 10px 3px #f97316, 0 0 20px 8px rgba(239,68,68,0.5)", preview: "🔥", unlockLevel: 15 },
  { id: "galaxy", name: "Galaksi", css: "0 0 0 2px #a855f7, 0 0 12px 4px #7c3aed, 0 0 24px 8px rgba(124,58,237,0.6)", preview: "✦", unlockLevel: 18 },
  { id: "rainbow", name: "Gökkuşağı", css: "0 0 0 3px transparent, 0 0 0 6px conic-gradient(from 0deg, #ef4444, #f59e0b, #22c55e, #06b6d4, #a855f7, #ec4899, #ef4444)", preview: "🌈", unlockLevel: 10 },
  { id: "crystal", name: "Kristal Buz", css: "0 0 0 2px #bae6fd, 0 0 10px 3px #0ea5e9, 0 0 0 5px rgba(14,165,233,0.2), inset 0 0 10px rgba(255,255,255,0.6)", preview: "❄", unlockLevel: 7 },
  { id: "emerald", name: "Zümrüt", css: "0 0 0 2px #10b981, 0 0 8px 3px #065f46, 0 4px 12px rgba(16,185,129,0.4)", preview: "⬣", unlockLevel: 6 },
  { id: "shadow", name: "Gölge Kral", css: "0 0 0 2px #1f2937, 0 6px 16px rgba(0,0,0,0.5), 0 0 16px 4px rgba(0,0,0,0.3)", preview: "⬛", unlockLevel: 20 },
] as const;

export const NICK_EFFECTS = [
  { id: "none", name: "Düz", css: "", preview: "Abc", unlockLevel: 1 },
  { id: "neon", name: "Neon Parıltı", css: "0 0 6px currentColor, 0 0 12px currentColor, 0 0 20px currentColor", preview: "Neon", unlockLevel: 3 },
  { id: "shadow", name: "Gölgeli", css: "2px 2px 0 rgba(0,0,0,0.3), 4px 4px 8px rgba(0,0,0,0.2)", preview: "Gölge", unlockLevel: 2 },
  { id: "glow-pulse", name: "Nabız Neon", css: "0 0 8px currentColor, 0 0 16px currentColor", preview: "Nabız", unlockLevel: 8, animated: true },
  { id: "rainbow-anim", name: "Gökkuşağı Akış", css: "", preview: "🌈", unlockLevel: 12, gradient: "linear-gradient(90deg, #ef4444, #f59e0b, #22c55e, #06b6d4, #a855f7, #ef4444)", animated: true },
  { id: "fire-text", name: "Ateş Yazı", css: "0 0 4px #ff6b00, 0 0 10px #ff3300, 0 2px 4px rgba(0,0,0,0.5)", preview: "Ateş", unlockLevel: 10 },
  { id: "ice", name: "Buz Kristal", css: "0 0 6px #38bdf8, 0 0 12px #0ea5e9, 0 1px 2px rgba(255,255,255,0.8)", preview: "Buz", unlockLevel: 7 },
  { id: "gold-shine", name: "Altın Işıltı", css: "0 0 8px #fbbf24, 0 0 16px #f59e0b, 0 1px 1px rgba(0,0,0,0.3)", preview: "Altın", unlockLevel: 9 },
] as const;

export function getLevelStyle(level: number) {
  // Her seviye kendi rengini ve efektini alır — 1-100 arası spektrum
  if (level >= 50) return { color: "#f59e0b", bg: "linear-gradient(135deg, #f59e0b, #ef4444)", glow: "0 0 12px rgba(245,158,11,0.8), 0 0 24px rgba(239,68,68,0.5)", label: "EFSANE" };
  if (level >= 35) return { color: "#a855f7", bg: "linear-gradient(135deg, #a855f7, #ec4899)", glow: "0 0 10px rgba(168,85,247,0.7)", label: "DESTANSI" };
  if (level >= 25) return { color: "#06b6d4", bg: "linear-gradient(135deg, #06b6d4, #3b82f6)", glow: "0 0 10px rgba(6,182,214,0.6)", label: "USTA" };
  if (level >= 15) return { color: "#10b981", bg: "linear-gradient(135deg, #10b981, #06b6d4)", glow: "0 0 8px rgba(16,185,129,0.5)", label: "UZMAN" };
  if (level >= 10) return { color: "#f97316", bg: "linear-gradient(135deg, #f97316, #f59e0b)", glow: "0 0 8px rgba(249,115,22,0.5)", label: "DENEYİMLİ" };
  if (level >= 5) return { color: "#0ea5e9", bg: "linear-gradient(135deg, #0ea5e9, #6366f1)", glow: "0 0 6px rgba(14,165,233,0.4)", label: "AKTİF" };
  return { color: "#94a3b8", bg: "#94a3b8", glow: "none", label: "YENİ" };
}

export const GIFTS = [
  { key: "gul", name: "Gül", points: 10, sprite: 0, emoji: "🌹" },
  { key: "cikolata", name: "Çikolata", points: 25, sprite: 1, emoji: "🍫" },
  { key: "ayi", name: "Peluş Ayı", points: 50, sprite: 2, emoji: "🧸" },
  { key: "kahve", name: "Türk Kahvesi", points: 75, sprite: 3, emoji: "☕" },
  { key: "balon", name: "Kalp Balon", points: 100, sprite: 4, emoji: "🎈" },
  { key: "pasta", name: "Pasta", points: 150, sprite: 5, emoji: "🎂" },
  { key: "yuzuk", name: "Pırlanta Yüzük", points: 300, sprite: 6, emoji: "💍" },
  { key: "araba", name: "Spor Araba", points: 500, sprite: 7, emoji: "🏎️" },
  { key: "tac", name: "Altın Taç", points: 1000, sprite: 8, emoji: "👑" },
  { key: "roket", name: "Roket", points: 1500, sprite: 9, emoji: "🚀" },
  { key: "yat", name: "Yat", points: 2500, sprite: 10, emoji: "🛥️" },
  { key: "saray", name: "Saray", points: 5000, sprite: 11, emoji: "🏰" },
] as const;
export type GiftKey = (typeof GIFTS)[number]["key"];

export const GENDERS = [
  { id: "", label: "Belirtme", icon: "○", color: "#94a3b8" },
  { id: "kadin", label: "Kadın", icon: "♀", color: "#ec4899" },
  { id: "erkek", label: "Erkek", icon: "♂", color: "#3b82f6" },
  { id: "diger", label: "Diğer", icon: "⚧", color: "#a855f7" },
] as const;
export type GenderId = (typeof GENDERS)[number]["id"];
export function genderInfo(id: string) { return GENDERS.find((g) => g.id === id) ?? GENDERS[0]; }

export const COUNTRIES = [
  { code: "", name: "Belirtme", flag: "🌍" },
  { code: "TR", name: "Türkiye", flag: "🇹🇷" },
  { code: "DE", name: "Almanya", flag: "🇩🇪" },
  { code: "US", name: "Amerika", flag: "🇺🇸" },
  { code: "GB", name: "İngiltere", flag: "🇬🇧" },
  { code: "FR", name: "Fransa", flag: "🇫🇷" },
  { code: "NL", name: "Hollanda", flag: "🇳🇱" },
  { code: "AZ", name: "Azerbaycan", flag: "🇦🇿" },
  { code: "KZ", name: "Kazakistan", flag: "🇰🇿" },
  { code: "UZ", name: "Özbekistan", flag: "🇺🇿" },
  { code: "RU", name: "Rusya", flag: "🇷🇺" },
  { code: "SA", name: "Suudi Arabistan", flag: "🇸🇦" },
  { code: "AE", name: "BAE", flag: "🇦🇪" },
  { code: "IQ", name: "Irak", flag: "🇮🇶" },
  { code: "SY", name: "Suriye", flag: "🇸🇾" },
  { code: "EG", name: "Mısır", flag: "🇪🇬" },
  { code: "GR", name: "Yunanistan", flag: "🇬🇷" },
  { code: "IT", name: "İtalya", flag: "🇮🇹" },
  { code: "ES", name: "İspanya", flag: "🇪🇸" },
  { code: "SE", name: "İsveç", flag: "🇸🇪" },
  { code: "CH", name: "İsviçre", flag: "🇨🇭" },
  { code: "CA", name: "Kanada", flag: "🇨🇦" },
  { code: "AU", name: "Avustralya", flag: "🇦🇺" },
  { code: "JP", name: "Japonya", flag: "🇯🇵" },
  { code: "KR", name: "G. Kore", flag: "🇰🇷" },
  { code: "CN", name: "Çin", flag: "🇨🇳" },
  { code: "BR", name: "Brezilya", flag: "🇧🇷" },
] as const;
export function countryFlag(code: string) { return COUNTRIES.find((c) => c.code === code || c.name === code)?.flag ?? (code ? "🏳️" : ""); }
export function countryInfo(codeOrName: string) { return COUNTRIES.find((c) => c.code === codeOrName || c.name === codeOrName) ?? null; }

export const ACHIEVEMENTS = {
  ilk_mesaj: { name: "İlk Söz", desc: "İlk mesajını gönderdin", icon: "✍️", bubble: null },
  ilk_hediye: { name: "Cömert Kalp", desc: "İlk hediyeni gönderdin", icon: "🎁", bubble: "#f472b6" },
  gece_kusu: { name: "Gece Kuşu", desc: "Gece 02:00-05:00 arasında yazdın", icon: "🦉", bubble: "#6366f1" },
  sohbet_100: { name: "Konuşkan", desc: "100 mesaj gönderdin", icon: "💬", bubble: "#06b6d4" },
  sohbet_1000: { name: "Efsane", desc: "1000 mesaj gönderdin", icon: "🏆", bubble: "#f59e0b" },
  dost_10: { name: "Sosyal Kelebek", desc: "10 arkadaş edindin", icon: "🦋", bubble: "#22c55e" },
  okey_kazan: { name: "Okey Ustası", desc: "Bir okey eli bitirdin", icon: "🎲", bubble: "#ef4444" },
  cark_7: { name: "Sadık", desc: "7 kez çark çevirdin", icon: "🎡", bubble: null },
  seviye_10: { name: "Onuncu Kat", desc: "10. seviyeye ulaştın", icon: "⭐", bubble: "#a855f7" },
  dogrulandi: { name: "Mavi Tık", desc: "Profilini doğruladın", icon: "✅", bubble: "#2563eb" },
} as const;
export type AchievementKey = keyof typeof ACHIEVEMENTS;

export const RADIO_STATIONS = [
  { id: "paradise", name: "Radio Paradise", genre: "Eclectic Mix", url: "https://stream.radioparadise.com/mp3-128", np: "rp:0" },
  { id: "paradise-mellow", name: "RP Mellow", genre: "Chill", url: "https://stream.radioparadise.com/mellow-128", np: "rp:1" },
  { id: "paradise-rock", name: "RP Rock", genre: "Rock", url: "https://stream.radioparadise.com/rock-128", np: "rp:2" },
  { id: "soma-groove", name: "Groove Salad", genre: "Ambient / Downtempo", url: "https://ice1.somafm.com/groovesalad-128-mp3", np: "soma:groovesalad" },
  { id: "soma-lush", name: "Lush", genre: "Vocal Electronica", url: "https://ice1.somafm.com/lush-128-mp3", np: "soma:lush" },
  { id: "soma-dronezone", name: "Drone Zone", genre: "Ambient", url: "https://ice1.somafm.com/dronezone-128-mp3", np: "soma:dronezone" },
] as const;

export const EMOJIS =
  "😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 🥲 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 🤯 🤠 🥳 🥸 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 💩 🤡 👹 👺 👻 👽 🤖 😺 😸 😹 😻 😼 😽 🙀 😿 😾 👋 🤚 ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 💪 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 🔥 ✨ 🌟 💫 ⭐ 🎉 🎊 🎈 🎁 🏆 🥇 🎵 🎶 🎧 🎮 🎲 ☕ 🍕 🍔 🍟 🌹 🌸 🌺 🌈 ☀️ 🌙 ⚡ ❄️ 🚀 🚗 ✈️ 🏠 💎 👑 💰 📻 📷 🔒 ✅ ❌ ⚠️ 💯 🆗 🆒 🇹🇷".split(" ");

export const REACTION_EMOJIS = ["👍", "❤️", "😂", "🔥", "😮"];

export const USERNAME_REGEX = /^[A-Za-zÇĞİÖŞÜçğıöşü0-9 ._-]{2,18}$/;
export const USERNAME_HINT = "Kullanıcı adı 2-18 karakter olmalı ve yalnızca harf, sayı, boşluk, nokta, tire içerebilir.";

export const ONLINE_WINDOW_MS = 45_000;
export const SESSION_COOKIE = "srcn_session";
export const WELCOME_BONUS = 100;
export const POINTS = { roomMsg: 1, dm: 2, onlineTick: 5, okeyWin: 25, okeyPairWin: 50, whisperCost: 5 };

export function levelFromXp(xp: number) {
  return Math.floor(Math.sqrt(Math.max(0, xp) / 100)) + 1;
}
export function xpForLevel(level: number) {
  return (level - 1) * (level - 1) * 100;
}

export const OKEY_TABLE_COUNT = 3;

export const TRIVIA = [
  { q: "Türkiye'nin başkenti neresidir?", a: ["Ankara", "İstanbul", "İzmir", "Bursa"], c: 0 },
  { q: "Bir okey setinde kaç taş vardır?", a: ["104", "106", "108", "100"], c: 1 },
  { q: "Dünyanın en büyük okyanusu?", a: ["Atlantik", "Hint", "Pasifik", "Arktik"], c: 2 },
  { q: "Işık hızı yaklaşık kaç km/sn?", a: ["300.000", "150.000", "1.000.000", "30.000"], c: 0 },
  { q: "İstiklal Marşı'nın yazarı kimdir?", a: ["Nazım Hikmet", "Mehmet Akif Ersoy", "Yahya Kemal", "Orhan Veli"], c: 1 },
  { q: "En küçük asal sayı?", a: ["0", "1", "2", "3"], c: 2 },
  { q: "Güneş sistemindeki en büyük gezegen?", a: ["Satürn", "Jüpiter", "Neptün", "Dünya"], c: 1 },
  { q: "Suyun kimyasal formülü?", a: ["CO2", "H2O", "O2", "NaCl"], c: 1 },
];
export const WORD_GUESS = ["kalem", "radyo", "sohbet", "istanbul", "gitar", "deniz", "bulut", "kahve", "pencere", "yıldız"];
export const TRUTH_DARE = {
  truth: ["En büyük korkun ne?", "Son söylediğin yalan neydi?", "Gizli bir yeteneğin var mı?", "En utandığın anın?"],
  dare: ["Odaya bir şiir yaz", "5 emoji ile kendini anlat", "Bir şarkı sözü yaz", "Herkese iltifat et"],
};
