import { db } from "@/db";
import { licenses } from "@/db/schema";
import { eq } from "drizzle-orm";

export function normalizeKey(k: string) {
  return k.trim().toUpperCase().replace(/\s+/g, "");
}

export async function validateLicense(key: string): Promise<{ valid: boolean; reason?: string }> {
  const norm = normalizeKey(key);
  if (!norm) return { valid: false, reason: "Lisans anahtarı boş" };
  const [row] = await db.select().from(licenses).where(eq(licenses.key, norm)).limit(1);
  if (!row) return { valid: false, reason: "Geçersiz lisans anahtarı" };
  if (row.isUsed) return { valid: false, reason: "Bu lisans zaten kullanıldı" };
  return { valid: true };
}

export async function consumeLicense(key: string, usedBy: string) {
  const norm = normalizeKey(key);
  await db.update(licenses).set({ isUsed: true, usedBy, usedAt: new Date() }).where(eq(licenses.key, norm));
}

export function isLicenseRequired(): boolean {
  // if already installed, don't require unless env forces
  return process.env.REQUIRE_LICENSE !== "0";
}
