// Okey engine — pure functions over a JSON state
export type Tile = { id: number; color: 0 | 1 | 2 | 3; num: number; fake?: boolean }; // num 1..13, fake okey num=0
export type Seat = { userId: number; username: string; color: string; rack: (Tile | null)[]; drawn: boolean };
export type OkeyState = {
  seats: (Seat | null)[]; // 4
  deck: Tile[];
  indicator: Tile | null;
  okey: { color: number; num: number } | null;
  discards: Tile[][]; // per seat, top = last
  turn: number; // seat index
  phase: "waiting" | "playing" | "finished";
  winner?: { userId: number; username: string; pairs: boolean };
  log: string[];
  spectators: number[];
  chat: { user: string; text: string; t: number }[];
  startedAt?: number;
};

export const COLORS = ["#e11d48", "#2563eb", "#111827", "#f59e0b"]; // kırmızı, mavi, siyah, sarı
export const RACK_SIZE = 26;

export function emptyState(): OkeyState {
  return { seats: [null, null, null, null], deck: [], indicator: null, okey: null, discards: [[], [], [], []], turn: 0, phase: "waiting", log: [], spectators: [], chat: [] };
}

export function normalize(raw: Record<string, unknown>): OkeyState {
  if (!raw || !Array.isArray(raw.seats)) return emptyState();
  return raw as unknown as OkeyState;
}

function buildDeck(): Tile[] {
  const deck: Tile[] = [];
  let id = 1;
  for (let copy = 0; copy < 2; copy++)
    for (let c = 0; c < 4; c++)
      for (let n = 1; n <= 13; n++) deck.push({ id: id++, color: c as 0 | 1 | 2 | 3, num: n });
  deck.push({ id: id++, color: 0, num: 0, fake: true });
  deck.push({ id: id++, color: 0, num: 0, fake: true });
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

export function startGame(s: OkeyState): OkeyState {
  const players = s.seats.filter(Boolean) as Seat[];
  if (players.length < 2) throw new Error("En az 2 oyuncu gerekli");
  const deck = buildDeck();
  // indicator: non-fake tile
  let idx = deck.findIndex((t) => !t.fake);
  const indicator = deck.splice(idx, 1)[0];
  const okey = { color: indicator.color, num: indicator.num === 13 ? 1 : indicator.num + 1 };
  // fake okeys play as the okey tile value; the okey tile is joker
  const starter = Math.floor(Math.random() * 4);
  const seats = s.seats.map((seat, i) => {
    if (!seat) return null;
    const n = i === starter ? 15 : 14;
    const rack: (Tile | null)[] = Array(RACK_SIZE).fill(null);
    for (let k = 0; k < n; k++) rack[k] = deck.pop()!;
    return { ...seat, rack, drawn: i === starter };
  });
  idx = seats.findIndex((x) => x);
  const turn = seats[starter] ? starter : idx;
  if (!seats[starter]) {
    // starter must have 15 tiles
    const st = seats[turn]!;
    const slot = st.rack.findIndex((t) => !t);
    st.rack[slot] = deck.pop()!;
    st.drawn = true;
  }
  return { ...s, seats, deck, indicator, okey, discards: [[], [], [], []], turn, phase: "playing", winner: undefined, log: [...s.log.slice(-20), "Oyun başladı!"], startedAt: Date.now() };
}

export function isJoker(t: Tile, okey: OkeyState["okey"]) {
  return !!okey && !t.fake && t.color === okey.color && t.num === okey.num;
}
export function effective(t: Tile, okey: OkeyState["okey"]): { color: number; num: number } | "joker" {
  if (isJoker(t, okey)) return "joker";
  if (t.fake && okey) return { color: okey.color, num: okey.num };
  return { color: t.color, num: t.num };
}

function prevSeat(s: OkeyState, seat: number) {
  for (let k = 1; k <= 4; k++) {
    const i = (seat - k + 4) % 4;
    if (s.seats[i]) return i;
  }
  return seat;
}
function nextSeat(s: OkeyState, seat: number) {
  for (let k = 1; k <= 4; k++) {
    const i = (seat + k) % 4;
    if (s.seats[i]) return i;
  }
  return seat;
}

export function draw(s: OkeyState, seat: number, from: "middle" | "left"): OkeyState {
  if (s.phase !== "playing" || s.turn !== seat) throw new Error("Sıra sende değil");
  const me = s.seats[seat]!;
  if (me.drawn) throw new Error("Zaten taş çektin");
  let tile: Tile | undefined;
  if (from === "middle") {
    tile = s.deck.pop();
    if (!tile) {
      return { ...s, phase: "finished", log: [...s.log, "Taşlar bitti, berabere."] };
    }
  } else {
    const p = prevSeat(s, seat);
    tile = s.discards[p].pop();
    if (!tile) throw new Error("Solda atılmış taş yok");
  }
  const slot = me.rack.findIndex((t) => !t);
  me.rack[slot] = tile;
  me.drawn = true;
  return { ...s, log: [...s.log.slice(-20), `${me.username} ${from === "middle" ? "ortadan" : "soldan"} taş çekti`] };
}

export function discard(s: OkeyState, seat: number, tileId: number): OkeyState {
  if (s.phase !== "playing" || s.turn !== seat) throw new Error("Sıra sende değil");
  const me = s.seats[seat]!;
  if (!me.drawn) throw new Error("Önce taş çekmelisin");
  const idx = me.rack.findIndex((t) => t && t.id === tileId);
  if (idx < 0) throw new Error("Taş bulunamadı");
  const tile = me.rack[idx]!;
  me.rack[idx] = null;
  s.discards[seat].push(tile);
  me.drawn = false;
  return { ...s, turn: nextSeat(s, seat), log: [...s.log.slice(-20), `${me.username} taş attı`] };
}

export function arrange(s: OkeyState, seat: number, rack: (number | null)[]): OkeyState {
  const me = s.seats[seat]!;
  const tiles = me.rack.filter(Boolean) as Tile[];
  const byId = new Map(tiles.map((t) => [t.id, t]));
  const next: (Tile | null)[] = Array(RACK_SIZE).fill(null);
  const used = new Set<number>();
  rack.slice(0, RACK_SIZE).forEach((id, i) => {
    if (id && byId.has(id) && !used.has(id)) {
      next[i] = byId.get(id)!;
      used.add(id);
    }
  });
  for (const t of tiles) if (!used.has(t.id)) next[next.findIndex((x) => !x)] = t;
  me.rack = next;
  return s;
}

// Validate groups: contiguous slots on each row (13 per row) form a group
function groupsFromRack(rack: (Tile | null)[]): Tile[][] {
  const groups: Tile[][] = [];
  for (const row of [rack.slice(0, 13), rack.slice(13, 26)]) {
    let cur: Tile[] = [];
    for (const t of row) {
      if (t) cur.push(t);
      else {
        if (cur.length) groups.push(cur);
        cur = [];
      }
    }
    if (cur.length) groups.push(cur);
  }
  return groups;
}

function validRun(group: Tile[], okey: OkeyState["okey"]) {
  if (group.length < 3) return false;
  const eff = group.map((t) => effective(t, okey));
  const concrete = eff.filter((e) => e !== "joker") as { color: number; num: number }[];
  if (!concrete.length) return true;
  const color = concrete[0].color;
  if (concrete.some((c) => c.color !== color)) return false;
  // try to fit sequence with jokers filling gaps, allowing 12-13-1 wrap
  const tryFrom = (start: number) => {
    let jokers = eff.filter((e) => e === "joker").length;
    for (let i = 0; i < group.length; i++) {
      const expect = ((start - 1 + i) % 13) + 1;
      const e = eff[i];
      if (e === "joker") continue;
      if (e.num !== expect) {
        if (jokers > 0) return false;
        return false;
      }
    }
    jokers = 0;
    return true;
  };
  for (let start = 1; start <= 13; start++) {
    if (tryFrom(start)) {
      // forbid wrap beyond 1 (e.g., 13-1-2 is not allowed, 12-13-1 is allowed)
      const nums = Array.from({ length: group.length }, (_, i) => ((start - 1 + i) % 13) + 1);
      const wrapIdx = nums.indexOf(1);
      if (wrapIdx > 0 && wrapIdx !== nums.length - 1) continue;
      return true;
    }
  }
  return false;
}
function validSet(group: Tile[], okey: OkeyState["okey"]) {
  if (group.length < 3 || group.length > 4) return false;
  const eff = group.map((t) => effective(t, okey));
  const concrete = eff.filter((e) => e !== "joker") as { color: number; num: number }[];
  if (!concrete.length) return true;
  const num = concrete[0].num;
  if (concrete.some((c) => c.num !== num)) return false;
  const colors = new Set(concrete.map((c) => c.color));
  return colors.size === concrete.length;
}
function validPairs(groups: Tile[][], okey: OkeyState["okey"]) {
  const all = groups.flat();
  if (all.length !== 14) return false;
  if (!groups.every((g) => g.length === 2)) return false;
  return groups.every((g) => {
    const [a, b] = g.map((t) => effective(t, okey));
    if (a === "joker" || b === "joker") return true;
    return a.color === b.color && a.num === b.num;
  });
}

export function checkFinish(rack: (Tile | null)[], okey: OkeyState["okey"]): { ok: boolean; pairs: boolean } {
  const groups = groupsFromRack(rack);
  const total = groups.flat().length;
  if (total !== 14) return { ok: false, pairs: false };
  if (validPairs(groups, okey)) return { ok: true, pairs: true };
  const ok = groups.every((g) => validRun(g, okey) || validSet(g, okey));
  return { ok, pairs: false };
}

export function finish(s: OkeyState, seat: number, tileId: number): OkeyState {
  if (s.phase !== "playing" || s.turn !== seat) throw new Error("Sıra sende değil");
  const me = s.seats[seat]!;
  if (!me.drawn) throw new Error("Önce taş çekmelisin");
  const idx = me.rack.findIndex((t) => t && t.id === tileId);
  if (idx < 0) throw new Error("Taş bulunamadı");
  const rack = me.rack.slice();
  rack[idx] = null;
  const r = checkFinish(rack, s.okey);
  if (!r.ok) throw new Error("Elin geçerli değil. Taşları seri/per ya da 7 çift olacak şekilde diz.");
  me.rack = rack;
  return { ...s, phase: "finished", winner: { userId: me.userId, username: me.username, pairs: r.pairs }, log: [...s.log.slice(-20), `🏆 ${me.username} ${r.pairs ? "ÇİFT" : ""} bitirdi!`] };
}

export function autoArrange(rack: (Tile | null)[], mode: "seri" | "cift", okey: OkeyState["okey"]): (Tile | null)[] {
  const tiles = (rack.filter(Boolean) as Tile[]).slice();
  const key = (t: Tile) => {
    const e = effective(t, okey);
    return e === "joker" ? { color: 9, num: 99 } : e;
  };
  const out: (Tile | null)[] = Array(RACK_SIZE).fill(null);
  if (mode === "seri") {
    tiles.sort((a, b) => key(a).color - key(b).color || key(a).num - key(b).num);
    let pos = 0;
    for (let i = 0; i < tiles.length; i++) {
      if (i > 0 && key(tiles[i]).color !== key(tiles[i - 1]).color) pos++;
      if (pos === 13) pos = 13; // move to second row
      if (pos >= RACK_SIZE) break;
      out[pos++] = tiles[i];
    }
  } else {
    tiles.sort((a, b) => key(a).num - key(b).num || key(a).color - key(b).color);
    let pos = 0;
    let i = 0;
    while (i < tiles.length && pos < RACK_SIZE) {
      const a = tiles[i], b = tiles[i + 1];
      if (b && key(a).num === key(b).num && key(a).color === key(b).color) {
        out[pos++] = a;
        out[pos++] = b;
        pos++;
        i += 2;
      } else {
        out[pos++] = a;
        i++;
      }
    }
  }
  return out;
}

export function viewFor(s: OkeyState, userId: number) {
  return {
    ...s,
    deck: undefined,
    deckCount: s.deck.length,
    seats: s.seats.map((seat) => (seat ? { ...seat, rack: seat.userId === userId ? seat.rack : seat.rack.map((t) => (t ? { id: 0, color: 0, num: 0 } : null)), tileCount: seat.rack.filter(Boolean).length } : null)),
  };
}
