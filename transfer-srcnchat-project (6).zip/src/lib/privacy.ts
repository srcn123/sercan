import { db } from "@/db";
import { friendships } from "@/db/schema";
import { and, eq, or } from "drizzle-orm";

export type PrefValue = "everyone" | "friends" | "nobody";

export function normalizePref(v: unknown): PrefValue {
  return v === "friends" || v === "nobody" ? v : "everyone";
}

export async function areFriends(a: number, b: number) {
  if (a === b) return true;
  const [row] = await db
    .select({ id: friendships.id })
    .from(friendships)
    .where(
      and(
        eq(friendships.status, "accepted"),
        or(
          and(eq(friendships.requesterId, a), eq(friendships.addresseeId, b)),
          and(eq(friendships.requesterId, b), eq(friendships.addresseeId, a)),
        ),
      ),
    )
    .limit(1);
  return !!row;
}

export async function checkPref(pref: unknown, meId: number, peerId: number): Promise<{ ok: boolean; reason?: string }> {
  const p = normalizePref(pref);
  if (p === "everyone") return { ok: true };
  if (p === "nobody") return { ok: false, reason: "kapalı" };
  const friends = await areFriends(meId, peerId);
  if (!friends) return { ok: false, reason: "dost" };
  return { ok: true };
}

export const PREF_LABEL: Record<PrefValue, string> = {
  everyone: "Herkes",
  friends: "Dostlarım",
  nobody: "Hiçkimse",
};
