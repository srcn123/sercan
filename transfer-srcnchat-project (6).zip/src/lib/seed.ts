import { db } from "@/db";
import { messages, okeyTables, rooms, settings, users, wordRules } from "@/db/schema";
import { count, eq } from "drizzle-orm";
import { hashPassword } from "./auth";
import { OKEY_TABLE_COUNT } from "./constants";

const DEFAULT_ROOMS = [
  { name: "Lobi", slug: "lobi", icon: "🏠", description: "Herkesin buluşma noktası", isDefault: true, kind: "chat", sortOrder: 0 },
  { name: "Müzik", slug: "muzik", icon: "🎧", description: "Şarkı adı yaz, DJ botu çalsın", kind: "music", sortOrder: 1 },
  { name: "Oyun", slug: "oyun", icon: "🎮", description: "Oyun geceleri ve takım arama", kind: "chat", sortOrder: 2 },
  { name: "Rastgele", slug: "rastgele", icon: "🎲", description: "Aklına ne gelirse", kind: "chat", sortOrder: 3 },
  { name: "Yapay Zeka", slug: "yapay-zeka", icon: "🤖", description: "Nova'ya istediğini sor", kind: "ai", sortOrder: 4 },
  { name: "Radyo", slug: "radyo", icon: "📻", description: "Çalan parçalar burada duyurulur", kind: "radio", sortOrder: 5 },
  { name: "Okey Salonu", slug: "okey-salonu", icon: "🀄", description: "3 masa, gerçek okey keyfi", kind: "okey", sortOrder: 6 },
];

const SEED_MESSAGES = [
  { username: "Luna", color: "#6d3bff", rank: "operator", content: "sohbete hepiniz hoş geldiniz" },
  { username: "Turbo", color: "#1e90ff", rank: "vip", content: "bu gece oyun gecesi var, kaçırmayın" },
  { username: "GeceKuşu", color: "#d946ef", rank: "uye", content: "radyodaki şarkı çok iyi değil mi?" },
  { username: "MaviBalina", color: "#06b6d4", rank: "admin", content: "odada kuralları okumayı unutmayın" },
  { username: "KediliAnne", color: "#f472b6", rank: "uye", content: "günaydın herkese, kahveler hazır ☕" },
];

const DEFAULT_SETTINGS: Record<string, string> = {
  installed: "0",
  siteName: "SrcnChat",
  domain: "",
  seoTitle: "SrcnChat — Sohbetin yeni adresi",
  seoDescription: "Odalara katıl, özel sohbetler başlat, radyoyu aç ve rütbeni yükselt.",
  seoKeywords: "sohbet, chat, radyo, okey, arkadaş",
  logoText: "SrcnChat",
  logoUrl: "",
  defaultTheme: "mor",
  radioEnabled: "1",
  radioStation: "paradise",
  customRadioUrl: "",
  announcement: "SrcnChat'e hoş geldin! Saygılı ol, spam yapma, keyfine bak. 🎉",
  securityMuteMinutes: "5",
  securityBanAfter: "5",
  nowPlaying: "",
  lastRadioTrack: "",
  botsEnabled: "1",
  iosAppStoreUrl: "",
  androidPlayStoreUrl: "",
  androidApkUrl: "",
  iosIcon: "",
  androidIcon: "",
  mobileDescription: "iOS ve Android’de native uygulama gibi çalışır — bildirimler, tam ekran, otomatik güncelleme.",
  mobileEnabled: "1",
  mobileAppName: "SrcnChat",
  mobileAppShortName: "SrcnChat",
  mobileAppDescription: "Sohbetin yeni adresi — odalara katıl, özel sohbetler başlat, radyoyu aç ve rütbeni yükselt.",
  mobileAppIcon: "",
  mobileAppThemeColor: "#6d3bff",
  mobileAppBackgroundColor: "#0b1020",
  mobileAppBrand: "SrcnChat",
  appStoreDescription: "Sohbetin yeni adresi — 7+ oda, okey, radyo, hediyeler ve daha fazlası. Hemen katıl!",
  playStoreDescription: "Sohbetin yeni adresi — 7+ oda, canlı radyo, okey salonu ve hediyelerle dolu topluluk.",
  rankPack: "pack1",
  rankPackCustom: "",
};

const DEFAULT_WORDS = [
  { word: "salak", replacement: "tatlı" },
  { word: "aptal", replacement: "şekerim" },
  { word: "gerizekalı", replacement: "canım" },
];

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  const [{ value }] = await db.select({ value: count() }).from(rooms);
  if (value === 0) {
    await db.insert(rooms).values(DEFAULT_ROOMS);
  }
  for (const [key, val] of Object.entries(DEFAULT_SETTINGS)) {
    await db.insert(settings).values({ key, value: val }).onConflictDoNothing();
  }
  const [lobby] = await db.select().from(rooms).where(eq(rooms.isDefault, true)).limit(1);
  if (lobby) {
    const [{ value: msgCount }] = await db.select({ value: count() }).from(messages).where(eq(messages.roomId, lobby.id));
    if (msgCount === 0) {
      await db.insert(messages).values(SEED_MESSAGES.map((m) => ({ ...m, roomId: lobby.id, userId: null })));
    }
  }
  // Kurucu
  const [founder] = await db.select({ id: users.id }).from(users).where(eq(users.usernameLower, "sercan")).limit(1);
  if (!founder) {
    await db.insert(users).values({
      username: "Sercan",
      usernameLower: "sercan",
      passwordHash: hashPassword("Sercan123"),
      secretWordHash: hashPassword("srcn"),
      color: "#6d3bff",
      rank: "kurucu",
      isGuest: false,
      isDj: true,
      isVerified: true,
      points: 10000,
      xp: 10000,
      about: "SrcnChat kurucusu",
    });
  }
  // Bots
  const allRooms = await db.select().from(rooms);
  const aiRoom = allRooms.find((r) => r.kind === "ai");
  const musicRoom = allRooms.find((r) => r.kind === "music");
  const bots = [
    { username: "Nova", botKind: "nova", color: "#a855f7", botRoomMode: "fixed", botRoomId: aiRoom?.id ?? null, about: "Yapay zekâ asistanı. Sor, cevaplayayım ✨" },
    { username: "DJ Srcn", botKind: "dj", color: "#f59e0b", botRoomMode: "fixed", botRoomId: musicRoom?.id ?? null, about: "Şarkı adını yaz, çalayım 🎧" },
    { username: "Bekçi", botKind: "security", color: "#ef4444", botRoomMode: "all", botRoomId: null, about: "Kuralları koruyan güvenlik botu 🛡" },
  ];
  for (const b of bots) {
    const [exists] = await db.select({ id: users.id }).from(users).where(eq(users.botKind, b.botKind)).limit(1);
    if (!exists) {
      await db.insert(users).values({
        ...b,
        usernameLower: b.username.toLocaleLowerCase("tr"),
        isBot: true,
        isGuest: false,
        rank: "vip",
        isVerified: true,
        lastSeen: new Date(),
      });
    }
  }
  const [{ value: wr }] = await db.select({ value: count() }).from(wordRules);
  if (wr === 0) await db.insert(wordRules).values(DEFAULT_WORDS);
  for (let i = 1; i <= OKEY_TABLE_COUNT; i++) {
    await db.insert(okeyTables).values({ id: i, state: {} }).onConflictDoNothing();
  }
  seeded = true;
}
