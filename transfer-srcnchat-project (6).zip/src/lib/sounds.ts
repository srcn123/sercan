"use client";

export type SoundCategory = "sohbet" | "ozel" | "bildirim" | "username" | "cagri";

export const SOUND_CATEGORIES: Record<SoundCategory, { label: string; desc: string; icon: string }> = {
  sohbet: { label: "Sohbet sesleri", desc: "Oda mesajı geldiğinde", icon: "💬" },
  ozel: { label: "Özel sesleri", desc: "Özel mesaj geldiğinde", icon: "✉️" },
  bildirim: { label: "Bildirim sesleri", desc: "Genel bildirimler", icon: "🔔" },
  username: { label: "Username sesleri", desc: "@bahsedildiğinde", icon: "📢" },
  cagri: { label: "Çağrı sesleri", desc: "Arama geldiğinde", icon: "📞" },
};

export const SOUND_PRESETS: Record<SoundCategory, { id: string; name: string; freq: number; pattern: "single" | "double" | "triple" | "chime" | "ring" }[]> = {
  sohbet: [
    { id: "pop", name: "Pop", freq: 880, pattern: "single" },
    { id: "click", name: "Tık", freq: 1200, pattern: "single" },
    { id: "bubble", name: "Baloncuk", freq: 600, pattern: "double" },
    { id: "soft", name: "Yumuşak", freq: 700, pattern: "single" },
  ],
  ozel: [
    { id: "ding", name: "Ding", freq: 1046, pattern: "double" },
    { id: "chime2", name: "Çınlama", freq: 880, pattern: "chime" },
    { id: "notify", name: "Bildirim", freq: 900, pattern: "double" },
  ],
  bildirim: [
    { id: "bell", name: "Çan", freq: 800, pattern: "single" },
    { id: "chime", name: "Melodi", freq: 600, pattern: "chime" },
    { id: "alert", name: "Uyarı", freq: 1000, pattern: "triple" },
  ],
  username: [
    { id: "highlight", name: "Vurgu", freq: 1318, pattern: "double" },
    { id: "ping", name: "Ping", freq: 1500, pattern: "single" },
    { id: "attention", name: "Dikkat", freq: 1200, pattern: "triple" },
  ],
  cagri: [
    { id: "ring", name: "Zil", freq: 660, pattern: "ring" },
    { id: "phone", name: "Telefon", freq: 440, pattern: "ring" },
    { id: "classic", name: "Klasik", freq: 550, pattern: "ring" },
  ],
};

export type SoundSettings = Record<SoundCategory, { enabled: boolean; volume: number; preset: string }>;

const DEFAULT_SOUNDS: SoundSettings = {
  sohbet: { enabled: true, volume: 50, preset: "pop" },
  ozel: { enabled: true, volume: 70, preset: "ding" },
  bildirim: { enabled: true, volume: 60, preset: "bell" },
  username: { enabled: true, volume: 80, preset: "highlight" },
  cagri: { enabled: true, volume: 80, preset: "ring" },
};

const STORAGE_KEY = "srcn_sounds_v1";

export function getSoundSettings(): SoundSettings {
  if (typeof window === "undefined") return DEFAULT_SOUNDS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_SOUNDS, ...JSON.parse(raw) };
  } catch {}
  return DEFAULT_SOUNDS;
}

export function saveSoundSettings(s: SoundSettings) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(s)); } catch {}
}

let audioCtx: AudioContext | null = null;
function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)(); } catch { return null; }
  }
  if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
  return audioCtx;
}

function playTone(freq: number, duration: number, volume: number, type: OscillatorType = "sine", delay = 0) {
  const ctx = getCtx(); if (!ctx) return;
  const now = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(0, now);
  gain.gain.linearRampToValueAtTime(volume / 100 * 0.15, now + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(now); osc.stop(now + duration + 0.02);
}

export function playSound(category: SoundCategory, customSettings?: SoundSettings) {
  const settings = customSettings ?? getSoundSettings();
  const cfg = settings[category];
  if (!cfg?.enabled || cfg.volume === 0) return;
  const preset = SOUND_PRESETS[category].find((p) => p.id === cfg.preset) ?? SOUND_PRESETS[category][0];
  const vol = cfg.volume;
  switch (preset.pattern) {
    case "single": playTone(preset.freq, 0.12, vol); break;
    case "double": playTone(preset.freq, 0.12, vol); playTone(preset.freq * 1.25, 0.12, vol, "sine", 0.14); break;
    case "triple": playTone(preset.freq, 0.08, vol); playTone(preset.freq * 1.2, 0.08, vol, "sine", 0.1); playTone(preset.freq * 1.5, 0.12, vol, "sine", 0.2); break;
    case "chime": playTone(preset.freq, 0.3, vol, "sine"); playTone(preset.freq * 1.5, 0.3, vol * 0.7, "triangle", 0.05); playTone(preset.freq * 2, 0.4, vol * 0.5, "sine", 0.15); break;
    case "ring": for (let i = 0; i < 3; i++) playTone(preset.freq, 0.25, vol, "sine", i * 0.35); break;
  }
}

export function testSound(category: SoundCategory, presetId?: string, volume?: number) {
  const s = getSoundSettings();
  const testCfg = { ...s[category], preset: presetId ?? s[category].preset, volume: volume ?? s[category].volume, enabled: true };
  const tmp: SoundSettings = { ...s, [category]: testCfg };
  playSound(category, tmp);
}
