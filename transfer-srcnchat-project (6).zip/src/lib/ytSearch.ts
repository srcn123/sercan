export async function searchYoutubeFull(q: string): Promise<{ title: string; artist: string; youtubeId: string; artwork?: string } | null> {
  const enc = encodeURIComponent(q);
  const mirrors = [
    `https://pipedapi.kavin.rocks/search?q=${enc}`,
    `https://pipedapi.adminforge.de/search?q=${enc}`,
    `https://api.piped.private.coffee/search?q=${enc}`,
    `https://pipedapi.syncpundit.io/search?q=${enc}`,
    `https://inv.nadeko.net/api/v1/search?q=${enc}`,
    `https://yt.artemislena.eu/api/v1/search?q=${enc}`,
  ];
  for (const url of mirrors) {
    try {
      const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 2500);
      const r = await fetch(url, { signal: ctrl.signal });
      clearTimeout(t);
      if (!r.ok) continue;
      const d = await r.json();
      const items = (Array.isArray(d) ? d : d.items ?? d) as { type: string; title: string; uploaderName?: string; url?: string; thumbnail?: string; videoId?: string; id?: string }[];
      const v = items.find((x) => (x.type === "stream" || x.type === "video" || !x.type) && (x.url?.startsWith("/watch") || x.videoId || x.id));
      if (v) {
        const vid = (v.url?.split("v=")[1]?.split("&")[0]) ?? v.videoId ?? v.id ?? "";
        if (vid) return { title: v.title, artist: v.uploaderName ?? "", youtubeId: vid, artwork: v.thumbnail ?? `https://img.youtube.com/vi/${vid}/mqdefault.jpg` };
      }
    } catch {}
  }
  return null;
}
